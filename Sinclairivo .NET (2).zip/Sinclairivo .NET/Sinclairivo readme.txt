Sinclairivo .NET
================

Sinclairivo is an university project made as an exercise in my
C# course. It allows you to play some of the old ZX Spectrum gaming
software or you can go to BASIC to try some programming. However,
this program is just an exercise so that the funcionality of the
program is a bit limited.

This program is a Sinclair ZX Spectrum emulator - an old 8bit computer
made in the United Kingdom and also in the Czech Republic as a clone
named Didaktik.

As part of the program you can find also a set of old Spectrum ROMs and
some gaming software to ilustrate the functioning of Sinclairivo.

Unfortunately, Sinclairivo doesn't support any sound output. Hopefully,
this will be added in the future. 

How to control this program:
This software behaves just like the old good ZX Spectrum. Just let the 
program run... You can select a game from the "Archive menu" or you can
go the the BASIC OS to start programming in BASIC. Just press the
"ROM #1" or "ROM #2" buttons. ROM 1 is the original ZX Spectrum operating
system. ROM 2 is a little bit adjusted - you have to type every command
which is probably more suitable for a PC user...

Press the "Reset" button to reset the ZX Spectrum system.
Press the "Pause" button to pause execution of a ZX Spectrum program.
Press "CTRL" to emulate the "Symbol Shift" key.
Press "Shift" to emulate the "Caps Lock" key.
Press "CTRL" + "Shift" to emulate the extended mode.


About me:
I am currently studying at the university of South Bohemia, Czech Republic.
My major is the computer science. Basically, I am very interested in desktop
programming, using JAVA, C# and C++.
Contact: JanKapoun@seznam.cz

Enjoy Sinclairivo .NET!

Mgr. Jan Kapoun
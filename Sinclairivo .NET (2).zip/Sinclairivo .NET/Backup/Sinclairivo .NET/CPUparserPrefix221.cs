using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{
/*
 * Parses instructions following the 221 prefix code.
 * 
 */
    public class CPUparserPrefix221
    {
        private CPUroutines cpu;
        private Registers Registers;
        private CPUparserPrefix221_203 prefix221_203;
        private int code;

        public CPUparserPrefix221(CPUroutines cpu, Registers Registers)
        {
            this.cpu = cpu;
            this.Registers = Registers;
            prefix221_203 = new CPUparserPrefix221_203(cpu, Registers);
        }

        public void Parse()
        {
            cpu.Refresh_R(); //obnov R registr
            code = cpu.Fetch();

            switch (code)
            {

                case 104:/*LD LX,B */
                    {
                        cpu.LD(Registers.regLX, Registers.regB);
                    }
                    break;

                case 105:/*LD LX,C */
                    {
                        cpu.LD(Registers.regLX, Registers.regC);
                    }
                    break;

                case 106:/*LD LX,D */
                    {
                        cpu.LD(Registers.regLX, Registers.regD);
                    }
                    break;

                case 107:/*LD LX,E */
                    {
                        cpu.LD(Registers.regLX, Registers.regE);
                    }
                    break;

                case 108:/*LD LX,HX */
                    {
                        cpu.LD(Registers.regLX, Registers.regHX);
                    }
                    break;

                case 109:/*LD LX,LX */
                    {
                        cpu.LD(Registers.regLX, Registers.regLX);
                    }
                    break;

                case 111:/*LD LX,A */
                    {
                        cpu.LD(Registers.regLX, Registers.regA);
                    }
                    break;

                case 96:/*LD HX,B */
                    {
                        cpu.LD(Registers.regHX, Registers.regB);
                    }
                    break;

                case 97:/*LD HX,C */
                    {
                        cpu.LD(Registers.regHX, Registers.regC);
                    }
                    break;

                case 98:/*LD HX,D */
                    {
                        cpu.LD(Registers.regHX, Registers.regD);
                    }
                    break;

                case 99:/*LD HX,E */
                    {
                        cpu.LD(Registers.regHX, Registers.regE);
                    }
                    break;

                case 100:/*LD HX,HX */
                    {
                        cpu.LD(Registers.regHX, Registers.regHX);
                    }
                    break;

                case 101:/*LD HX,LX */
                    {
                        cpu.LD(Registers.regHX, Registers.regLX);
                    }
                    break;

                case 103:/*LD HX,A */
                    {
                        cpu.LD(Registers.regHX, Registers.regA);
                    }
                    break;

                case 38:/*LD HX,N*/
                    {
                        cpu.LD_REG8_NN(Registers.regHX);
                    }
                    break;

                case 46:/*LD LX,N*/
                    {
                        cpu.LD_REG8_NN(Registers.regLX);
                    }
                    break;

                case 69:/*LD B,LX*/
                    {
                        cpu.LD(Registers.regB, Registers.regLX);
                    }
                    break;

                case 77:/*LD C,LX*/
                    {
                        cpu.LD(Registers.regC, Registers.regLX);
                    }
                    break;

                case 85:/*LD D,LX*/
                    {
                        cpu.LD(Registers.regD, Registers.regLX);
                    }
                    break;

                case 93:/*LD E,LX*/
                    {
                        cpu.LD(Registers.regE, Registers.regLX);
                    }
                    break;

                case 125:/*LD A,LX*/
                    {
                        cpu.LD(Registers.regA, Registers.regLX);
                    }
                    break;

                case 68:/*LD B,HX*/
                    {
                        cpu.LD(Registers.regB, Registers.regHX);
                    }
                    break;

                case 76:/*LD C,HX*/
                    {
                        cpu.LD(Registers.regC, Registers.regHX);
                    }
                    break;

                case 84:/*LD D,HX*/
                    {
                        cpu.LD(Registers.regD, Registers.regHX);
                    }
                    break;

                case 92:/*LD E,HX*/
                    {
                        cpu.LD(Registers.regE, Registers.regHX);
                    }
                    break;

                case 124:/*LD A,HX*/
                    {
                        cpu.LD(Registers.regA, Registers.regHX);
                    }
                    break;

                case 36:/*INC HX*/
                    {
                        cpu.INC(Registers.regHX);
                    }
                    break;

                case 37:/*DEC HX*/
                    {
                        cpu.DEC(Registers.regHX);
                    }
                    break;

                case 44:/*INC LX*/
                    {
                        cpu.INC(Registers.regLX);
                    }
                    break;

                case 45:/*DEC LX*/
                    {
                        cpu.DEC(Registers.regLX);
                    }
                    break;

                case 132:/*ADD A, HX*/
                    {
                        cpu.ADD(Registers.regA, Registers.regHX);
                    }
                    break;

                case 133:/*ADD A, LX*/
                    {
                        cpu.ADD(Registers.regA, Registers.regLX);
                    }
                    break;

                case 140:/*ADC A, HX*/
                    {
                        cpu.ADC(Registers.regA, Registers.regHX);
                    }
                    break;

                case 141:/*ADC A, LX*/
                    {
                        cpu.ADC(Registers.regA, Registers.regLX);
                    }
                    break;

                case 148:/*SUB A, HX*/
                    {
                        cpu.SUB(Registers.regA, Registers.regHX);
                    }
                    break;

                case 149:/*SUB A, LX*/
                    {
                        cpu.SUB(Registers.regA, Registers.regLX);
                    }
                    break;


                case 156:/*SBC A, HX*/
                    {
                        cpu.SBC(Registers.regA, Registers.regHX);
                    }
                    break;

                case 157:/*SBC A, LX*/
                    {
                        cpu.SBC(Registers.regA, Registers.regLX);
                    }
                    break;

                case 164:/*AND HX*/
                    {
                        cpu.AND(Registers.regA, Registers.regHX);
                    }
                    break;

                case 165:/*AND LX*/
                    {
                        cpu.AND(Registers.regA, Registers.regLX);
                    }
                    break;


                case 166:/*AND (IX + N)*/
                    {
                        cpu.AND_RegA_FromWherePointsIX_IY_Shift(Registers.regIX);
                    }
                    break;

                case 172:/*XOR HX*/
                    {
                        cpu.XOR(Registers.regA, Registers.regHX);
                    }
                    break;

                case 173:/*XOR LX*/
                    {
                        cpu.XOR(Registers.regA, Registers.regLX);
                    }
                    break;


                case 180:/*OR HX*/
                    {
                        cpu.OR(Registers.regA, Registers.regHX);
                    }
                    break;

                case 181:/*OR LX*/
                    {
                        cpu.OR(Registers.regA, Registers.regLX);
                    }
                    break;


                case 182:/*OR (IX + N)*/
                    {
                        cpu.OR_RegA_FromWherePointsIX_IY_Shift(Registers.regIX);
                    }
                    break;

                case 174:/*XOR (IX + N)*/
                    {
                        cpu.XOR_RegA_FromWherePointsIX_IY_Shift(Registers.regIX);
                    }
                    break;

                case 188:/*CP HX*/
                    {
                        cpu.CP(Registers.regA, Registers.regHX);
                    }
                    break;

                case 189:/*CP LX*/
                    {
                        cpu.CP(Registers.regA, Registers.regLX);
                    }
                    break;


                case 190: /*CP (IX + N)*/
                    {
                        cpu.CP_RegA_FromWherePointsIX_IY_Shift(Registers.regIX);
                    }
                    break;

                case 52: /*INC (IX + N)*/
                    {
                        cpu.INC_WherePointsIX_Shift(Registers.regIX);
                    }
                    break;

                case 53: /*DEC (IX + N)*/
                    {
                        cpu.DEC_WherePointsIX_Shift(Registers.regIX);
                    }
                    break;

                case 134: /*ADD A,(IX + N)*/
                    {
                        cpu.ADD_A_IX_IY_Plus_N(Registers.regA, Registers.regIX);
                    }
                    break;

                case 142: /*ADC A,(IX + N)*/
                    {
                        cpu.ADC_A_IX_IY_Plus_N(Registers.regA, Registers.regIX);
                    }
                    break;

                case 150: /*SUB(IX + N)*/
                    {
                        cpu.SUB_A_IX_IY_Plus_N(Registers.regA, Registers.regIX);
                    }
                    break;

                case 158: /*SBC A,(IX + N)*/
                    {
                        cpu.SBC_A_IX_IY_Plus_N(Registers.regA, Registers.regIX);
                    }
                    break;

                case 227:    /* EX (SP),IX */
                    {
                        cpu.EX_ToWherePointsSP_IX();
                    }
                    break;

                case 249:  /* LD SP,IX*/
                    {
                        cpu.LD(Registers.regSP, Registers.regIX, 10);
                    }
                    break;

                case 33: /*LD IX,NN*/
                    {
                        cpu.LD_REG16_NN(Registers.regIX, 14);
                    }
                    break;

                case 34:  /* LD (nn),IX*/
                    {
                        cpu.LD_MEM_REG16(Registers.regIX, 20);
                    }
                    break;

                case 42: /*LD IX,(NN)*/
                    {
                        cpu.LD_REG16_FromWherePointsOp(Registers.regIX, 20);
                    }
                    break;

                case 70: /*LD B,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regB, Registers.regIX);
                    }
                    break;

                case 78: /*LD C,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regC, Registers.regIX);
                    }
                    break;

                case 86: /*LD D,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regD, Registers.regIX);
                    }
                    break;

                case 94: /*LD E,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regE, Registers.regIX);
                    }
                    break;

                case 102: /*LD H,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regH, Registers.regIX);
                    }
                    break;

                case 110: /*LD L,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regL, Registers.regIX);
                    }
                    break;

                case 126: /*LD A,(IX + E)*/
                    {
                        cpu.LD_REG8_From_IndexReg(Registers.regA, Registers.regIX);
                    }
                    break;

                case 112: /*LD (IX + E),B*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regB);
                    }
                    break;

                case 113: /*LD (IX + E),C*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regC);
                    }
                    break;

                case 114: /*LD (IX + E),D*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regD);
                    }
                    break;

                case 115: /*LD (IX + E),E*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regE);
                    }
                    break;

                case 116: /*LD (IX + E),H*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regH);
                    }
                    break;

                case 117: /*LD (IX + E),L*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regL);
                    }
                    break;

                case 119: /*LD (IX + E),A*/
                    {
                        cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIX, Registers.regA);
                    }
                    break;

                case 54: /*LD (IX + E),N*/
                    {
                        cpu.LD_ToWherePointsIndexReg_NN(Registers.regIX);
                    }
                    break;

                case 35: /*INC IX*/
                    {
                        cpu.INC_IndexReg(Registers.regIX);
                    }
                    break;

                case 43: /*DEC IX*/
                    {
                        cpu.DEC_IndexReg(Registers.regIX);
                    }
                    break;

                case 9: /*ADD IX,BC*/
                    {
                        cpu.ADD_IX_REG16(Registers.regIX, Registers.regBC);
                    }
                    break;

                case 25: /*ADD IX,DE*/
                    {
                        cpu.ADD_IX_REG16(Registers.regIX, Registers.regDE);
                    }
                    break;

                case 41: /*ADD IX,IX*/
                    {
                        cpu.ADD_IX_REG16(Registers.regIX, Registers.regIX);
                    }
                    break;

                case 57: /*ADD IX,SP*/
                    {
                        cpu.ADD_IX_REG16(Registers.regIX, Registers.regSP);
                    }
                    break;

                case 229: /*PUSH IX*/
                    {
                        cpu.PUSH_IndexReg(Registers.regIX);
                    }
                    break;

                case 225: /*POP IX*/
                    {
                        cpu.POP_IndexReg(Registers.regIX);
                    }
                    break;

                case 233: /*JP (IX)*/
                    {
                        cpu.JP_Index(Registers.regIX);
                    }
                    break;

                case 203:
                    {
                        prefix221_203.Parse();
                    }
                    break;


                default:
                    {
                        MessageBox.Show("Prefix 221, instruction not supported, code: " + code + ", address: " + Registers.regPC);
                    }
                    break;
            }
        }



        //end of class
    }
}

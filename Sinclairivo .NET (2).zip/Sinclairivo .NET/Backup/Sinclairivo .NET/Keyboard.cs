using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Windows.Forms;

namespace Sinclairivo.NET
{

/*
 * Contains representation of the ZXS keyboard
 * 
 */
    public class Keyboard
    {


    public class Key
    {
        public int port1;
        public int port2;
        public int portOn1;
        public int portOn2;
        public int portOff1;
        public int portOff2;
        public String key;
    
        public Key(String key, int port1, int port2, int on1, int on2,  int off1, int off2)
        {
            this.port1 = port1;
            this.port2 = port2;
            this.key = key;
            this.portOn1 = on1;
            this.portOn2 = on2;
            this.portOff1 = off1;
            this.portOff2 = off2;
            this.key = key;
        }
        
    }
    
    private  ArrayList keys = new ArrayList();
    private Ports ports = null;
    
    private int on0 = 254;
    private int on1 = 253;
    private int on2 = 251;
    private int on3 = 247;
    private int on4 = 239;
    
    private int off0 = 1;
    private int off1 = 2;
    private int off2 = 4;
    private int off3 = 8;
    private int off4 = 16;
    
    
    public Keyboard(Ports ports)
    {
        this.ports = ports;
        
        
        keys.Add(new Key("Back", 65278, 61438, on0, on0, off0, off0));
        keys.Add(new Key("Oemcomma", 32766, 32766, on1, on3, off1, off3));
        keys.Add(new Key("OemPeriod", 32766, 32766, on1, on2, off1, off2));
        keys.Add(new Key("Slash",32766 , 65278, on1, on4, off1, off4));
        keys.Add(new Key("NumPad /",32766 , 65278, on1, on4, off1, off4));
        keys.Add(new Key("NumPad *",32766 , 65278, on1, on4, off1, off4));
        keys.Add(new Key("NumPad -",32766 , 65278, on1, on4, off1, off4));
        keys.Add(new Key("NumPad +",32766 , 65278, on1, on4, off1, off4));
        
        
        keys.Add(new Key("Capital",65278 , 63486, on0, on1, off0, off1));
        keys.Add(new Key("Escape",65278 , 32766, on0, on0, off0, off0));
        
        keys.Add(new Key("Down", 65278, 61438, on0, on4, off0, off4));
        keys.Add(new Key("Up", 65278, 61438, on0, on3, off0, off3));
        keys.Add(new Key("Right", 65278, 61438, on0, on2, off0, off2));
        keys.Add(new Key("Left", 65278, 63486, on0, on4, off0, off4));
        
        keys.Add(new Key("ShiftKey", 65278, 0, on0, 255, off0, 255));
        keys.Add(new Key("Z", 65278, 0, on1, 255, off1, 255));
        keys.Add(new Key("X", 65278, 0, on2, 255, off2, 255));
        keys.Add(new Key("C", 65278, 0, on3, 255, off3, 255));
        keys.Add(new Key("V", 65278, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("A", 65022, 0, on0, 255, off0, 255));
        keys.Add(new Key("S", 65022, 0, on1, 255, off1, 255));
        keys.Add(new Key("D", 65022, 0, on2, 255, off2, 255));
        keys.Add(new Key("F", 65022, 0, on3, 255, off3, 255));
        keys.Add(new Key("G", 65022, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("Q", 64510, 0, on0, 255, off0, 255));
        keys.Add(new Key("W", 64510, 0, on1, 255, off1, 255));
        keys.Add(new Key("E", 64510, 0, on2, 255, off2, 255));
        keys.Add(new Key("R", 64510, 0, on3, 255, off3, 255));
        keys.Add(new Key("T", 64510, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("D1", 63486, 0, on0, 255, off0, 255));
        keys.Add(new Key("D2", 63486, 0, on1, 255, off1, 255));
        keys.Add(new Key("D3", 63486, 0, on2, 255, off2, 255));
        keys.Add(new Key("D4", 63486, 0, on3, 255, off3, 255));
        keys.Add(new Key("D5", 63486, 0, on4, 255, off4, 255));
        keys.Add(new Key("NumPad-1", 63486, 0, on0, 255, off0, 255));
        keys.Add(new Key("NumPad-2", 63486, 0, on1, 255, off1, 255));
        keys.Add(new Key("NumPad-3", 63486, 0, on2, 255, off2, 255));
        keys.Add(new Key("NumPad-4", 63486, 0, on3, 255, off3, 255));
        keys.Add(new Key("NumPad-5", 63486, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("D0", 61438, 0, on0, 255, off0, 255));
        keys.Add(new Key("D9", 61438, 0, on1, 255, off1, 255));
        keys.Add(new Key("D8", 61438, 0, on2, 255, off2, 255));
        keys.Add(new Key("D7", 61438, 0, on3, 255, off3, 255));
        keys.Add(new Key("D6", 61438, 0, on4, 255, off4, 255));
        keys.Add(new Key("NumPad-0", 61438, 0, on0, 255, off0, 255));
        keys.Add(new Key("NumPad-9", 61438, 0, on1, 255, off1, 255));
        keys.Add(new Key("NumPad-8", 61438, 0, on2, 255, off2, 255));
        keys.Add(new Key("NumPad-7", 61438, 0, on3, 255, off3, 255));
        keys.Add(new Key("NumPad-6", 61438, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("P", 57342, 0, on0, 255, off0, 255));
        keys.Add(new Key("O", 57342, 0, on1, 255, off1, 255));
        keys.Add(new Key("I", 57342, 0, on2, 255, off2, 255));
        keys.Add(new Key("U", 57342, 0, on3, 255, off3, 255));
        keys.Add(new Key("Y", 57342, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("Return", 49150, 0, on0, 255, off0, 255));
        keys.Add(new Key("L", 49150, 0, on1, 255, off1, 255));
        keys.Add(new Key("K", 49150, 0, on2, 255, off2, 255));
        keys.Add(new Key("J", 49150, 0, on3, 255, off3, 255));
        keys.Add(new Key("H", 49150, 0, on4, 255, off4, 255));
        
        keys.Add(new Key("Space", 32766, 0, on0, 255, off0, 255));
        keys.Add(new Key("ControlKey", 32766, 0, on1, 255, off1, 255));
        keys.Add(new Key("M", 32766, 0, on2, 255, off2, 255));
        keys.Add(new Key("N", 32766, 0, on3, 255, off3, 255));
        keys.Add(new Key("B", 32766, 0, on4, 255, off4, 255));
        
    }
    
    public void KeyDown(String keyText)
    {
        
        foreach (Key key in keys)
        {
        
                if(keyText == (key.key))
                {
                    if (Globals.mapCursorAsKempston == true)
                    {
                        if (key.key == ("Left")){ ports.SetPort(31, (ports.InPort(31) | 2)); return; }
                        if (keyText == ("Right")){ ports.SetPort(31, (ports.InPort(31) | 1)); return; }
                        if (keyText == ("Up")){ ports.SetPort(31, (ports.InPort(31) | 8)); return; }
                        if (keyText == ("Down")){ ports.SetPort(31, (ports.InPort(31) | 4)); return; }
                        if (keyText == ("Ctrl")){ ports.SetPort(31, (ports.InPort(31) | 16)); return; }
                    }
                    
                    ports.SetPort(key.port1, ports.InPort(key.port1) & key.portOn1);
                    if (key.port2 != 0) {ports.SetPort(key.port2, ports.InPort(key.port2) & key.portOn2);}
                }
         }
      }
                     
    
      

    public void KeyUp(String keyText)
    {
        foreach(Key key in keys)
        {

                if(keyText == (key.key))
                {
                    if (Globals.mapCursorAsKempston == true)
                    {
                        if (key.key == ("Left")){ ports.SetPort(31, (ports.InPort(31) & 29)); return; }
                        if (keyText == ("Right")){ ports.SetPort(31, (ports.InPort(31) & 30)); return; }
                        if (keyText == ("Up")){ ports.SetPort(31, (ports.InPort(31) & 23)); return; }
                        if (keyText == ("Down")){ ports.SetPort(31, (ports.InPort(31) & 27)); return; }
                        if (keyText == ("Ctrl")){ ports.SetPort(31, (ports.InPort(31) & 15)); return; }
                    }
                
                    ports.SetPort(key.port1, ports.InPort(key.port1) | key.portOff1);
                    if (key.port2 != 0) {ports.SetPort(key.port2, ports.InPort(key.port2) | key.portOff2);}
                }
                
           
           }
          
    }
    
  
        //end of class
    }
}

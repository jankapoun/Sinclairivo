using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{
    /**
    * Stores the unsigned short values
    * @author Jan Kapoun, Mgr.
    */
    public class USHORT
    {
        private int value = 0;
        private String name = "Unknown";

        /**
         * New instance of USHORT
         * 
         */
        public USHORT(int value)
        {
            if ((value > 65535) || (value < 0))
            {
                MessageBox.Show("USHORT, constructor, argument out of range: " + value);
                return;
            }

            this.value = value;
        }

        USHORT(int value, String name)
        {
            if ((value > 65535) || (value < 0))
            {
                MessageBox.Show("USHORT, constructor, argument out of range: " + value);
                return;
            }

            this.value = value;
            this.name = name;
        }

        /**
         * Adds the specified number
         * 
         */
        public int Plus(int plus)
        {
            if (plus < 0) { this.Minus(plus * -1); return value; }
            if ((plus > 65535) || (plus < 0))
            {
                //            System.err.println("USHORT, Plus method, argument out of range: " + plus + ":" +  Main.regs.regPC.Get());

                return -1;
            }
            value += plus;
            if (value > 65535) { value = value - 65536; }
            return value;
        }


        /**
        * Substracts the specified number
        * 
        */
        public int Minus(int minus)
        {
            if (minus > 65535 || (minus < 0))
            {
                MessageBox.Show("USHORT, Minus method, argument out of range: " + minus);
                return -1;
            }
            value -= minus;
            if (value < 0) { value = value + 65536; }
            return value;
        }

        /**
         * Returns the actual value of this USHORT
         * 
         */
        public int Get()
        {
            return value;
        }

        public void SetName(String name)
        {
            this.name = name;
        }

        /**
        * Sets the USHORT to the specified value
        * 
        */
        public int Set(int x)
        {
            if ((x > 65535) || (x < 0))
            {
                //          System.err.println("USHORT, Set method, argument out of range: " + x + ":" +  Main.regs.regPC.Get() + " " + name); 
                return -1;
            }
            value = x;
            return value;
        }

        public int Inc()
        {
            Plus(1);
            return value;
        }

        public int Dec()
        {
            Minus(1);
            return value;
        }





        //end of class
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace Sinclairivo.NET
{
/**
 * This class contains the whole ZX Spectrum machine incl keyboard, screen etc...
 * @author Jan Kapoun, Mgr.
 */
    public class ZXMachine
    {
    public Registers Registers; 
    public Flags flg;
    public RAM ram;
    public Ports ports;
    public CPUroutines r;
    public CPUparser cpu;
    public Keyboard kbd;
    
    public ZXMachine(MainWnd mainWindow)
    {
        
        Registers = new Registers();
        flg = new Flags(Registers);
        ports = new Ports();
        ram = new RAM(mainWindow, ports);
        r = new CPUroutines(ram, flg, ports, Registers);
        cpu = new CPUparser(r, Registers);

        ram.ClearVRAM();
        Registers.regPC.Set(0);
        Registers.regSP.Set(0);
        
        kbd = new Keyboard(ports);
        
        LoadROM();
    }
   
    
    /**
     * Launches machine code.
     * @param iCount number of instructions to launch.
     * @param PCreg from where shall the execution start.
     */
    public void LaunchMachineCode(int iCount, int PCreg)
    {
        Registers.regPC.Set(PCreg);
        launchMCode(iCount);
    }

    /**
     * Launches specified number of instructions.
     * @param iCount number of instructions to launch.
     */
    public void LaunchMachineCode(int iCount)
    {
        launchMCode(iCount);
    }
    
    
    private void launchMCode(int iCount)
    {
        for (int j = 0; j < iCount; j++)
        {
            cpu.Parse();
            IMCallOnRequest();
            
        }
    
    }
    
    /**
     * Calls an interrupt when needed.
     */
    private void IMCallOnRequest()
    {
        if (r.GetInterruptRequest() == true)
        { r.CallIM(); }
    }


/**
 * Resets the whole machine - sets the cpu parser to address 0
 */
    public void ResetMachine()
    {
        Globals.reset = true;
        return;
    }

/**
 * Pauses the whole machine
 */
    public void PauseMachine()
    {
        Globals.pause = !Globals.pause;
    }
    

   /**
    * Loads the Spectrum ROM.
    */
    public void LoadROM()
    {
        RAMLoadSaveFile.LoadROM(ram);
    }
        //end of class
    }
}

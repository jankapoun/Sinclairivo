using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.Remoting.Contexts;

namespace Sinclairivo.NET
{
    /**
     * VRAM class, represents the ZXS screen and VRAM
    * @author Jan Kapoun, Mgr.
    */
    
    public class VRAM
    {


/*
 * BufferedImage - image representing the ZXS screen/video ram
 * WritableRaster - a special object encapsulating the actual VRAM data
 * VRAMdata - the actual VRAM data in RGB values (3 bytes per pixel)
 * ram - object that provides access to the RAM
 * IsFlash - signal, should the blinking attributes be redrawn?
 * flashPeriod - flash frequency
 */
    
  
  Bitmap ZXScreen = new Bitmap(256, 192, PixelFormat.Format24bppRgb);
  public Graphics gScreen; //object Graphics, ktery je zodpovedny za zobrazovani hlavniho screenu

  public MainWnd mainWindow;
  public byte[] VRAMdata = new byte[256 * 192 * 3];
       
  int bytes = 256 * 192 * 3;
  private RAM ram;
  private Ports ports;
  private bool IsFlash;   //signal, zda se maji prekreslit blikajici atributy
  private int flashPeriod;   //sem se uklada pocet preruseni, aby se vedelo, kdy se ma bliknout

  private Color DarkWhite = Color.FromArgb(220, 220, 220);
  private Color DarkYellow = Color.FromArgb(220, 220, 7);
  private Color cyan = Color.FromArgb(18, 200, 220);
  private Color green = Color.FromArgb(45, 200, 17);
  private Color magenta = Color.FromArgb(234, 16, 239);
  private Color red = Color.FromArgb(16, 16, 200);
  private Color blue = Color.FromArgb(200, 24, 13);
  

  Rectangle rect = new Rectangle(0, 0, 256, 192);
  System.Drawing.Imaging.BitmapData bmpData; 

  
/**
 * Creates a new instance of VRAM
 */ 
  public VRAM(MainWnd mainWindow, RAM ram, Ports ports)
  {
        this.mainWindow = mainWindow;
        if (Graphics.FromHwnd(mainWindow.Handle) == null) { MessageBox.Show("No window graphics handler found!"); }
        gScreen = Graphics.FromHwnd(mainWindow.Handle); //save graphics object
        this.ram = ram;
        this.ports = ports;
        LaunchScreenRefresh();
  }
  
  
/*
 * Draws the video pixel data according to the RAM content
 */
  public void WritePxlsToVRAM(int addr, int b)
  {
      VRAMDrawByte(addr, b);
  }

/*
 * Colors the video pixel data with the accorging RAM attributes
 */
  public void WriteAttribsToVRAM(int addr, int b)
  {
      VRAMDrawByteAccordToAttrbs(addr);
  }
  
/*
 * Copies the VRAMdata into the WritableRaster and
 * draws the VRAM to the screen
 */
 private void DrawVRAM()
 {
     
            bmpData = ZXScreen.LockBits(rect, System.Drawing.Imaging.ImageLockMode.ReadWrite,
            ZXScreen.PixelFormat);
            

            // Get the address of the first line.
            IntPtr ptr = bmpData.Scan0;
            

            // Copy the RGB values back to the bitmap

            System.Runtime.InteropServices.Marshal.Copy(VRAMdata, 0, ptr, bytes);
            
            // Unlock the bits.
            ZXScreen.UnlockBits(bmpData);
            
            flashPeriod++;
            if (flashPeriod == 25) { flashPeriod = 0; VRAMFlash(); IsFlash = !IsFlash; }  //1/2 vteriny blikni

            try
            {
                gScreen.DrawImage(ZXScreen, 20, 70, this.gScreen.VisibleClipBounds.Width - 40,
                               this.gScreen.VisibleClipBounds.Height - 120);
            }
            catch (Exception e) { }
     
            SetBorder();
     
  }
 
  /**
   * Sets the color of border.
   */
  public void SetBorder()
  {
      if ((ports.border & 7) == 0) { mainWindow.BackColor = Color.Black; }
      if ((ports.border & 7) == 1) { mainWindow.BackColor = Color.DarkBlue; }
      if ((ports.border & 7) == 2) { mainWindow.BackColor = Color.DarkRed; }
      if ((ports.border & 7) == 3) { mainWindow.BackColor = Color.DarkMagenta; }
      if ((ports.border & 7) == 4) { mainWindow.BackColor = Color.DarkGreen; }
      if ((ports.border & 7) == 5) { mainWindow.BackColor = Color.DarkCyan; }
      if ((ports.border & 7) == 6) { mainWindow.BackColor = DarkYellow; }
      if ((ports.border & 7) == 7) { mainWindow.BackColor = DarkWhite; }
  
  }
  
 /*
 * Sets the individual pixel data in VRAMdata[]
 */ 
  private void SetPixel(int x, int y, Color clr)  
  {                                            
       int pointer = (y * 256 * 3) + (x * 3);
       VRAMdata[pointer] = clr.B;   //values stored in B, G, R order!
       VRAMdata[pointer + 1] = clr.G;
       VRAMdata[pointer + 2] = clr.R;
  }

 /*
 *  Tests the individual bits in a given byte and paints 
 *  dots (pixels) accordingly
 */ 
  private void VRAMDrawByte(int addr, int b)
  {
       
       AtbsAdrAndCoords AtbsAddressAndCoords = VRAMComputeXY(addr); //according to the given address, find the x, y coords and attribute address
       AttribsBunch AtbsColors = VRAMGetAttribs(AtbsAddressAndCoords.AttribsAdr);
       int x = AtbsAddressAndCoords.x;
       int y = AtbsAddressAndCoords.y;
       Color ink = AtbsColors.ink;
       Color paper = AtbsColors.paper;
       
       Color interm;           //stores values for flash
  
       //if the attribute is to be flashed now, exchange the paper and ink color
       if ((IsFlash == true) & (AtbsColors.flash == true)) { interm = ink; ink = paper; paper = interm; } 

       int shift = 0;         //x-axis shift for the individual dots to be painted
       if ((b & 128) != 0) { SetPixel(x, y, ink); }
       else { SetPixel(x, y, paper); }
       shift++;

       if ((b & 64) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 32) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 16) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 8) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 4) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 2) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
       shift++;

       if ((b & 1) != 0) { SetPixel(x + shift, y, ink); }
       else { SetPixel(x + shift, y, paper); }
   }
  
 /*
 *  This method is called to ensure flashing
 */ 
  private void VRAMFlash()
  {
       int addr = 22528;
       int b;

       for (int i = 0; i < 768; i++)
       {
           b = ram.ReadRAM(addr + i);
           if ((b & 128) == 128)
           {
               VRAMDrawByteAccordToAttrbs(addr + i);
           }
       }

  }

 /*
 *  Redraw pixels in 8x8 square so they correspond to their attributes
 */ 
  private void VRAMDrawByteAccordToAttrbs(int addr)
  {
            
            int pxlsAddr = 16384;
            addr = (addr - 22528);
            int x = (addr % 32);
            int y = (addr / 32);

            if (y < 8) { pxlsAddr = (16384 + (32 * y) + x); }
            else if (y < 16) 
            {
                y -= 8;     //korekce y pro prechod mezi tretinami
                pxlsAddr = (18432 + (32 * y) + x); 
            }
            else 
            {
                y -= 16;    //korekce y pro prechod mezi tretinami
                pxlsAddr = (20480 + (32 * y) + x); 
            }

            for (int i = 0; i < 2048; i = i + 256) //prekresli vsech 8 bytu
            {
                VRAMDrawByte((pxlsAddr + i),ram.ReadRAM((pxlsAddr + i)));
            }
        } 
  
  
/*
 *  Returns paper and ink colors, flash and bright (attributes)
 *  which are bound with a given pixel address
 */ 
  private AttribsBunch VRAMGetAttribs(int addr)
  {
       AttribsBunch abts = new AttribsBunch();
       int attribute = ram.ReadRAM(addr);

       int InkData = (attribute & 7);
       int PaperData = (attribute & 56);

       if ((attribute & 128) != 0) { abts.flash = true; } 
       else { abts.flash = false; }

       if ((attribute & 64) != 0) { abts.bright = true; } 
       else { abts.bright = false; }

       switch (InkData)
       {
                case 0:
                    abts.ink = Color.Black;
                    break;
                case 1:
                    if (abts.bright == true) abts.ink = Color.Blue;
                    else abts.ink = Color.DarkBlue;
                    break;
                case 2:
                    if (abts.bright == true) abts.ink = Color.Red;
                    else abts.ink = Color.DarkRed;
                    break;
                case 3:
                    if (abts.bright == true) abts.ink = Color.Magenta;
                    else abts.ink = Color.DarkMagenta;
                    break;
                case 4:
                    if (abts.bright == true) abts.ink = Color.Lime;
                    else abts.ink = Color.DarkGreen;
                    break;
                case 5:
                    if (abts.bright == true) abts.ink = Color.Cyan;
                    else abts.ink = Color.DarkCyan;
                    break;
                case 6:
                    if (abts.bright == true) abts.ink = Color.Yellow;
                    else abts.ink = DarkYellow;
                    break;
                case 7:
                    if (abts.bright == true) abts.ink = Color.White;
                    else abts.ink = DarkWhite;
                    break;
            }

            switch (PaperData)
            {
                case 0:
                    abts.paper = Color.Black;
                    break;
                case 8:
                    if (abts.bright == true) abts.paper = Color.Blue;
                    else abts.paper = Color.DarkBlue;
                    break;
                case 16:
                    if (abts.bright == true) abts.paper = Color.Red;
                    else abts.paper = Color.DarkRed;
                    break;
                case 24:
                    if (abts.bright == true) abts.paper = Color.Magenta;
                    else abts.paper = Color.DarkMagenta;
                    break;
                case 32:
                    if (abts.bright == true) abts.paper = Color.Lime;
                    else abts.paper = Color.DarkGreen;
                    break;
                case 40:
                    if (abts.bright == true) abts.paper = Color.Cyan;
                    else abts.paper = Color.DarkCyan;
                    break;
                case 48:
                    if (abts.bright == true) abts.paper = Color.Yellow;
                    else abts.paper = DarkYellow;
                    break;
                case 56:
                    if (abts.bright == true) abts.paper = Color.White;
                    else abts.paper = DarkWhite;
                    break;
            }
            return abts;
        }
  
  /*
 *  Object representing attribute values (colors) - ink, paper, bright and flash
 */ 
  private class AttribsBunch
  {
    public Color ink;
    public Color paper;
    public bool bright;
    public bool flash;
  }
  
  /*
 *  Returns an AtbsAdrAndCoords object with  x, y coords according to the 
 *  given VRAM address and also the address for attributes 
 */ 
  private AtbsAdrAndCoords VRAMComputeXY(int addr) 
  {
      int x, y;
      
      AtbsAdrAndCoords addressObj = new AtbsAdrAndCoords();
      
      addr = (addr - 16384);        //make the calculation more readable for humans...
      x = (addr % 32) * 8;
      int atribsX = addr % 32;
      int atribsY;
      int posY;
      int addLine;

      if (addr < 2048)
      {
          addLine = addr / 256; //o kolik se ma posunout na ose y od prvniho radku kazdeho 8mi radkoveho bloku
          addr = (addr - (256 * addLine));//uprav, pracovat budeme jen s prvnim radkem kazdeho 8mi radkoveho bloku, ten pak posuneme na ose y o vypocitany pocet radku
          posY = (addr / 32);
          y = posY * 8 + addLine;
          atribsY = posY;
      }
      else if (addr < 4096)
      {
          addr = (addr - 2048);
          addLine = addr / 256;
          addr = (addr - (256 * addLine));
          posY = (addr / 32);
          y = (posY * 8) + 64 + addLine;
          atribsY = (byte)(posY + 8);
       }
       else
       {
          addr = (addr - 4096);
          addLine = addr / 256;
          addr = (addr - (256 * addLine));
          posY = (addr / 32);
          y = (posY * 8) + 128 + addLine;
          atribsY = (posY + 16);
       }

        addressObj.x = x;
        addressObj.y = y;
        addressObj.AttribsAdr = (atribsY * 32 + atribsX + 22528);
        
        return addressObj;
    }
  
/**
 * Object representing x, y coords and attribute address
 */ 
  private class AtbsAdrAndCoords
  {
        public int x = 0;
        public int y = 0;
        public int AttribsAdr = 0;
    }

  /**
   * Refreshes VRAM, called every interrupt tick.
   */
    public void RefreshVRAM()
    {
        DrawVRAM();
    }
  
 /*
 * Launches an independent thread to refresh the screen 1/50 sec.
 */ 
  public void LaunchScreenRefresh()
  {
      Thread refreshThr = new Thread(this.refreshScreen);
      refreshThr.Name = "refresh thread";
      refreshThr.IsBackground = true;
      refreshThr.Start();
        
  }
 
    /**
    * Refreshes VRAM on an independent thread. 
    */ 
        public void refreshScreen()
        {
            while (true)
            {
                Globals.paintingInProgress = true;
                flashPeriod++;
                if (flashPeriod == Globals.FlashFrequency)  //flash every 1/2 sec
                { 
                    flashPeriod = 0; 
                    VRAMFlash(); 
                    IsFlash = !IsFlash; 
                }
                DrawVRAM();
                Globals.paintingInProgress = false;
                
                try{Thread.Sleep(Globals.ScreenRefreshFrequency);}
                catch(Exception e){ MessageBox.Show(e.Message);}
            }
           
        }
  
        //end of class
    }
}

namespace Sinclairivo.NET
{
    partial class MainWnd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainWnd));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.load1Menu = new System.Windows.Forms.ToolStripMenuItem();
            this.load2Menu = new System.Windows.Forms.ToolStripMenuItem();
            this.resetMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.kempstonMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.archiveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highwayMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.alienMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.extremeMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.exolonMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ikariMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.eaglesMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.stuntMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tetrisMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.tomahawkMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.eclipseMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.eclipse2Menu = new System.Windows.Forms.ToolStripMenuItem();
            this.chessmasterMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.resetBtn = new System.Windows.Forms.ToolStripButton();
            this.pauseBtn = new System.Windows.Forms.ToolStripButton();
            this.rom1Btn = new System.Windows.Forms.ToolStripButton();
            this.rom2Btn = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.archiveToolStripMenuItem,
            this.aboutProgram});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(292, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.load1Menu,
            this.load2Menu,
            this.resetMenu,
            this.toolStripSeparator2,
            this.kempstonMenu,
            this.toolStripSeparator1,
            this.exitMenu});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // load1Menu
            // 
            this.load1Menu.Name = "load1Menu";
            this.load1Menu.Size = new System.Drawing.Size(226, 22);
            this.load1Menu.Text = "Load ZX ROM #1 (Standard)";
            this.load1Menu.Click += new System.EventHandler(this.rom1Btn_Click);
            // 
            // load2Menu
            // 
            this.load2Menu.Name = "load2Menu";
            this.load2Menu.Size = new System.Drawing.Size(226, 22);
            this.load2Menu.Text = "Load ZX ROM #2 (Modified)";
            this.load2Menu.Click += new System.EventHandler(this.rom2Btn_Click);
            // 
            // resetMenu
            // 
            this.resetMenu.Name = "resetMenu";
            this.resetMenu.Size = new System.Drawing.Size(226, 22);
            this.resetMenu.Text = "Reset ZX Spectrum";
            this.resetMenu.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(223, 6);
            // 
            // kempstonMenu
            // 
            this.kempstonMenu.CheckOnClick = true;
            this.kempstonMenu.Name = "kempstonMenu";
            this.kempstonMenu.Size = new System.Drawing.Size(226, 22);
            this.kempstonMenu.Text = "Map cursor keys to Kempston";
            this.kempstonMenu.Click += new System.EventHandler(this.kempstonMenu_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(223, 6);
            // 
            // exitMenu
            // 
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(226, 22);
            this.exitMenu.Text = "Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // archiveToolStripMenuItem
            // 
            this.archiveToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.highwayMenu,
            this.alienMenu,
            this.extremeMenu,
            this.exolonMenu,
            this.ikariMenu,
            this.eaglesMenu,
            this.stuntMenu,
            this.tetrisMenu,
            this.tomahawkMenu,
            this.eclipseMenu,
            this.eclipse2Menu,
            this.chessmasterMenu});
            this.archiveToolStripMenuItem.Name = "archiveToolStripMenuItem";
            this.archiveToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.archiveToolStripMenuItem.Text = "Archive";
            // 
            // highwayMenu
            // 
            this.highwayMenu.Name = "highwayMenu";
            this.highwayMenu.Size = new System.Drawing.Size(178, 22);
            this.highwayMenu.Text = "Highway Encounter";
            this.highwayMenu.Click += new System.EventHandler(this.highwayMenu_Click);
            // 
            // alienMenu
            // 
            this.alienMenu.Name = "alienMenu";
            this.alienMenu.Size = new System.Drawing.Size(178, 22);
            this.alienMenu.Text = "Alien Encounter";
            this.alienMenu.Click += new System.EventHandler(this.alienMenu_Click);
            // 
            // extremeMenu
            // 
            this.extremeMenu.Name = "extremeMenu";
            this.extremeMenu.Size = new System.Drawing.Size(178, 22);
            this.extremeMenu.Text = "Extreme";
            this.extremeMenu.Click += new System.EventHandler(this.extremeMenu_Click);
            // 
            // exolonMenu
            // 
            this.exolonMenu.Name = "exolonMenu";
            this.exolonMenu.Size = new System.Drawing.Size(178, 22);
            this.exolonMenu.Text = "Exolon";
            this.exolonMenu.Click += new System.EventHandler(this.exolonMenu_Click);
            // 
            // ikariMenu
            // 
            this.ikariMenu.Name = "ikariMenu";
            this.ikariMenu.Size = new System.Drawing.Size(178, 22);
            this.ikariMenu.Text = "Ikari Warriors";
            this.ikariMenu.Click += new System.EventHandler(this.ikariMenu_Click);
            // 
            // eaglesMenu
            // 
            this.eaglesMenu.Name = "eaglesMenu";
            this.eaglesMenu.Size = new System.Drawing.Size(178, 22);
            this.eaglesMenu.Text = "Eagle\'s Nest";
            this.eaglesMenu.Click += new System.EventHandler(this.eaglesMenu_Click);
            // 
            // stuntMenu
            // 
            this.stuntMenu.Name = "stuntMenu";
            this.stuntMenu.Size = new System.Drawing.Size(178, 22);
            this.stuntMenu.Text = "Stunt Car Racer";
            this.stuntMenu.Click += new System.EventHandler(this.stuntMenu_Click);
            // 
            // tetrisMenu
            // 
            this.tetrisMenu.Name = "tetrisMenu";
            this.tetrisMenu.Size = new System.Drawing.Size(178, 22);
            this.tetrisMenu.Text = "Tetris";
            this.tetrisMenu.Click += new System.EventHandler(this.tetrisMenu_Click);
            // 
            // tomahawkMenu
            // 
            this.tomahawkMenu.Name = "tomahawkMenu";
            this.tomahawkMenu.Size = new System.Drawing.Size(178, 22);
            this.tomahawkMenu.Text = "Tomahawk";
            this.tomahawkMenu.Click += new System.EventHandler(this.tomahawkMenu_Click);
            // 
            // eclipseMenu
            // 
            this.eclipseMenu.Name = "eclipseMenu";
            this.eclipseMenu.Size = new System.Drawing.Size(178, 22);
            this.eclipseMenu.Text = "Total Eclipse";
            this.eclipseMenu.Click += new System.EventHandler(this.eclipseMenu_Click);
            // 
            // eclipse2Menu
            // 
            this.eclipse2Menu.Name = "eclipse2Menu";
            this.eclipse2Menu.Size = new System.Drawing.Size(178, 22);
            this.eclipse2Menu.Text = "Total Eclipse 2";
            this.eclipse2Menu.Click += new System.EventHandler(this.eclipse2Menu_Click);
            // 
            // chessmasterMenu
            // 
            this.chessmasterMenu.Name = "chessmasterMenu";
            this.chessmasterMenu.Size = new System.Drawing.Size(178, 22);
            this.chessmasterMenu.Text = "Chessmaster";
            this.chessmasterMenu.Click += new System.EventHandler(this.chessmasterMenu_Click);
            // 
            // aboutProgram
            // 
            this.aboutProgram.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutMenu});
            this.aboutProgram.Name = "aboutProgram";
            this.aboutProgram.Size = new System.Drawing.Size(48, 20);
            this.aboutProgram.Text = "About";
            // 
            // aboutMenu
            // 
            this.aboutMenu.Name = "aboutMenu";
            this.aboutMenu.Size = new System.Drawing.Size(157, 22);
            this.aboutMenu.Text = "About program";
            this.aboutMenu.Click += new System.EventHandler(this.aboutProgramToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetBtn,
            this.pauseBtn,
            this.rom1Btn,
            this.rom2Btn,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(292, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // resetBtn
            // 
            this.resetBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.resetBtn.Image = ((System.Drawing.Image)(resources.GetObject("resetBtn.Image")));
            this.resetBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(23, 22);
            this.resetBtn.Text = "Reset";
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // pauseBtn
            // 
            this.pauseBtn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pauseBtn.Image = ((System.Drawing.Image)(resources.GetObject("pauseBtn.Image")));
            this.pauseBtn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pauseBtn.Name = "pauseBtn";
            this.pauseBtn.Size = new System.Drawing.Size(23, 22);
            this.pauseBtn.Text = "Pause";
            this.pauseBtn.Click += new System.EventHandler(this.pauseBtn_Click);
            // 
            // rom1Btn
            // 
            this.rom1Btn.Image = ((System.Drawing.Image)(resources.GetObject("rom1Btn.Image")));
            this.rom1Btn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.rom1Btn.Name = "rom1Btn";
            this.rom1Btn.Size = new System.Drawing.Size(64, 22);
            this.rom1Btn.Text = "ROM#1";
            this.rom1Btn.Click += new System.EventHandler(this.rom1Btn_Click);
            // 
            // rom2Btn
            // 
            this.rom2Btn.Image = ((System.Drawing.Image)(resources.GetObject("rom2Btn.Image")));
            this.rom2Btn.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.rom2Btn.Name = "rom2Btn";
            this.rom2Btn.Size = new System.Drawing.Size(64, 22);
            this.rom2Btn.Text = "ROM#2";
            this.rom2Btn.Click += new System.EventHandler(this.rom2Btn_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.aboutProgramToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 244);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.statusStrip1.Size = new System.Drawing.Size(292, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(248, 17);
            this.toolStripStatusLabel1.Text = "(c) 2008 Jan Kapoun, University of South Bohemia";
            // 
            // MainWnd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 266);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainWnd";
            this.Text = "Sinclairivo .NET";
            this.Load += new System.EventHandler(this.MainWnd_Load);
            this.Shown += new System.EventHandler(this.MainWnd_Shown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainWnd_KeyUp);
            this.Resize += new System.EventHandler(this.MainWnd_Resize);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainWnd_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem archiveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutProgram;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripButton resetBtn;
        private System.Windows.Forms.ToolStripButton rom1Btn;
        private System.Windows.Forms.ToolStripButton rom2Btn;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem load1Menu;
        private System.Windows.Forms.ToolStripMenuItem load2Menu;
        private System.Windows.Forms.ToolStripMenuItem resetMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.ToolStripMenuItem highwayMenu;
        private System.Windows.Forms.ToolStripMenuItem extremeMenu;
        private System.Windows.Forms.ToolStripMenuItem ikariMenu;
        private System.Windows.Forms.ToolStripMenuItem eaglesMenu;
        private System.Windows.Forms.ToolStripMenuItem stuntMenu;
        private System.Windows.Forms.ToolStripMenuItem tomahawkMenu;
        private System.Windows.Forms.ToolStripMenuItem eclipseMenu;
        private System.Windows.Forms.ToolStripMenuItem chessmasterMenu;
        private System.Windows.Forms.ToolStripMenuItem aboutMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem kempstonMenu;
        private System.Windows.Forms.ToolStripButton pauseBtn;
        private System.Windows.Forms.ToolStripMenuItem alienMenu;
        private System.Windows.Forms.ToolStripMenuItem exolonMenu;
        private System.Windows.Forms.ToolStripMenuItem tetrisMenu;
        private System.Windows.Forms.ToolStripMenuItem eclipse2Menu;

    }
}


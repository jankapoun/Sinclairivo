using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Sinclairivo.NET
{
    public partial class MainWnd : Form
    {
        private ZXMachine zxmachine;

        public MainWnd()
        {
            InitializeComponent();
        }

        private void MainWnd_Resize(object sender, EventArgs e)
        {
         
            if (zxmachine != null)
            {
                zxmachine.ram.vram.gScreen = Graphics.FromHwnd(this.Handle);
                this.Refresh();
            }
        }

        private void MainWnd_Shown(object sender, EventArgs e)
        {
            this.Width = 400;
            this.Height = 400;
            zxmachine = new ZXMachine(this);
            zxmachine.ResetMachine();
            
            Thread thr = new Thread(new ThreadStart(LaunchMachine));
            thr.IsBackground = true;
            thr.Start();
        }

        
        private void MainWnd_KeyDown(object sender, KeyEventArgs e)
        {
            zxmachine.kbd.KeyDown(e.KeyCode.ToString());

            
        }

        private void MainWnd_KeyUp(object sender, KeyEventArgs e)
        {
            zxmachine.kbd.KeyUp(e.KeyCode.ToString());
        }

        private void LaunchMachine()
        {
            for (int i = 0; i < 700000; i++)
            {
                zxmachine.LaunchMachineCode(1);
            }

            Thread.Sleep(500);
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.highway_encounter, zxmachine);
            
            while (true)
            {
                zxmachine.LaunchMachineCode(1);
            }
        }

        private void resetBtn_Click(object sender, EventArgs e)
        {
            zxmachine.ResetMachine();
        }

        private void rom1Btn_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadROM(global::Sinclairivo.NET.Properties.Resources.zx_spectrum_ROM,
                zxmachine.ram);
            zxmachine.ResetMachine();

        }

        private void rom2Btn_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadROM(global::Sinclairivo.NET.Properties.Resources.zx_spectrum_ROM_modified, 
                zxmachine.ram);
            zxmachine.ResetMachine();
        }

        private void highwayMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.highway_encounter, zxmachine);
        }

        private void extremeMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.extreme, zxmachine);
        }

        private void ikariMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.ikari_warriors, zxmachine);
        }

        private void eaglesMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.into_the_eagles_nest, zxmachine);
        }

        private void stuntMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.stunt_car_racer, zxmachine);
        }

        private void tomahawkMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.tomahawk, zxmachine);
        }

        private void eclipseMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.total_eclipse, zxmachine);
        }

        private void chessmasterMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.chessmaster, zxmachine);
        }

        private void pauseBtn_Click(object sender, EventArgs e)
        {
            zxmachine.PauseMachine();
        }

        private void alienMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.highway_encounter_2, zxmachine);
        }

        private void exolonMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.exolon, zxmachine);
        }

        private void tetrisMenu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.tetris, zxmachine);
        }

        private void eclipse2Menu_Click(object sender, EventArgs e)
        {
            RAMLoadSaveFile.LoadSnapShot(global::Sinclairivo.NET.Properties.Resources.total_eclipse_2, zxmachine);
        }

        private void kempstonMenu_Click(object sender, EventArgs e)
        {
            Globals.mapCursorAsKempston = !Globals.mapCursorAsKempston;
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainWnd_Load(object sender, EventArgs e)
        {

        }

        private void aboutProgramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox aBox = new AboutBox();
            aBox.ShowDialog();
        }


    }
}
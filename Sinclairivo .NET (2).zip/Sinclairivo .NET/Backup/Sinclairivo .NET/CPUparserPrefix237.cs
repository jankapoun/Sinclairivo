using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{
    /*
     * Parses instructions following a prefix code.
     * 
     */
    public class CPUparserPrefix237
    {


        private CPUroutines cpu;
        private Registers Registers;
        private int code;

        public CPUparserPrefix237(CPUroutines cpu, Registers Registers)
        {
            this.cpu = cpu;
            this.Registers = Registers;
        }

        public void Parse()
        {
            cpu.Refresh_R();
            code = cpu.Fetch();

            switch (code)
            {
                case 67:  /* LD (nn),BC*/
                    {
                        cpu.LD_MEM_REG16(Registers.regBC, 20);
                    }
                    break;

                case 83:  /* LD (nn),DE*/
                    {
                        cpu.LD_MEM_REG16(Registers.regDE, 20);
                    }
                    break;

                case 115:  /* LD (nn),SP*/
                    {
                        cpu.LD_MEM_REG16(Registers.regSP, 20);
                    }
                    break;

                case 99:  /* LD (nn),HL - longer version*/
                    {
                        cpu.LD_MEM_REG16(Registers.regHL, 20);
                    }
                    break;

                case 107:  /* LD HL,(nn) - longer version*/
                    {
                        cpu.LD_REG16_FromWherePointsOp(Registers.regHL, 20);
                    }
                    break;

                case 75:  /* LD BC,(nn)*/
                    {
                        cpu.LD_REG16_FromWherePointsOp(Registers.regBC, 20);
                    }
                    break;

                case 91:  /* LD DE,(nn)*/
                    {
                        cpu.LD_REG16_FromWherePointsOp(Registers.regDE, 20);
                    }
                    break;

                case 123:  /* LD SP,(nn)*/
                    {
                        cpu.LD_REG16_FromWherePointsOp(Registers.regSP, 20);
                    }
                    break;

                case 71:  /* LD I,A */
                    {
                        cpu.LD_I_R_A(Registers.regI, Registers.regA);
                    }
                    break;

                case 79:  /* LD R,A */
                    {
                        cpu.LD_I_R_A(Registers.regR, Registers.regA);
                    }
                    break;

                case 87:  /* LD A,I */
                    {
                        cpu.LD_A_I_R(Registers.regA, Registers.regI);
                    }
                    break;

                case 95:  /* LD A,R */
                    {
                        cpu.LD_A_I_R(Registers.regA, Registers.regR);
                    }
                    break;

                case 103:  /* RRD */
                    {
                        cpu.RRD();
                    }
                    break;

                case 111:  /* RLD */
                    {
                        cpu.RLD();
                    }
                    break;

                case 70:  /* IM 0 */
                    {
                        cpu.im(0);
                    }
                    break;

                case 86:  /* IM 1 */
                    {
                        cpu.im(1);
                    }
                    break;

                case 94:  /* IM 2 */
                    {
                        cpu.im(2);
                    }
                    break;

                case 68:  /* NEG */
                case 76:  /* NEG */
                case 84:  /* NEG */
                case 92:  /* NEG */
                case 100:  /* NEG */
                case 108:  /* NEG */
                case 116:  /* NEG */
                case 124:  /* NEG */
                    {
                        cpu.NEG();
                    }
                    break;

                case 77:  /* RETI */
                case 93:  /* RETI */
                case 109:  /* RETI */
                case 125:  /* RETI */
                    {
                        cpu.RETI();
                    }
                    break;

                /* RETN */
                case 69:  /* RETN */
                case 85:  /* RETN */
                case 101:  /* RETN */
                case 117:  /* RETN */
                    {
                        cpu.RETN();
                    }
                    break;

                case 64:  /* IN B,(c) */
                    {
                        cpu.IN(Registers.regB, Registers.regBC);
                    }
                    break;

                case 72:  /* IN C,(c) */
                    {
                        cpu.IN(Registers.regC, Registers.regBC);
                    }
                    break;

                case 80:  /* IN D,(c) */
                    {
                        cpu.IN(Registers.regD, Registers.regBC);
                    }
                    break;

                case 88:  /* IN E,(c) */
                    {
                        cpu.IN(Registers.regE, Registers.regBC);
                    }
                    break;

                case 96:  /* IN H,(c) */
                    {
                        cpu.IN(Registers.regH, Registers.regBC);
                    }
                    break;

                case 104:  /* IN L,(c) */
                    {
                        cpu.IN(Registers.regL, Registers.regBC);
                    }
                    break;

                case 120:  /* IN A,(c) */
                    {
                        cpu.IN(Registers.regA, Registers.regBC);
                    }
                    break;

                /* OUT (c),r */
                case 65:  /* OUT (c),B */
                    {
                        cpu.OUT(Registers.regBC, Registers.regB);
                    }
                    break;

                case 73:  /* OUT (c),C */
                    {
                        cpu.OUT(Registers.regBC, Registers.regC);
                    }
                    break;

                case 81:  /* OUT (c),D */
                    {
                        cpu.OUT(Registers.regBC, Registers.regD);
                    }
                    break;

                case 89:  /* OUT (c),E */
                    {
                        cpu.OUT(Registers.regBC, Registers.regE);
                    }
                    break;

                case 97:  /* OUT (c),H */
                    {
                        cpu.OUT(Registers.regBC, Registers.regH);
                    }
                    break;

                case 105:  /* OUT (c),L */
                    {
                        cpu.OUT(Registers.regBC, Registers.regL);
                    }
                    break;

                case 113:  /* OUT (c),0 */
                    {
                        // ??? cpu.OUT(Registers.regBC, Registers.regB);
                    }
                    break;

                case 121:  /* OUT (c),A */
                    {
                        cpu.OUT(Registers.regBC, Registers.regA);
                    }
                    break;

                case 162:  /* INI */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 163:  /* OUTI */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 170:  /* IND */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 171:  /* OUTD */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 178:  /* INIR */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 179:  /* OTIR */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 186:  /* INDR */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 187:  /* OTDR */
                    {
                        cpu.NotImplemented(code);
                    }
                    break;

                case 74: /*ADC HL,BC*/
                    {
                        cpu.ADC(Registers.regHL, Registers.regBC);
                    }
                    break;

                case 90: /*ADC HL,DE*/
                    {
                        cpu.ADC(Registers.regHL, Registers.regDE);
                    }
                    break;

                case 106: /*ADC HL,HL*/
                    {
                        cpu.ADC(Registers.regHL, Registers.regHL);
                    }
                    break;

                case 122: /*ADC HL,SP*/
                    {
                        cpu.ADC(Registers.regHL, Registers.regSP);
                    }
                    break;

                case 66: /*SBC HL,BC*/
                    {
                        cpu.SBC(Registers.regHL, Registers.regBC);
                    }
                    break;

                case 82: /*SBC HL,DE*/
                    {
                        cpu.SBC(Registers.regHL, Registers.regDE);
                    }
                    break;

                case 98: /*SBC HL,HL*/
                    {
                        cpu.SBC(Registers.regHL, Registers.regHL);
                    }
                    break;

                case 114: /*SBC HL,SP*/
                    {
                        cpu.SBC(Registers.regHL, Registers.regSP);
                    }
                    break;

                case 160:  /* LDI */
                    {
                        cpu.LDI();
                    }
                    break;

                case 168:  /* LDD */
                    {
                        cpu.LDD();
                    }
                    break;

                case 176:  /* LDIR */
                    {
                        cpu.LDIR();
                    }
                    break;

                case 184:  /* LDDR */
                    {
                        cpu.LDDR();
                    }
                    break;

                case 161:  /* CPI */
                    {
                        cpu.CPI();
                    }
                    break;

                case 169:  /* CPD */
                    {
                        cpu.CPD();
                    }
                    break;

                case 177:  /* CPIR */ //ma zvlastni chovani flagu!!!
                    {
                        cpu.CPIR();
                    }
                    break;

                case 185:  /* CPDR */
                    {
                        cpu.CPDR();
                    }
                    break;

                default:
                    {
                        MessageBox.Show("Prefix 237, instruction not supported, code: " + code + ", address: " + Registers.regPC.Get());
                    }
                    break;

            }
        }


        //end of class
    }
}

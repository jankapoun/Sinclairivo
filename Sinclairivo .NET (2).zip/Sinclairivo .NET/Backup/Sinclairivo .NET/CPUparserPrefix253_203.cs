using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{
/**
 * Parses instructions following the 253 203 prefix codes
 * 
 */
    class CPUparserPrefix253_203
    {


            private CPUroutines cpu;
            private Registers Registers;
            private int code;

            public CPUparserPrefix253_203(CPUroutines cpu, Registers Registers)
            {
                this.cpu = cpu;
                this.Registers = Registers;
            }

            public void Parse()
            {
                cpu.Refresh_R(); //obnov R registr

                /*  16bit index operation instructions have 2 prefixes. In a 4byte instruction, 
                 *  the actual instruction code lies as the last one, the shift code
                 *  lies on the 3rd place.
                 */
                cpu.IgnoreByte();   //skip the index shift
                code = cpu.Fetch();

                switch (code)
                {

                    case 22: /*RL (IY + N)*/
                        {
                            cpu.RL_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 6: /*RLC (IY + N)*/
                        {
                            cpu.RLC_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 14: /*RRC (IY + N)*/
                        {
                            cpu.RRC_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 30: /*RR (IY + N)*/
                        {
                            cpu.RR_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 38: /*SLA (IY + N)*/
                        {
                            cpu.SLA_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 46: /*SRA (IY + N)*/
                        {
                            cpu.SRL_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 54: /*SLL (IY + N)*/
                        {
                            cpu.SLIA_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    case 62: /*SRL (IY + N)*/
                        {
                            cpu.SRL_OnWherePointsIndexReg(Registers.regIY);
                        }
                        break;

                    /**
                     *  BIT N,N 
                     */
                    case 70: /*BIT 0,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 0);
                        }
                        break;

                    case 78: /*BIT 1,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 1);
                        }
                        break;

                    case 86: /*BIT 2,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 2);
                        }
                        break;

                    case 94: /*BIT 3,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 3);
                        }
                        break;

                    case 102: /*BIT 4,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 4);
                        }
                        break;

                    case 110: /*BIT 5,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 5);
                        }
                        break;

                    case 118: /*BIT 6,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 6);
                        }
                        break;

                    case 126: /*BIT 7,(IY + N)*/
                        {
                            cpu.BIT_OnWherePointsIndexReg(Registers.regIY, 7);
                        }
                        break;

                    /**
                     *  SET N,N 
                     */
                    case 198: /*SET 0,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 0);
                        }
                        break;

                    case 206: /*SET 1,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 1);
                        }
                        break;

                    case 214: /*SET 2,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 2);
                        }
                        break;

                    case 222: /*SET 3,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 3);
                        }
                        break;

                    case 230: /*SET 4,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 4);
                        }
                        break;

                    case 238: /*SET 5,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 5);
                        }
                        break;

                    case 246: /*SET 6,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 6);
                        }
                        break;

                    case 254: /*SET 7,(IY + N)*/
                        {
                            cpu.SET_OnWherePointsIndexReg(Registers.regIY, 7);
                        }
                        break;

                    /**
                     *  RES N,N 
                     */
                    case 134: /*RES 0,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 0);
                        }
                        break;

                    case 142: /*RES 1,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 1);
                        }
                        break;

                    case 150: /*RES 2,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 2);
                        }
                        break;

                    case 158: /*RES 3,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 3);
                        }
                        break;

                    case 166: /*RES 4,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 4);
                        }
                        break;

                    case 174: /*RES 5,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 5);
                        }
                        break;

                    case 182: /*RES 6,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 6);
                        }
                        break;

                    case 190: /*RES 7,(IY + N)*/
                        {
                            cpu.RES_OnWherePointsIndexReg(Registers.regIY, 7);
                        }
                        break;

                    default:
                        {
                            MessageBox.Show("Prefix 253_203, instruction not supported, code: " + code + ", address: " + Registers.regPC);
                        }
                        break;
                }
            }

        

        //end of class
    }
}

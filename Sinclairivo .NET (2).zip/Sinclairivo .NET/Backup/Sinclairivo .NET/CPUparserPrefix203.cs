using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;


namespace Sinclairivo.NET
{
    /*
     * Parses instructions following the 203 prefix code.
     * 
     */
    class CPUparserPrefix203
    {


        private CPUroutines cpu;
        private Registers Registers;
        private int code;

        public CPUparserPrefix203(CPUroutines cpu, Registers Registers)
        {
            this.cpu = cpu;
            this.Registers = Registers;
        }

        public void Parse()
        {
            cpu.Refresh_R(); //obnov R registr
            code = cpu.Fetch();

            switch (code)
            {

                case 0:	/* RLC B */
                    {
                        cpu.RLC(Registers.regB);
                    }
                    break;

                case 1:	/* RLC C */
                    {
                        cpu.RLC(Registers.regC);
                    }
                    break;

                case 2:	/* RLC D */
                    {
                        cpu.RLC(Registers.regD);
                    }
                    break;

                case 3:	/* RLC E */
                    {
                        cpu.RLC(Registers.regE);
                    }
                    break;

                case 4:	/* RLC H */
                    {
                        cpu.RLC(Registers.regH);
                    }
                    break;

                case 5:	/* RLC L */
                    {
                        cpu.RLC(Registers.regL);
                    }
                    break;

                case 6:	/* RLC (HL) */
                    {
                        cpu.RLC_OnWherePointsHL();
                    }
                    break;

                case 7:	/* RLC A */
                    {
                        cpu.RLC(Registers.regA);
                    }
                    break;

                case 16:	/* RL B */
                    {
                        cpu.RL(Registers.regB);
                    }
                    break;

                case 17:	/* RL C */
                    {
                        cpu.RL(Registers.regC);
                    }
                    break;

                case 18:	/* RL D */
                    {
                        cpu.RL(Registers.regD);
                    }
                    break;

                case 19:	/* RL E */
                    {
                        cpu.RL(Registers.regE);
                    }
                    break;

                case 20:	/* RL H */
                    {
                        cpu.RL(Registers.regH);
                    }
                    break;

                case 21:	/* RL L */
                    {
                        cpu.RL(Registers.regL);
                    }
                    break;

                case 22:	/* RL (HL) */
                    {
                        cpu.RL_OnWherePointsHL();
                    }
                    break;

                case 23:	/* RL A */
                    {
                        cpu.RL(Registers.regA);
                    }
                    break;

                case 8:	/* RRC B */
                    {
                        cpu.RRC(Registers.regB);
                    }
                    break;

                case 9:	/* RRC C */
                    {
                        cpu.RRC(Registers.regC);
                    }
                    break;

                case 10:	/* RRC D */
                    {
                        cpu.RRC(Registers.regD);
                    }
                    break;

                case 11:	/* RRC E */
                    {
                        cpu.RRC(Registers.regE);
                    }
                    break;

                case 12:	/* RRC H */
                    {
                        cpu.RRC(Registers.regH);
                    }
                    break;

                case 13:	/* RRC L */
                    {
                        cpu.RRC(Registers.regL);
                    }
                    break;

                case 14:	/* RRC (HL) */
                    {
                        cpu.RRC_OnWherePointsHL();
                    }
                    break;

                case 15:	/* RRC A */
                    {
                        cpu.RRC(Registers.regA);
                    }
                    break;

                case 24:	/* RR B */
                    {
                        cpu.RR(Registers.regB);
                    }
                    break;

                case 25:	/* RR C */
                    {
                        cpu.RR(Registers.regC);
                    }
                    break;

                case 26:	/* RR D */
                    {
                        cpu.RR(Registers.regD);
                    }
                    break;

                case 27:	/* RR E */
                    {
                        cpu.RR(Registers.regE);
                    }
                    break;

                case 28:	/* RR H */
                    {
                        cpu.RR(Registers.regH);
                    }
                    break;

                case 29:	/* RR L */
                    {
                        cpu.RR(Registers.regL);
                    }
                    break;

                case 30:	/* RR (HL) */
                    {
                        cpu.RR_OnWherePointsHL();
                    }
                    break;

                case 31:	/* RR A */
                    {
                        cpu.RR(Registers.regA);
                    }
                    break;

                case 32:	/* SLA B */
                    {
                        cpu.SLA(Registers.regB);
                    }
                    break;

                case 33:	/* SLA C */
                    {
                        cpu.SLA(Registers.regC);
                    }
                    break;

                case 34:	/* SLA D */
                    {
                        cpu.SLA(Registers.regD);
                    }
                    break;

                case 35:	/* SLA E */
                    {
                        cpu.SLA(Registers.regE);
                    }
                    break;

                case 36:	/* SLA H */
                    {
                        cpu.SLA(Registers.regH);
                    }
                    break;

                case 37:	/* SLA L */
                    {
                        cpu.SLA(Registers.regL);
                    }
                    break;

                case 38:	/* SLA (HL) */
                    {
                        cpu.SLA_OnWherePointsHL();
                    }
                    break;

                case 39:	/* SLA A */
                    {
                        cpu.SLA(Registers.regA);
                    }
                    break;

                case 40:	/* SRA B */
                    {
                        cpu.SRA(Registers.regB);
                    }
                    break;

                case 41:	/* SRA C */
                    {
                        cpu.SRA(Registers.regC);
                    }
                    break;

                case 42:	/* SRA D */
                    {
                        cpu.SRA(Registers.regD);
                    }
                    break;

                case 43:	/* SRA E */
                    {
                        cpu.SRA(Registers.regE);
                    }
                    break;

                case 44:	/* SRA H */
                    {
                        cpu.SRA(Registers.regH);
                    }
                    break;

                case 45:	/* SRA L */
                    {
                        cpu.SRA(Registers.regL);
                    }
                    break;

                case 46:	/* SRA (HL) */
                    {
                        cpu.SRA_OnWherePointsHL();
                    }
                    break;

                case 47:	/* SRA A */
                    {
                        cpu.SRA(Registers.regA);
                    }
                    break;

                case 48:	/* SLIA B */
                    {
                        cpu.SLIA(Registers.regB);
                    }
                    break;

                case 49:	/* SLIA C */
                    {
                        cpu.SLIA(Registers.regC);
                    }
                    break;

                case 50:	/* SLIA D */
                    {
                        cpu.SLIA(Registers.regD);
                    }
                    break;

                case 51:	/* SLIA E */
                    {
                        cpu.SLIA(Registers.regE);
                    }
                    break;

                case 52:	/* SLIA H */
                    {
                        cpu.SLIA(Registers.regH);
                    }
                    break;

                case 53:	/* SLIA L */
                    {
                        cpu.SLIA(Registers.regL);
                    }
                    break;

                case 54:	/* SLIA (HL) */
                    {
                        cpu.SLIA_OnWherePointsHL();
                    }
                    break;

                case 55:	/* SLIA A */
                    {
                        cpu.SLIA(Registers.regA);
                    }
                    break;

                case 56:	/* SRL B */
                    {
                        cpu.SRL(Registers.regB);
                    }
                    break;

                case 57:	/* SRL C */
                    {
                        cpu.SRL(Registers.regC);
                    }
                    break;

                case 58:	/* SRL D */
                    {
                        cpu.SRL(Registers.regD);
                    }
                    break;

                case 59:	/* SRL E */
                    {
                        cpu.SRL(Registers.regE);
                    }
                    break;

                case 60:	/* SRL H */
                    {
                        cpu.SRL(Registers.regH);
                    }
                    break;

                case 61:	/* SRL L */
                    {
                        cpu.SRL(Registers.regL);
                    }
                    break;

                case 62:	/* SRL (HL) */
                    {
                        cpu.SRL_OnWherePointsHL();
                    }
                    break;

                case 63:	/* SRL A */
                    {
                        cpu.SRL(Registers.regA);
                    }
                    break;

                /*
                * BIT ops
                * 
                */
                case 64:	/* cpu.BIT 0,B */
                    {
                        cpu.BIT(Registers.regB, 0);
                    }
                    break;

                case 65:	/* cpu.BIT 0,C */
                    {
                        cpu.BIT(Registers.regC, 0);
                    }
                    break;

                case 66:	/* cpu.BIT 0,D */
                    {
                        cpu.BIT(Registers.regD, 0);
                    }
                    break;

                case 67:	/* cpu.BIT 0,E */
                    {
                        cpu.BIT(Registers.regE, 0);
                    }
                    break;

                case 68:	/* cpu.BIT 0,H */
                    {
                        cpu.BIT(Registers.regH, 0);
                    }
                    break;

                case 69:	/* cpu.BIT 0,L */
                    {
                        cpu.BIT(Registers.regL, 0);
                    }
                    break;

                case 70:	/* cpu.BIT 0,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(0);
                    }
                    break;

                case 71:	/* cpu.BIT 0,A */
                    {
                        cpu.BIT(Registers.regA, 0);
                    }
                    break;

                //************************************
                //cpu.BIT 1,N

                case 72:	/* cpu.BIT 1,B */
                    {
                        cpu.BIT(Registers.regB, 1);
                    }
                    break;

                case 73:	/* cpu.BIT 1,C */
                    {
                        cpu.BIT(Registers.regC, 1);
                    }
                    break;

                case 74:	/* cpu.BIT 1,D */
                    {
                        cpu.BIT(Registers.regD, 1);
                    }
                    break;

                case 75:	/* cpu.BIT 1,E */
                    {
                        cpu.BIT(Registers.regE, 1);
                    }
                    break;

                case 76:	/* cpu.BIT 1,H */
                    {
                        cpu.BIT(Registers.regH, 1);
                    }
                    break;

                case 77:	/* cpu.BIT 1,L */
                    {
                        cpu.BIT(Registers.regL, 1);
                    }
                    break;

                case 78:	/* cpu.BIT 1,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(1);
                    }
                    break;

                case 79:	/* cpu.BIT 1,A */
                    {
                        cpu.BIT(Registers.regA, 1);
                    }
                    break;

                //******************************************
                //cpu.BIT 2,N

                case 80:	/* cpu.BIT 2,B */
                    {
                        cpu.BIT(Registers.regB, 2);
                    }
                    break;

                case 81:	/* cpu.BIT 2,C */
                    {
                        cpu.BIT(Registers.regC, 2);
                    }
                    break;

                case 82:	/* cpu.BIT 2,D */
                    {
                        cpu.BIT(Registers.regD, 2);
                    }
                    break;

                case 83:	/* cpu.BIT 2,E */
                    {
                        cpu.BIT(Registers.regE, 2);
                    }
                    break;

                case 84:	/* cpu.BIT 2,H */
                    {
                        cpu.BIT(Registers.regH, 2);
                    }
                    break;

                case 85:	/* cpu.BIT 2,L */
                    {
                        cpu.BIT(Registers.regL, 2);
                    }
                    break;

                case 86:	/* cpu.BIT 2,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(2);
                    }
                    break;

                case 87:	/* cpu.BIT 2,A */
                    {
                        cpu.BIT(Registers.regA, 2);
                    }
                    break;

                //******************************************
                //cpu.BIT 3,N

                case 88:	/* cpu.BIT 3,B */
                    {
                        cpu.BIT(Registers.regB, 3);
                    }
                    break;

                case 89:	/* cpu.BIT 3,C */
                    {
                        cpu.BIT(Registers.regC, 3);
                    }
                    break;

                case 90:	/* cpu.BIT 3,D */
                    {
                        cpu.BIT(Registers.regD, 3);
                    }
                    break;

                case 91:	/* cpu.BIT 3,E */
                    {
                        cpu.BIT(Registers.regE, 3);
                    }
                    break;

                case 92:	/* cpu.BIT 3,H */
                    {
                        cpu.BIT(Registers.regH, 3);
                    }
                    break;

                case 93:	/* cpu.BIT 3,L */
                    {
                        cpu.BIT(Registers.regL, 3);
                    }
                    break;

                case 94:	/* cpu.BIT 3,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(3);
                    }
                    break;

                case 95:	/* cpu.BIT 3,A */
                    {
                        cpu.BIT(Registers.regA, 3);
                    }
                    break;

                //************************************
                //cpu.BIT 4,N

                case 96:	/* cpu.BIT 4,B */
                    {
                        cpu.BIT(Registers.regB, 4);
                    }
                    break;

                case 97:	/* cpu.BIT 4,C */
                    {
                        cpu.BIT(Registers.regC, 4);
                    }
                    break;

                case 98:	/* cpu.BIT 4,D */
                    {
                        cpu.BIT(Registers.regD, 4);
                    }
                    break;

                case 99:	/* cpu.BIT 4,E */
                    {
                        cpu.BIT(Registers.regE, 4);
                    }
                    break;

                case 100:	/* cpu.BIT 4,H */
                    {
                        cpu.BIT(Registers.regH, 4);
                    }
                    break;

                case 101:	/* cpu.BIT 4,L */
                    {
                        cpu.BIT(Registers.regL, 4);
                    }
                    break;

                case 102:	/* cpu.BIT 4,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(4);
                    }
                    break;

                case 103:	/* cpu.BIT 4,A */
                    {
                        cpu.BIT(Registers.regA, 4);
                    }
                    break;

                //************************************
                //cpu.BIT 5,N

                case 104:	/* cpu.BIT 5,B */
                    {
                        cpu.BIT(Registers.regB, 5);
                    }
                    break;

                case 105:	/* cpu.BIT 5,C */
                    {
                        cpu.BIT(Registers.regC, 5);
                    }
                    break;

                case 106:	/* cpu.BIT 5,D */
                    {
                        cpu.BIT(Registers.regD, 5);
                    }
                    break;

                case 107:	/* cpu.BIT 5,E */
                    {
                        cpu.BIT(Registers.regE, 5);
                    }
                    break;

                case 108:	/* cpu.BIT 5,H */
                    {
                        cpu.BIT(Registers.regH, 5);
                    }
                    break;

                case 109:	/* cpu.BIT 5,L */
                    {
                        cpu.BIT(Registers.regL, 5);
                    }
                    break;

                case 110:	/* cpu.BIT 5,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(5);
                    }
                    break;

                case 111:	/* cpu.BIT 5,A */
                    {
                        cpu.BIT(Registers.regA, 5);
                    }
                    break;

                //************************************
                //cpu.BIT 6,N

                case 112:	/* cpu.BIT 6,B */
                    {
                        cpu.BIT(Registers.regB, 6);
                    }
                    break;

                case 113:	/* cpu.BIT 6,C */
                    {
                        cpu.BIT(Registers.regC, 6);
                    }
                    break;

                case 114:	/* cpu.BIT 6,D */
                    {
                        cpu.BIT(Registers.regD, 6);
                    }
                    break;

                case 115:	/* cpu.BIT 6,E */
                    {
                        cpu.BIT(Registers.regE, 6);
                    }
                    break;

                case 116:	/* cpu.BIT 6,H */
                    {
                        cpu.BIT(Registers.regH, 6);
                    }
                    break;

                case 117:	/* cpu.BIT 6,L */
                    {
                        cpu.BIT(Registers.regL, 6);
                    }
                    break;

                case 118:	/* cpu.BIT 6,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(6);
                    }
                    break;

                case 119:	/* cpu.BIT 6,A */
                    {
                        cpu.BIT(Registers.regA, 6);
                    }
                    break;

                //************************************
                //cpu.BIT 7,N

                case 120:	/* cpu.BIT 7,B */
                    {
                        cpu.BIT(Registers.regB, 7);
                    }
                    break;

                case 121:	/* cpu.BIT 7,C */
                    {
                        cpu.BIT(Registers.regC, 7);
                    }
                    break;

                case 122:	/* cpu.BIT 7,D */
                    {
                        cpu.BIT(Registers.regD, 7);
                    }
                    break;

                case 123:	/* cpu.BIT 7,E */
                    {
                        cpu.BIT(Registers.regE, 7);
                    }
                    break;

                case 124:	/* cpu.BIT 7,H */
                    {
                        cpu.BIT(Registers.regH, 7);
                    }
                    break;

                case 125:	/* cpu.BIT 7,L */
                    {
                        cpu.BIT(Registers.regL, 7);
                    }
                    break;

                case 126:	/* cpu.BIT 7,(HL) */
                    {
                        cpu.BIT_OnWherePointsHL(7);
                    }
                    break;

                case 127:	/* cpu.BIT 7,A */
                    {
                        cpu.BIT(Registers.regA, 7);
                    }
                    break;

                //*************************************
                //SET 0,N

                case 192:	/* SET 0,B */
                    {
                        cpu.SET(Registers.regB, 0);
                    }
                    break;

                case 193:	/* SET 0,C */
                    {
                        cpu.SET(Registers.regC, 0);
                    }
                    break;

                case 194:	/* SET 0,D */
                    {
                        cpu.SET(Registers.regD, 0);
                    }
                    break;

                case 195:	/* SET 0,E */
                    {
                        cpu.SET(Registers.regE, 0);
                    }
                    break;

                case 196:	/* SET 0,H */
                    {
                        cpu.SET(Registers.regH, 0);
                    }
                    break;

                case 197:	/* SET 0,L */
                    {
                        cpu.SET(Registers.regL, 0);
                    }
                    break;

                case 198:	/* SET 0,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(0);
                    }
                    break;

                case 199:	/* SET 0,A */
                    {
                        cpu.SET(Registers.regA, 0);
                    }
                    break;

                //*************************************
                //SET 1,N

                case 200:	/* SET 1,B */
                    {
                        cpu.SET(Registers.regB, 1);
                    }
                    break;

                case 201:	/* SET 1,C */
                    {
                        cpu.SET(Registers.regC, 1);
                    }
                    break;

                case 202:	/* SET 1,D */
                    {
                        cpu.SET(Registers.regD, 1);
                    }
                    break;

                case 203:	/* SET 1,E */
                    {
                        cpu.SET(Registers.regE, 1);
                    }
                    break;

                case 204:	/* SET 1,H */
                    {
                        cpu.SET(Registers.regH, 1);
                    }
                    break;

                case 205:	/* SET 1,L */
                    {
                        cpu.SET(Registers.regL, 1);
                    }
                    break;

                case 206:	/* SET 1,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(1);
                    }
                    break;

                case 207:	/* SET 1,A */
                    {
                        cpu.SET(Registers.regA, 1);
                    }
                    break;

                //*************************************
                //SET 2,N

                case 208:	/* SET 2,B */
                    {
                        cpu.SET(Registers.regB, 2);
                    }
                    break;

                case 209:	/* SET 2,C */
                    {
                        cpu.SET(Registers.regC, 2);
                    }
                    break;

                case 210:	/* SET 2,D */
                    {
                        cpu.SET(Registers.regD, 2);
                    }
                    break;

                case 211:	/* SET 2,E */
                    {
                        cpu.SET(Registers.regE, 2);
                    }
                    break;

                case 212:	/* SET 2,H */
                    {
                        cpu.SET(Registers.regH, 2);
                    }
                    break;

                case 213:	/* SET 2,L */
                    {
                        cpu.SET(Registers.regL, 2);
                    }
                    break;

                case 214:	/* SET 2,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(2);
                    }
                    break;

                case 215:	/* SET 2,A */
                    {
                        cpu.SET(Registers.regA, 2);
                    }
                    break;

                //*************************************
                //SET 3,N

                case 216:	/* SET 3,B */
                    {
                        cpu.SET(Registers.regB, 3);
                    }
                    break;

                case 217:	/* SET 3,C */
                    {
                        cpu.SET(Registers.regC, 3);
                    }
                    break;

                case 218:	/* SET 3,D */
                    {
                        cpu.SET(Registers.regD, 3);
                    }
                    break;

                case 219:	/* SET 3,E */
                    {
                        cpu.SET(Registers.regE, 3);
                    }
                    break;

                case 220:	/* SET 3,H */
                    {
                        cpu.SET(Registers.regH, 3);
                    }
                    break;

                case 221:	/* SET 3,L */
                    {
                        cpu.SET(Registers.regL, 3);
                    }
                    break;

                case 222:	/* SET 3,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(3);
                    }
                    break;
                case 223:	/* SET 3,A */
                    {
                        cpu.SET(Registers.regA, 3);
                    }
                    break;

                //*************************************
                //SET 4,N

                case 224:	/* SET 4,B */
                    {
                        cpu.SET(Registers.regB, 4);
                    }
                    break;

                case 225:	/* SET 4,C */
                    {
                        cpu.SET(Registers.regC, 4);
                    }
                    break;

                case 226:	/* SET 4,D */
                    {
                        cpu.SET(Registers.regD, 4);
                    }
                    break;

                case 227:	/* SET 4,E */
                    {
                        cpu.SET(Registers.regE, 4);
                    }
                    break;

                case 228:	/* SET 4,H */
                    {
                        cpu.SET(Registers.regH, 4);
                    }
                    break;

                case 229:	/* SET 4,L */
                    {
                        cpu.SET(Registers.regL, 4);
                    }
                    break;

                case 230:	/* SET 4,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(4);
                    }
                    break;

                case 231:	/* SET 4,A */
                    {
                        cpu.SET(Registers.regA, 4);
                    }
                    break;

                //*************************************
                //SET 5,N

                case 232:	/* SET 5,B */
                    {
                        cpu.SET(Registers.regB, 5);
                    }
                    break;

                case 233:	/* SET 5,C */
                    {
                        cpu.SET(Registers.regC, 5);
                    }
                    break;

                case 234:	/* SET 5,D */
                    {
                        cpu.SET(Registers.regD, 5);
                    }
                    break;

                case 235:	/* SET 5,E */
                    {
                        cpu.SET(Registers.regE, 5);
                    }
                    break;

                case 236:	/* SET 5,H */
                    {
                        cpu.SET(Registers.regH, 5);
                    }
                    break;

                case 237:	/* SET 5,L */
                    {
                        cpu.SET(Registers.regL, 5);
                    }
                    break;

                case 238:	/* SET 5,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(5);
                    }
                    break;
                case 239:	/* SET 5,A */
                    {
                        cpu.SET(Registers.regA, 5);
                    }
                    break;

                //*************************************
                //SET 6,N

                case 240:	/* SET 6,B */
                    {
                        cpu.SET(Registers.regB, 6);
                    }
                    break;

                case 241:	/* SET 6,C */
                    {
                        cpu.SET(Registers.regC, 6);
                    }
                    break;

                case 242:	/* SET 6,D */
                    {
                        cpu.SET(Registers.regD, 6);
                    }
                    break;

                case 243:	/* SET 6,E */
                    {
                        cpu.SET(Registers.regE, 6);
                    }
                    break;

                case 244:	/* SET 6,H */
                    {
                        cpu.SET(Registers.regH, 6);
                    }
                    break;

                case 245:	/* SET 6,L */
                    {
                        cpu.SET(Registers.regL, 6);
                    }
                    break;

                case 246:	/* SET 6,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(6);
                    }
                    break;
                case 247:	/* SET 6,A */
                    {
                        cpu.SET(Registers.regA, 6);
                    }
                    break;

                //*************************************
                //SET 7,N

                case 248:	/* SET 7,B */
                    {
                        cpu.SET(Registers.regB, 7);
                    }
                    break;

                case 249:	/* SET 7,C */
                    {
                        cpu.SET(Registers.regC, 7);
                    }
                    break;

                case 250:	/* SET 7,D */
                    {
                        cpu.SET(Registers.regD, 7);
                    }
                    break;

                case 251:	/* SET 7,E */
                    {
                        cpu.SET(Registers.regE, 7);
                    }
                    break;

                case 252:	/* SET 7,H */
                    {
                        cpu.SET(Registers.regH, 7);
                    }
                    break;

                case 253:	/* SET 7,L */
                    {
                        cpu.SET(Registers.regL, 7);
                    }
                    break;

                case 254:	/* SET 7,(HL) */
                    {
                        cpu.SET_OnWherePointsHL(7);
                    }
                    break;

                case 255:	/* SET 7,A */
                    {
                        cpu.SET(Registers.regA, 7);
                    }
                    break;

                //*************************************
                //RES 0,N

                case 128:	/* RES 0,B */
                    {
                        cpu.RES(Registers.regB, 0);
                    }
                    break;

                case 129:	/* RES 0,C */
                    {
                        cpu.RES(Registers.regC, 0);
                    }
                    break;

                case 130:	/* RES 0,D */
                    {
                        cpu.RES(Registers.regD, 0);
                    }
                    break;

                case 131:	/* RES 0,E */
                    {
                        cpu.RES(Registers.regE, 0);
                    }
                    break;

                case 132:	/* RES 0,H */
                    {
                        cpu.RES(Registers.regH, 0);
                    }
                    break;

                case 133:	/* RES 0,L */
                    {
                        cpu.RES(Registers.regL, 0);
                    }
                    break;

                case 134:	/* RES 0,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(0);
                    }
                    break;

                case 135:	/* RES 0,A */
                    {
                        cpu.RES(Registers.regA, 0);
                    }
                    break;

                //*************************************
                //RES 1,N

                case 136:	/* RES 1,B */
                    {
                        cpu.RES(Registers.regB, 1);
                    }
                    break;

                case 137:	/* RES 1,C */
                    {
                        cpu.RES(Registers.regC, 1);
                    }
                    break;

                case 138:	/* RES 1,D */
                    {
                        cpu.RES(Registers.regD, 1);
                    }
                    break;

                case 139:	/* RES 1,E */
                    {
                        cpu.RES(Registers.regE, 1);
                    }
                    break;

                case 140:	/* RES 1,H */
                    {
                        cpu.RES(Registers.regH, 1);
                    }
                    break;

                case 141:	/* RES 1,L */
                    {
                        cpu.RES(Registers.regL, 1);
                    }
                    break;

                case 142:	/* RES 1,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(1);
                    }
                    break;

                case 143:	/* RES 1,A */
                    {
                        cpu.RES(Registers.regA, 1);
                    }
                    break;

                //*************************************
                //RES 2,N

                case 144:	/* RES 2,B */
                    {
                        cpu.RES(Registers.regB, 2);
                    }
                    break;

                case 145:	/* RES 2,C */
                    {
                        cpu.RES(Registers.regC, 2);
                    }
                    break;

                case 146:	/* RES 2,D */
                    {
                        cpu.RES(Registers.regD, 2);
                    }
                    break;

                case 147:	/* RES 2,E */
                    {
                        cpu.RES(Registers.regE, 2);
                    }
                    break;

                case 148:	/* RES 2,H */
                    {
                        cpu.RES(Registers.regH, 2);
                    }
                    break;

                case 149:	/* RES 2,L */
                    {
                        cpu.RES(Registers.regL, 2);
                    }
                    break;

                case 150:	/* RES 2,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(2);
                    }
                    break;

                case 151:	/* RES 2,A */
                    {
                        cpu.RES(Registers.regA, 2);
                    }
                    break;

                //*************************************
                //RES 3,N

                case 152:	/* RES 3,B */
                    {
                        cpu.RES(Registers.regB, 3);
                    }
                    break;

                case 153:	/* RES 3,C */
                    {
                        cpu.RES(Registers.regC, 3);
                    }
                    break;

                case 154:	/* RES 3,D */
                    {
                        cpu.RES(Registers.regD, 3);
                    }
                    break;

                case 155:	/* RES 3,E */
                    {
                        cpu.RES(Registers.regE, 3);
                    }
                    break;

                case 156:	/* RES 3,H */
                    {
                        cpu.RES(Registers.regH, 3);
                    }
                    break;

                case 157:	/* RES 3,L */
                    {
                        cpu.RES(Registers.regL, 3);
                    }
                    break;

                case 158:	/* RES 3,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(3);
                    }
                    break;

                case 159:	/* RES 3,A */
                    {
                        cpu.RES(Registers.regA, 3);
                    }
                    break;

                //*************************************
                //RES 4,N

                case 160:	/* RES 4,B */
                    {
                        cpu.RES(Registers.regB, 4);
                    }
                    break;

                case 161:	/* RES 4,C */
                    {
                        cpu.RES(Registers.regC, 4);
                    }
                    break;

                case 162:	/* RES 4,D */
                    {
                        cpu.RES(Registers.regD, 4);
                    }
                    break;

                case 163:	/* RES 4,E */
                    {
                        cpu.RES(Registers.regE, 4);
                    }
                    break;

                case 164:	/* RES 4,H */
                    {
                        cpu.RES(Registers.regH, 4);
                    }
                    break;

                case 165:	/* RES 4,L */
                    {
                        cpu.RES(Registers.regL, 4);
                    }
                    break;

                case 166:	/* RES 4,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(4);
                    }
                    break;

                case 167:	/* RES 4,A */
                    {
                        cpu.RES(Registers.regA, 4);
                    }
                    break;

                //*************************************
                //RES 5,N

                case 168:	/* RES 5,B */
                    {
                        cpu.RES(Registers.regB, 5);
                    }
                    break;

                case 169:	/* RES 5,C */
                    {
                        cpu.RES(Registers.regC, 5);
                    }
                    break;

                case 170:	/* RES 5,D */
                    {
                        cpu.RES(Registers.regD, 5);
                    }
                    break;

                case 171:	/* RES 5,E */
                    {
                        cpu.RES(Registers.regE, 5);
                    }
                    break;

                case 172:	/* RES 5,H */
                    {
                        cpu.RES(Registers.regH, 5);
                    }
                    break;

                case 173:	/* RES 5,L */
                    {
                        cpu.RES(Registers.regL, 5);
                    }
                    break;

                case 174:	/* RES 5,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(5);
                    }
                    break;

                case 175:	/* RES 5,A */
                    {
                        cpu.RES(Registers.regA, 5);
                    }
                    break;

                //*************************************
                //RES 6,N

                case 176:	/* RES 6,B */
                    {
                        cpu.RES(Registers.regB, 6);
                    }
                    break;

                case 177:	/* RES 6,C */
                    {
                        cpu.RES(Registers.regC, 6);
                    }
                    break;

                case 178:	/* RES 6,D */
                    {
                        cpu.RES(Registers.regD, 6);
                    }
                    break;

                case 179:	/* RES 6,E */
                    {
                        cpu.RES(Registers.regE, 6);
                    }
                    break;

                case 180:	/* RES 6,H */
                    {
                        cpu.RES(Registers.regH, 6);
                    }
                    break;

                case 181:	/* RES 6,L */
                    {
                        cpu.RES(Registers.regL, 6);
                    }
                    break;

                case 182:	/* RES 6,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(6);
                    }
                    break;

                case 183:	/* RES 6,A */
                    {
                        cpu.RES(Registers.regA, 6);
                    }
                    break;

                //*************************************
                //RES 7,N

                case 184:	/* RES 7,B */
                    {
                        cpu.RES(Registers.regB, 7);
                    }
                    break;

                case 185:	/* RES 7,C */
                    {
                        cpu.RES(Registers.regC, 7);
                    }
                    break;

                case 186:	/* RES 7,D */
                    {
                        cpu.RES(Registers.regD, 7);
                    }
                    break;

                case 187:	/* RES 7,E */
                    {
                        cpu.RES(Registers.regE, 7);
                    }
                    break;

                case 188:	/* RES 7,H */
                    {
                        cpu.RES(Registers.regH, 7);
                    }
                    break;

                case 189:	/* RES 7,L */
                    {
                        cpu.RES(Registers.regL, 7);
                    }
                    break;

                case 190:	/* RES 7,(HL) */
                    {
                        cpu.RES_OnWherePointsHL(7);
                    }
                    break;

                case 191:	/* RES 7,A */
                    {
                        cpu.RES(Registers.regA, 7);
                    }
                    break;

                default:
                    {
                        MessageBox.Show("Prefix 221, instruction not supported, code: " + code + ", address: " + Registers.regPC);
                    }
                    break;

            }
        }



        //end of class
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{

/*
 * Parses instructions following the 253 prefix code.
 * Index IY instructions
 */
    public class CPUparserPrefix253
    {

            private CPUroutines cpu;
            private Registers Registers;
            private CPUparserPrefix253_203 prefix253_203;
            private int code;


            public CPUparserPrefix253(CPUroutines cpu, Registers Registers)
            {
                this.cpu = cpu;
                this.Registers = Registers;
                prefix253_203 = new CPUparserPrefix253_203(cpu, Registers);
            }

            public void Parse()
            {
                cpu.Refresh_R(); //obnov R registr
                code = cpu.Fetch();

                switch (code)
                {

                    case 104:/*LD LY,B */
                        {
                            cpu.LD(Registers.regLY, Registers.regB);
                        }
                        break;

                    case 105:/*LD LY,C */
                        {
                            cpu.LD(Registers.regLY, Registers.regC);
                        }
                        break;

                    case 106:/*LD LY,D */
                        {
                            cpu.LD(Registers.regLY, Registers.regD);
                        }
                        break;

                    case 107:/*LD LY,E */
                        {
                            cpu.LD(Registers.regLY, Registers.regE);
                        }
                        break;

                    case 108:/*LD LY,HY */
                        {
                            cpu.LD(Registers.regLY, Registers.regHY);
                        }
                        break;

                    case 109:/*LD LY,LY */
                        {
                            cpu.LD(Registers.regLY, Registers.regLY);
                        }
                        break;


                    case 111:/*LD LY,A */
                        {
                            cpu.LD(Registers.regLY, Registers.regA);
                        }
                        break;


                    case 96:/*LD HY,B */
                        {
                            cpu.LD(Registers.regHY, Registers.regB);
                        }
                        break;

                    case 97:/*LD HY,C */
                        {
                            cpu.LD(Registers.regHY, Registers.regC);
                        }
                        break;

                    case 98:/*LD HY,D */
                        {
                            cpu.LD(Registers.regHY, Registers.regD);
                        }
                        break;

                    case 99:/*LD HY,E */
                        {
                            cpu.LD(Registers.regHY, Registers.regE);
                        }
                        break;

                    case 100:/*LD HY,HY */
                        {
                            cpu.LD(Registers.regHY, Registers.regHY);
                        }
                        break;

                    case 101:/*LD HY,LY */
                        {
                            cpu.LD(Registers.regHY, Registers.regLY);
                        }
                        break;

                    case 103:/*LD HY,A */
                        {
                            cpu.LD(Registers.regHY, Registers.regA);
                        }
                        break;

                    case 38:/*LD HY,N*/
                        {
                            cpu.LD_REG8_NN(Registers.regHY);
                        }
                        break;

                    case 46:/*LD LY,N*/
                        {
                            cpu.LD_REG8_NN(Registers.regLY);
                        }
                        break;

                    case 36:/*INC HY*/
                        {
                            cpu.INC(Registers.regHY);
                        }
                        break;

                    case 37:/*DEC HY*/
                        {
                            cpu.DEC(Registers.regHY);
                        }
                        break;

                    case 44:/*INC LY*/
                        {
                            cpu.INC(Registers.regLY);
                        }
                        break;

                    case 45:/*DEC LY*/
                        {
                            cpu.DEC(Registers.regLY);
                        }
                        break;

                    case 69:/*LD B,LY*/
                        {
                            cpu.LD(Registers.regB, Registers.regLY);
                        }
                        break;

                    case 77:/*LD C,LY*/
                        {
                            cpu.LD(Registers.regC, Registers.regLY);
                        }
                        break;

                    case 85:/*LD D,LY*/
                        {
                            cpu.LD(Registers.regD, Registers.regLY);
                        }
                        break;

                    case 93:/*LD E,LY*/
                        {
                            cpu.LD(Registers.regE, Registers.regLY);
                        }
                        break;

                    case 125:/*LD A,LY*/
                        {
                            cpu.LD(Registers.regA, Registers.regLY);
                        }
                        break;

                    case 68:/*LD B,HY*/
                        {
                            cpu.LD(Registers.regB, Registers.regHY);
                        }
                        break;

                    case 76:/*LD C,HY*/
                        {
                            cpu.LD(Registers.regC, Registers.regHY);
                        }
                        break;

                    case 84:/*LD D,HY*/
                        {
                            cpu.LD(Registers.regD, Registers.regHY);
                        }
                        break;

                    case 92:/*LD E,HY*/
                        {
                            cpu.LD(Registers.regE, Registers.regHY);
                        }
                        break;

                    case 124:/*LD A,HY*/
                        {
                            cpu.LD(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 132:/*ADD A, HY*/
                        {
                            cpu.ADD(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 133:/*ADD A, LY*/
                        {
                            cpu.ADD(Registers.regA, Registers.regLY);
                        }
                        break;

                    case 140:/*ADC A, HY*/
                        {
                            cpu.ADC(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 141:/*ADC A, LY*/
                        {
                            cpu.ADC(Registers.regA, Registers.regLY);
                        }
                        break;

                    case 148:/*SUB A, HY*/
                        {
                            cpu.SUB(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 149:/*SUB A, LY*/
                        {
                            cpu.SUB(Registers.regA, Registers.regLY);
                        }
                        break;

                    case 156:/*SBC A, HY*/
                        {
                            cpu.SBC(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 157:/*SBC A, LY*/
                        {
                            cpu.SBC(Registers.regA, Registers.regLY);
                        }
                        break;

                    case 164:/*AND HY*/
                        {
                            cpu.AND(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 165:/*AND LY*/
                        {
                            cpu.AND(Registers.regA, Registers.regLY);
                        }
                        break;

                    case 166:/*AND (IY + N)*/
                        {
                            cpu.AND_RegA_FromWherePointsIX_IY_Shift(Registers.regIY);
                        }
                        break;

                    case 172:/*XOR HY*/
                        {
                            cpu.XOR(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 173:/*XOR LY*/
                        {
                            cpu.XOR(Registers.regA, Registers.regLY);
                        }
                        break;


                    case 180:/*OR HY*/
                        {
                            cpu.OR(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 181:/*OR LY*/
                        {
                            cpu.OR(Registers.regA, Registers.regLY);
                        }
                        break;



                    case 182:/*OR (IY + N)*/
                        {
                            cpu.OR_RegA_FromWherePointsIX_IY_Shift(Registers.regIY);
                        }
                        break;

                    case 174:/*XOR (IY + N)*/
                        {
                            cpu.XOR_RegA_FromWherePointsIX_IY_Shift(Registers.regIY);
                        }
                        break;

                    case 188:/*CP HY*/
                        {
                            cpu.CP(Registers.regA, Registers.regHY);
                        }
                        break;

                    case 189:/*CP LY*/
                        {
                            cpu.CP(Registers.regA, Registers.regLY);
                        }
                        break;


                    case 190: /*CP (IY + N)*/
                        {
                            cpu.CP_RegA_FromWherePointsIX_IY_Shift(Registers.regIY);
                        }
                        break;

                    case 52: /*INC (IY + N)*/
                        {
                            cpu.INC_WherePointsIX_Shift(Registers.regIY);
                        }
                        break;

                    case 53: /*DEC (IY + N)*/
                        {
                            cpu.DEC_WherePointsIX_Shift(Registers.regIY);
                        }
                        break;

                    case 134: /*ADD A,(IY + N)*/
                        {
                            cpu.ADD_A_IX_IY_Plus_N(Registers.regA, Registers.regIY);
                        }
                        break;

                    case 142: /*ADC A,(IY + N)*/
                        {
                            cpu.ADC_A_IX_IY_Plus_N(Registers.regA, Registers.regIY);
                        }
                        break;

                    case 150: /*SUB(IY + N)*/
                        {
                            cpu.SUB_A_IX_IY_Plus_N(Registers.regA, Registers.regIY);
                        }
                        break;

                    case 158: /*SBC A,(IY + N)*/
                        {
                            cpu.SBC_A_IX_IY_Plus_N(Registers.regA, Registers.regIY);
                        }
                        break;

                    case 227:    /* EX (SP),IY */
                        {
                            cpu.EX_ToWherePointsSP_IY();
                        }
                        break;

                    case 249:  /* LD SP,IY*/
                        {
                            cpu.LD(Registers.regSP, Registers.regIY, 10);
                        }
                        break;

                    case 33: /*LD IY,NN*/
                        {
                            cpu.LD_REG16_NN(Registers.regIY, 14);
                        }
                        break;

                    case 34:  /* LD (nn),IY*/
                        {
                            cpu.LD_MEM_REG16(Registers.regIY, 20);
                        }
                        break;

                    case 42: /*LD IY,(NN)*/
                        {
                            cpu.LD_REG16_FromWherePointsOp(Registers.regIY, 20);
                        }
                        break;

                    case 70: /*LD B,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regB, Registers.regIY);
                        }
                        break;

                    case 78: /*LD C,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regC, Registers.regIY);
                        }
                        break;

                    case 86: /*LD D,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regD, Registers.regIY);
                        }
                        break;

                    case 94: /*LD E,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regE, Registers.regIY);
                        }
                        break;

                    case 102: /*LD H,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regH, Registers.regIY);
                        }
                        break;

                    case 110: /*LD L,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regL, Registers.regIY);
                        }
                        break;

                    case 126: /*LD A,(IY + E)*/
                        {
                            cpu.LD_REG8_From_IndexReg(Registers.regA, Registers.regIY);
                        }
                        break;

                    case 112: /*LD (IY + E),B*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regB);
                        }
                        break;

                    case 113: /*LD (IY + E),C*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regC);
                        }
                        break;

                    case 114: /*LD (IY + E),D*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regD);
                        }
                        break;

                    case 115: /*LD (IY + E),E*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regE);
                        }
                        break;

                    case 116: /*LD (IY + E),H*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regH);
                        }
                        break;

                    case 117: /*LD (IY + E),L*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regL);
                        }
                        break;

                    case 119: /*LD (IY + E),A*/
                        {
                            cpu.LD_ToWherePointsIndexReg_Reg8(Registers.regIY, Registers.regA);
                        }
                        break;

                    case 54: /*LD (IY + E),N*/
                        {
                            cpu.LD_ToWherePointsIndexReg_NN(Registers.regIY);
                        }
                        break;

                    case 35: /*INC IY*/
                        {
                            cpu.INC_IndexReg(Registers.regIY);
                        }
                        break;

                    case 43: /*DEC IY*/
                        {
                            cpu.DEC_IndexReg(Registers.regIY);
                        }
                        break;

                    case 9: /*ADD IY,BC*/
                        {
                            cpu.ADD_IX_REG16(Registers.regIY, Registers.regBC);
                        }
                        break;

                    case 25: /*ADD IY,DE*/
                        {
                            cpu.ADD_IX_REG16(Registers.regIY, Registers.regDE);
                        }
                        break;

                    case 41: /*ADD IY,IY*/
                        {
                            cpu.ADD_IX_REG16(Registers.regIY, Registers.regIY);
                        }
                        break;

                    case 57: /*ADD IY,SP*/
                        {
                            cpu.ADD_IX_REG16(Registers.regIY, Registers.regSP);
                        }
                        break;

                    case 229: /*PUSH IY*/
                        {
                            cpu.PUSH_IndexReg(Registers.regIY);
                        }
                        break;

                    case 225: /*POP IY*/
                        {
                            cpu.POP_IndexReg(Registers.regIY);
                        }
                        break;

                    case 233: /*JP (IY)*/
                        {
                            cpu.JP_Index(Registers.regIY);
                        }
                        break;

                    case 203:
                        {
                            prefix253_203.Parse();
                        }
                        break;


                    default:
                        {
                            MessageBox.Show("Prefix 253, instruction not supported, code: " + code + ", address: " + Registers.regPC);
                        }
                        break;
                }
            }

         
        //end of class
    }
}

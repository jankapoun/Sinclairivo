using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{
/*
 * Contains the representation of ZXS memory
 * 
 */
    public class RAM
    {
    private int[] ram = new int[65536];
    private MainWnd mainWindow;
    public VRAM vram = null;
    private Ports ports;

/**
 *
 * Creates a new instance of RAM, creates also a new object of VRAM
 * because ZXS memory 16384 - 22728 is VRAM. When writing to these
 * addresses, RAM object must also be able to call VRAM routines to 
 * ensure that the RAM values will be copied into the VRAM pixel array.
 */
    public RAM(MainWnd mainWindow, Ports ports)
    {
        this.mainWindow = mainWindow;
        this.ports = ports;
        vram = new VRAM(mainWindow, this, ports);
    }
  
/**
* Gets the actual int array representing the ZX RAM.
* @return ZX RAM int array
*/
    public int[] GetRAMArray()
    { return ram; }

  /**
   * Sets the actual int array representing the ZX RAM.
   */
    public void SetRAMArray(int[] bytes)
    { this.ram = bytes;}

    public void SetROMArray(byte[] bytes)
    {
        if (bytes.Length > 16384) { MessageBox.Show("ROM data is too long!"); return; }
        int addr = 0;
        int i;
        foreach (byte b in bytes)
        {
            i = b;
            this.WriteROM_NoCheck(addr, i);
            addr++;
        }
    
    }

        public void SetROMArray(byte[] bytes, int addr)
        {
            if (bytes.Length > 16384) { MessageBox.Show("ROM data is too long!"); return; }
            
            int i;
            foreach (byte b in bytes)
            {
                i = b;
                this.WriteROM_NoCheck(addr, i);
                addr++;
            }

        }

        public void SetRAMArray(byte[] bytes, int addr)
        {
            if (bytes.Length > 65535) { MessageBox.Show("RAM data is too long!"); return; }

            int i;
            foreach (byte b in bytes)
            {
                i = b;
                this.WriteROM_NoCheck(addr, i);
                addr++;
            }

        }
    
/**
 * Gets the VRAM
 * @return VRAM
 */
    public VRAM GetVRAM()
    {
        return vram;
    }
    
/**
 * Writes into the RAM
 */
        public void WriteRAM(int addr, int b)
        {
            if (b > 255){ MessageBox.Show("WriteRAM: Argument out of range!"); return;}
            //writing to the ROM is not possible
         //   if (addr < 16384) { System.err.println("WriteRAM: Attempt to write into ROM!");}
            
            if ((addr >= 16384) && (addr <= 65535)) { ram[addr] = b; }
            
            //writing to the pixels VRAM
            if ((addr >= 16384) && (addr <= 22527)) 
            {
                vram.WritePxlsToVRAM(addr, b);
                
            }
            //writing to the attributes VRAM
            if ((addr >= 22528) && (addr <= (22528 + 768))) 
            {
                vram.WriteAttribsToVRAM(addr, b);
           
            }
        }
        
/**
 * Writes into the ROM
 */
        public void WriteROM_NoCheck(int addr, int b)
        {
            if (b > 255) { MessageBox.Show("WriteRAM: Argument out of range!"); return; }
            if ((addr >= 0) && (addr <= 65535)) { ram[addr] = b; }
            
             //writing to the pixels VRAM
            if ((addr >= 16384) && (addr <= 22527)) 
            {
                vram.WritePxlsToVRAM(addr, b);
                
            }
            //writing to the attributes VRAM
            if ((addr >= 22528) && (addr <= (22528 + 768))) 
            {
                vram.WriteAttribsToVRAM(addr, b);
           
            }
        }
                
    
/*
 * Reads from RAM
 * 
 */
 public int ReadRAM(int addr)
 {
       return ram[addr];
 }

/**
 * Fills a ZXS memory block with a specified value
 * used mainly for clearing the ZXS screen.
 * Used only for debugging purposes.
 * 
 */
 public void FillRAM(int from, int size, int with)
 {
    for (int i = from; i < from + size; i++ )
    {
        WriteRAM(i,with);
    }
 
 }

/**
 * Resets the RAM
 * Used only for debugging purposes.
 */ 
 public void ResetRAM()
 {
    this.FillRAM(0, 65536, 0);
 }
 
/**
 * Clears the VRAM (cls)
 * Used mainly for clearing the ZXS screen.
 * Used only for debugging purposes.
 * 
 */
  public void ClearVRAM()
  {
       FillRAM(16384, 6144, 0);
       FillRAM(22528, 768, 56);
  }
 
        //end of class
    }
}

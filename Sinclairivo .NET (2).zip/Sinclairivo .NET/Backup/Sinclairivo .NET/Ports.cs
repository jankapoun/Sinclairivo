using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Sinclairivo.NET
{
    /*
     * Contains the ZXS ports (mainly keyboard ports)
     * 
     */
    public class Ports
    {
        /**
        * These ports are emulated
        */
        //border port
        public int border;      //254, border

        //keyboard ports         
        private int CshZXCV = 255;      //65278;
        private int ASDFG = 255;        //65022;
        private int QWERT = 255;       //64510
        private int P12345 = 255;      //63486;
        private int P09876 = 255;    //61438;
        private int POIUY = 255;       //57342;
        private int EntLKJH = 255;     //49150;
        private int SpcSshMNB = 255;   //32766;
        private int Kempston = 0;

        /**
        * Sets the ports. Called only by the ZXS emulator program to
        * emulate the activity of ports,  NOT by the ZXS machine itself!
        */
        public void SetPort(int port, int b)
        {
            switch (port)
            {
                case 254: border = b;
                    break;

                case 65278: CshZXCV = b;
                    break;

                case 65022: ASDFG = b;
                    break;

                case 64510: QWERT = b;
                    break;

                case 63486: P12345 = b;
                    break;

                case 61438: P09876 = b;
                    break;

                case 57342: POIUY = b;
                    break;

                case 49150: EntLKJH = b;
                    break;

                case 32766: SpcSshMNB = b;
                    break;

                case 31: Kempston = b;
                    break;

                default:
                    break;
                    //System.err.println("Trying to set an unrecognized port: " + port);
            }

        }

        /**
        * Reads from ports, called by the ZXS machine itself.
        */
        public int InPort(int port) //vola instrukce IN
        {
            switch (port)
            {
                case 254: return (EntLKJH & CshZXCV & ASDFG & QWERT & P12345 & P09876 & POIUY & EntLKJH & SpcSshMNB);

                case 65278: return CshZXCV;

                case 65022: return ASDFG;

                case 64510: return QWERT;

                case 63486: return P12345;

                case 61438: return P09876;

                case 57342: return POIUY;

                case 49150: return EntLKJH;

                case 32766: return SpcSshMNB;

                case 32510: return SpcSshMNB;

                case 31: return Kempston;

                default:
                    break;
                    //System.err.println("Reading from an unrecognized port: " + port);
            }
            return 255;  //unrecognized port, 255 - no device connected

        }

        /**
         * Writes to ports, used by the ZXS machine itself.
         * However, the I/O operations are not supported except
         * for the keyboard.
         */
        public void OutPort(int port, int b)
        {
            switch (port)
            {
                case 254: border = b;
                    break;

            }

        }

        //end of class
    }
}

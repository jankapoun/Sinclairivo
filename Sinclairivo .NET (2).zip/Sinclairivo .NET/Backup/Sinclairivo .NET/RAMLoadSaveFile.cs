using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace Sinclairivo.NET
{

    /**
     * This class loads or saves a file into the ZX RAM.
     * @author Jan Kapoun, Mgr.
     */
    public class RAMLoadSaveFile
    {
        public static void LoadROM(RAM ram)
        {
            ram.SetROMArray(global::Sinclairivo.NET.Properties.Resources.zx_spectrum_ROM);
        }

        public static void LoadROM(byte[] bytes, RAM ram)
        {
            ram.SetROMArray(bytes);
        }

        public static void LoadSnapShot(byte[] bytes, ZXMachine zxmachine)
        {
            Globals.snapshotLoading = true;
            //wait until the cpu parser finishes work (it's on an other thread)
            while (Globals.CPUparserInProgress == true)
            {
                /**
                 * Waits for the parser to finish
                 * so new program can be loaded. 
                 */
                try { Thread.Sleep(10); }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }

        
                int address = 0;
                
                Registers.regI.Set(bytes[address]); address++;
                Registers.regL_.Set(bytes[address]); address++;
                Registers.regH_.Set(bytes[address]); address++;
                Registers.regE_.Set(bytes[address]); address++;
                Registers.regD_.Set(bytes[address]); address++;
                Registers.regC_.Set(bytes[address]); address++;
                Registers.regB_.Set(bytes[address]); address++;

                Registers.regF_.Set(bytes[address]); address++;
                Registers.regA_.Set(bytes[address]); address++;

                Registers.regL.Set(bytes[address]); address++;
                Registers.regH.Set(bytes[address]); address++;
                Registers.regE.Set(bytes[address]); address++;
                Registers.regD.Set(bytes[address]); address++;
                Registers.regC.Set(bytes[address]); address++;
                Registers.regB.Set(bytes[address]); address++;
                Registers.regLY.Set(bytes[address]); address++;
                Registers.regHY.Set(bytes[address]); address++;

                Registers.regLX.Set(bytes[address]); address++;
                Registers.regHX.Set(bytes[address]); address++;

                if ((bytes[address] & 1) == 1) { Registers.regIFF = false; } //iff
                else { Registers.regIFF = true; }
                address++;
                Registers.regR.Set(bytes[address]); address++;
                Registers.regF.Set(bytes[address]); address++;
                Registers.regA.Set(bytes[address]); address++;

                Registers.regSP.Set(bytes[address] + (256 * bytes[address + 1]));
                address += 2;
                Registers.im.Set(bytes[address]); address++;
                zxmachine.ports.border = bytes[address];//border color
                address++;

                for (int i = 16384; i < 65536; i++)
                {
                    zxmachine.ram.WriteRAM(i, bytes[address]);
                    address++;
                }

                Globals.snapshotSNARequest = true;
                Globals.snapshotLoading = false;
        
        }

        public static void Load(String filename, RAM ram, int address)
        {
            try
            {
                FileInfo iStream = new FileInfo(filename);
                BinaryReader br = new BinaryReader(iStream.OpenWrite());

                int b;
                try
                {
                    while (true) //are we at the end of file?, -1 = yes
                    {                           
                        b = br.ReadByte();
                        if (b == -1)
                        {
                            br.Close();
                            return;
                        }
                        
                        ram.WriteROM_NoCheck(address, b);
                        address++;
                    }
                }
                catch (Exception e)
                {
                    
                    MessageBox.Show("Load operation failed, file: " + filename + "\n" +
                        e.Message);
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("File not found: " + filename + "\n" +
                        e.Message);
            }

        }

        /**
          * SNA snapshot format
          */
        //   Offset   Size   Description
        //   ------------------------------------------------------------------------
        //   0        1      byte   I
        //   1        8      word   HL',DE',BC',AF'
        //   9        10     word   HL,DE,BC,IY,IX
        //   19       1      byte   Interrupt (bit 2 contains IFF2, 1=EI/0=DI)
        //   20       1      byte   R
        //   21       4      words  AF,SP
        //   25       1      byte   IntMode (0=IM0/1=IM1/2=IM2)
        //   26       1      byte   BorderColor (0..7, not used by Spectrum 1.7)
        //   27       49152  bytes  RAM dump 16384..65535
        //   ------------------------------------------------------------------------
        //   Total: 49179 bytes
        //    

        public static void LoadSnapshot(String filename, ZXMachine zxmachine)
        {
            Globals.snapshotLoading = true;
            while (Globals.CPUparserInProgress == true)
            {
                /**
                 * Waits for the parser to finish
                 * so new program can be loaded. 
                 */
                try { Thread.Sleep(10); }
                catch (Exception ex) { MessageBox.Show(ex.Message); }

            }

            try
            {
                FileInfo iStream = new FileInfo(filename);
                BinaryReader br = new BinaryReader(iStream.OpenWrite());

                try
                {
                    Registers.regI.Set(br.ReadByte());
                    Registers.regL_.Set(br.ReadByte());
                    Registers.regH_.Set(br.ReadByte());
                    Registers.regE_.Set(br.ReadByte());
                    Registers.regD_.Set(br.ReadByte());
                    Registers.regC_.Set(br.ReadByte());
                    Registers.regB_.Set(br.ReadByte());

                    Registers.regF_.Set(br.ReadByte());
                    Registers.regA_.Set(br.ReadByte());

                    Registers.regL.Set(br.ReadByte());
                    Registers.regH.Set(br.ReadByte());
                    Registers.regE.Set(br.ReadByte());
                    Registers.regD.Set(br.ReadByte());
                    Registers.regC.Set(br.ReadByte());
                    Registers.regB.Set(br.ReadByte());
                    Registers.regLY.Set(br.ReadByte());
                    Registers.regHY.Set(br.ReadByte());

                    Registers.regLX.Set(br.ReadByte());
                    Registers.regHX.Set(br.ReadByte());

                    if ((br.ReadByte() & 1) == 1) { Registers.regIFF = false; } //iff
                    else { Registers.regIFF = true; }
                    Registers.regR.Set(br.ReadByte());
                    Registers.regF.Set(br.ReadByte());
                    Registers.regA.Set(br.ReadByte());

                    Registers.regSP.Set(br.ReadByte() + (256 * br.ReadByte()));
                    Registers.im.Set(br.ReadByte());
                    zxmachine.ports.border = br.ReadByte();//border color

                    for (int i = 16384; i < 65536; i++)
                    {
                        zxmachine.ram.WriteRAM(i, br.ReadByte());

                    }

                    br.Close();


                }
                catch (Exception e)
                {
                    MessageBox.Show("Snapshot loading operation failed, file: " 
                        + filename + "\n" + e.Message);
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Snapshot file not found: " 
                    + filename + "\n" + e.Message);
            }

            Globals.snapshotSNARequest = true;
            Globals.snapshotLoading = false;


        }

        public static void SaveSnapshot(String filename, ZXMachine zxmachine)
        {

            Globals.snapshotLoading = true;
            while (Globals.CPUparserInProgress == true)
            {
                /**
                 * Waits for the parser to finish
                 * so new program can be loaded. 
                 */
                try { Thread.Sleep(10); }
                catch (Exception ex) { }

            }

            try
            {

                FileInfo iStream = new FileInfo(filename);
                BinaryWriter bw = new BinaryWriter(iStream.OpenWrite());

                

                try
                {
                    bw.Write(Registers.regI.Get());
                    bw.Write(Registers.regL_.Get());
                    bw.Write(Registers.regH_.Get());
                    bw.Write(Registers.regE_.Get());
                    bw.Write(Registers.regD_.Get());
                    bw.Write(Registers.regC_.Get());
                    bw.Write(Registers.regB_.Get());
                    bw.Write(Registers.regF_.Get());
                    bw.Write(Registers.regA_.Get());
                    bw.Write(Registers.regL.Get());
                    bw.Write(Registers.regH.Get());
                    bw.Write(Registers.regE.Get());
                    bw.Write(Registers.regD.Get());
                    bw.Write(Registers.regC.Get());
                    bw.Write(Registers.regB.Get());

                    bw.Write(Registers.regLY.Get());
                    bw.Write(Registers.regHY.Get());
                    bw.Write(Registers.regLX.Get());
                    bw.Write(Registers.regHX.Get());

                    if (Registers.regIFF == false) { bw.Write(0); }
                    else { bw.Write(1); }

                    bw.Write(Registers.regR.Get());
                    bw.Write(Registers.regF.Get());
                    bw.Write(Registers.regA.Get());
                    zxmachine.r.PUSH(Registers.regPC);
                    bw.Write(Registers.regSP.Get() % 256);
                    bw.Write(Registers.regSP.Get() / 256);
                    bw.Write(Registers.im.Get());
                    bw.Write(zxmachine.ports.border); //border color 


                    for (int i = 16384; i < (65536); i++)
                    {
                        bw.Write(zxmachine.ram.ReadRAM(i));
                    }

                    bw.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show("Save operation failed, file: " 
                        + filename + "\n" + e.Message);
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("File not found: " + filename);
            }

            Globals.snapshotLoading = false;

        }

        public static void Save(String filename, RAM ram, int start, int length)
        {
            try
            {
                FileInfo iStream = new FileInfo(filename);
                BinaryWriter bw = new BinaryWriter(iStream.OpenWrite());


                try
                {
                    for (int i = start; i < (start + length); i++)
                    {
                        bw.Write(ram.ReadRAM(i));
                    }

                    bw.Close();
                }
                catch (Exception e)
                {
                    MessageBox.Show("Save operation failed, file: " + filename);
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("File not found: " + filename);
            }



        }

        //end of class
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Sinclairivo.NET
{
    /*
     * This is the Zilog Z80 parser.
     * Reads instructions and decides which CPU routines to call.
     */
    public class CPUparser
    {
        private CPUroutines cpu;
        private Registers Registers;
        private CPUparserPrefix203 prefix203;
        private CPUparserPrefix221 prefix221;
        private CPUparserPrefix253 prefix253;
        private CPUparserPrefix237 prefix237;
        private int code;

        public CPUparser(CPUroutines cpu, Registers Registers)
        {
            this.cpu = cpu;
            this.Registers = Registers;
            prefix203 = new CPUparserPrefix203(cpu, Registers);
            prefix221 = new CPUparserPrefix221(cpu, Registers);
            prefix253 = new CPUparserPrefix253(cpu, Registers);
            prefix237 = new CPUparserPrefix237(cpu, Registers);
        }
        /*
         * Reads instructions and executes them.
         * Only 1 instruction is executed per call.
         */

        public void Parse()
        {
            if (Globals.reset == true) { Globals.reset = false; Registers.regPC.Set(0); }

            while (Globals.pause == true)
            {
                try { Thread.Sleep(20); }
                catch (Exception e) { MessageBox.Show(e.Message); }
            }

            while (Globals.snapshotLoading == true)
            {
                try { Thread.Sleep(20); }
                catch (Exception e) { MessageBox.Show(e.Message); }
            }


            if (Globals.snapshotSNARequest == true)
            {
                Globals.snapshotSNARequest = false;
                cpu.RET();
            }

            Globals.CPUparserInProgress = true;

            cpu.Refresh_R(); //refresh the R register
            code = cpu.Fetch();

            /**
             * Parses the instructions.
             */
            switch (code)
            {
                case 0:    /* NOP */
                    {
                        cpu.NOP();
                    }
                    break;

                case 39: /* DAA */
                    {
                        cpu.DAA();
                    }
                    break;

                case 47: /* CPL */
                    {
                        cpu.CPL(Registers.regA);
                    }
                    break;

                /*
                 * LD operations.
                 * Reads and writes data from and into registrers or memory.
                 */
                /* LD B,* */
                case 64:    /* LD B,B */
                    {
                        cpu.LD(Registers.regB, Registers.regB);
                    }
                    break;

                case 65:    /* LD B,C */
                    {
                        cpu.LD(Registers.regB, Registers.regC);
                    }
                    break;

                case 66:    /* LD B,D */
                    {
                        cpu.LD(Registers.regB, Registers.regD);

                    }
                    break;

                case 67:    /* LD B,E */
                    {
                        cpu.LD(Registers.regB, Registers.regE);
                    }
                    break;


                case 68:    /* LD B,H */
                    {
                        cpu.LD(Registers.regB, Registers.regH);
                    }
                    break;


                case 69:    /* LD B,L */
                    {
                        cpu.LD(Registers.regB, Registers.regL);
                    }
                    break;


                case 71:    /* LD B,A */
                    {
                        cpu.LD(Registers.regB, Registers.regA);
                    }
                    break;

                /* LD C,* */
                case 72:    /* LD C,B */
                    {
                        cpu.LD(Registers.regC, Registers.regB);

                    }
                    break;

                case 73:    /* LD C,C */
                    {
                        cpu.LD(Registers.regC, Registers.regC);
                    }
                    break;


                case 74:    /* LD C,D */
                    {
                        cpu.LD(Registers.regC, Registers.regD);

                    }
                    break;


                case 75:    /* LD C,E */
                    {
                        cpu.LD(Registers.regC, Registers.regE);

                    }
                    break;


                case 76:    /* LD C,H */
                    {
                        cpu.LD(Registers.regC, Registers.regH);

                    }
                    break;


                case 77:    /* LD C,L */
                    {
                        cpu.LD(Registers.regC, Registers.regL);

                    }
                    break;

                case 79:    /* LD C,A */
                    {
                        cpu.LD(Registers.regC, Registers.regA);

                    }
                    break;

                /* LD D,* */
                case 80:    /* LD D,B */
                    {
                        cpu.LD(Registers.regD, Registers.regB);

                    }
                    break;


                case 81:    /* LD D,C */
                    {
                        cpu.LD(Registers.regD, Registers.regC);

                    }
                    break;


                case 82:    /* LD D,D */
                    {
                        cpu.LD(Registers.regD, Registers.regD);
                    }
                    break;


                case 83:    /* LD D,E */
                    {
                        cpu.LD(Registers.regD, Registers.regE);

                    }
                    break;


                case 84:    /* LD D,H */
                    {
                        cpu.LD(Registers.regD, Registers.regH);

                    }
                    break;


                case 85:    /* LD D,L */
                    {
                        cpu.LD(Registers.regD, Registers.regL);

                    }
                    break;


                case 87:    /* LD D,A */
                    {
                        cpu.LD(Registers.regD, Registers.regA);

                    }
                    break;

                /* LD E,* */
                case 88:    /* LD E,B */
                    {
                        cpu.LD(Registers.regE, Registers.regB);

                    }
                    break;


                case 89:    /* LD E,C */
                    {
                        cpu.LD(Registers.regE, Registers.regC);

                    }
                    break;


                case 90:    /* LD E,D */
                    {
                        cpu.LD(Registers.regE, Registers.regD);

                    }
                    break;


                case 91:    /* LD E,E */
                    {
                        cpu.LD(Registers.regE, Registers.regE);
                    }
                    break;

                case 92:    /* LD E,H */
                    {
                        cpu.LD(Registers.regE, Registers.regH);

                    }
                    break;


                case 93:    /* LD E,L */
                    {
                        cpu.LD(Registers.regE, Registers.regL);

                    }
                    break;

                case 95:    /* LD E,A */
                    {
                        cpu.LD(Registers.regE, Registers.regA);

                    }
                    break;

                /* LD H,* */
                case 96:    /* LD H,B */
                    {
                        cpu.LD(Registers.regH, Registers.regB);

                    }
                    break;


                case 97:    /* LD H,C */
                    {
                        cpu.LD(Registers.regH, Registers.regC);

                    }
                    break;


                case 98:    /* LD H,D */
                    {
                        cpu.LD(Registers.regH, Registers.regD);

                    }
                    break;


                case 99:    /* LD H,E */
                    {
                        cpu.LD(Registers.regH, Registers.regE);

                    }
                    break;


                case 100: /* LD H,H */
                    {
                        cpu.LD(Registers.regH, Registers.regH);
                    }
                    break;

                case 101:    /* LD H,L */
                    {
                        cpu.LD(Registers.regH, Registers.regL);

                    }
                    break;


                case 103:    /* LD H,A */
                    {
                        cpu.LD(Registers.regH, Registers.regA);

                    }
                    break;

                /* LD L,* */
                case 104:    /* LD L,B */
                    {
                        cpu.LD(Registers.regL, Registers.regB);

                    }
                    break;


                case 105:    /* LD L,C */
                    {
                        cpu.LD(Registers.regL, Registers.regC);

                    }
                    break;


                case 106:    /* LD L,D */
                    {
                        cpu.LD(Registers.regL, Registers.regD);

                    }
                    break;


                case 107:    /* LD L,E */
                    {
                        cpu.LD(Registers.regL, Registers.regE);

                    }
                    break;


                case 108:    /* LD L,H */
                    {
                        cpu.LD(Registers.regL, Registers.regH);

                    }
                    break;


                case 109:    /* LD L,L */
                    {
                        cpu.LD(Registers.regL, Registers.regL);
                    }
                    break;


                case 111:    /* LD L,A */
                    {
                        cpu.LD(Registers.regL, Registers.regA);

                    }
                    break;

                case 120:    /* LD A,B */
                    {
                        cpu.LD(Registers.regA, Registers.regB);

                    }
                    break;


                case 121:    /* LD A,C */
                    {
                        cpu.LD(Registers.regA, Registers.regC);

                    }
                    break;


                case 122:    /* LD A,D */
                    {
                        cpu.LD(Registers.regA, Registers.regD);

                    }
                    break;


                case 123:    /* LD A,E */
                    {
                        cpu.LD(Registers.regA, Registers.regE);

                    }
                    break;


                case 124:    /* LD A,H */
                    {
                        cpu.LD(Registers.regA, Registers.regH);

                    }
                    break;


                case 125:    /* LD A,L */
                    {
                        cpu.LD(Registers.regA, Registers.regL);

                    }
                    break;


                case 127:    /* LD A,A */
                    {
                        cpu.LD(Registers.regA, Registers.regA);
                    }
                    break;

                /* LD *,N */
                case 6:    /* LD B,n */
                    {
                        cpu.LD_REG8_NN(Registers.regB);

                    }
                    break;


                case 14:    /* LD C,n */
                    {
                        cpu.LD_REG8_NN(Registers.regC);

                    }
                    break;


                case 22:    /* LD D,n */
                    {
                        cpu.LD_REG8_NN(Registers.regD);

                    }
                    break;


                case 30:    /* LD E,n */
                    {
                        cpu.LD_REG8_NN(Registers.regE);

                    }
                    break;

                case 38:    /* LD H,n */
                    {
                        cpu.LD_REG8_NN(Registers.regH);

                    }
                    break;


                case 46:    /* LD L,n */
                    {
                        cpu.LD_REG8_NN(Registers.regL);

                    }
                    break;


                case 62:    /* LD A,n */
                    {
                        cpu.LD_REG8_NN(Registers.regA);

                    }
                    break;

                /* LD (HL),* */

                case 112:    /* LD (HL),B */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regB);

                    }
                    break;

                case 113:    /* LD (HL),C */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regC);

                    }
                    break;


                case 114:    /* LD (HL),D */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regD);

                    }
                    break;

                case 115:    /* LD (HL),E */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regE);

                    }
                    break;

                case 116:    /* LD (HL),H */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regH);

                    }
                    break;

                case 117:    /* LD (HL),L */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regL);

                    }
                    break;

                case 119:    /* LD (HL),A */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regHL, Registers.regA);

                    }
                    break;

                case 70:    /* LD B,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regB, Registers.regHL);

                    }
                    break;

                case 78:    /* LD C,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regC, Registers.regHL);

                    }
                    break;

                case 86:    /* LD D,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regD, Registers.regHL);

                    }
                    break;

                case 94:    /* LD E,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regE, Registers.regHL);

                    }
                    break;

                case 102:    /* LD H,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regH, Registers.regHL);

                    }
                    break;

                case 110:    /* LD L,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regL, Registers.regHL);

                    }
                    break;

                case 126:    /* LD A,(HL) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regA, Registers.regHL);

                    }
                    break;

                case 54:    /* LD (HL),n */
                    {
                        cpu.LD_ToWherePointsR16_NN(Registers.regHL);

                    }
                    break;

                case 10:    /* LD A,(BC) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regA, Registers.regBC);

                    }
                    break;

                case 2:    /* LD (BC),A */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regBC, Registers.regA);

                    }
                    break;

                case 26:    /* LD A,(DE) */
                    {
                        cpu.LD_REG8_FromWherePointsR16(Registers.regA, Registers.regDE);
                    }
                    break;

                case 18:    /* LD (DE),A */
                    {
                        cpu.LD_ToWherePointsR16_REG8(Registers.regDE, Registers.regA);

                    }
                    break;

                case 50:    /* LD (nn),A */
                    {
                        cpu.LD_MEM_REG8(Registers.regA);
                    }
                    break;

                case 58:    /* LD A,(nn) */
                    {
                        cpu.LD_REG8_MEM(Registers.regA);
                    }
                    break;

                case 1:    /* LD BC(),nn */
                    {
                        cpu.LD_REG16_NN(Registers.regBC);

                    }
                    break;


                case 17:    /* LD DE,nn */
                    {
                        cpu.LD_REG16_NN(Registers.regDE);

                    }
                    break;

                case 33:    /* LD HL,nn */
                    {
                        cpu.LD_REG16_NN(Registers.regHL);

                    }
                    break;

                case 49:    /* LD SP,nn */
                    {
                        cpu.LD_REG16_NN(Registers.regSP);
                    }
                    break;

                case 34:    /* LD (nn),HL */
                    {
                        cpu.LD_MEM_REG16(Registers.regHL);
                    }
                    break;

                case 42:    /* LD HL,(nn) */
                    {
                        cpu.LD_REG16_FromWherePointsOp(Registers.regHL);
                    }
                    break;

                case 249:  /* LD SP,HL*/
                    {
                        cpu.LD(Registers.regSP, Registers.regHL);

                    }
                    break;

                /*
                 * Stack operations, PUSH, POP.
                 */
                /* PUSH,Various */
                case 197:    /* PUSH BC */
                    {
                        cpu.PUSH(Registers.regBC);
                    }
                    break;

                case 213:    /* cpu.PUSH DE */
                    {
                        cpu.PUSH(Registers.regDE);
                    }
                    break;

                case 229:    /* cpu.PUSH HL */
                    {
                        cpu.PUSH(Registers.regHL);
                    }
                    break;

                case 245:    /* cpu.PUSH AF */
                    {
                        cpu.PUSH(Registers.regAF);
                    }
                    break;

                /* POP,Various */

                case 193:    /* POP BC */
                    {
                        cpu.POP(Registers.regBC);
                    }
                    break;

                case 209:    /* POP DE */
                    {
                        cpu.POP(Registers.regDE);
                    }
                    break;

                case 225:    /* POP HL */
                    {
                        cpu.POP(Registers.regHL);
                    }
                    break;

                case 241:    /* POP AF */
                    {
                        cpu.POP(Registers.regAF);
                    }
                    break;

                /*
                 * EX instructions, exchange registers, stack with hl...
                 */
                case 8:    /* EX AF,AF' */
                    {
                        cpu.EX_REG16_REG16(Registers.regAF, Registers.regAF_);

                    }
                    break;

                case 235:    /* EX DE,HL */
                    {
                        cpu.EX_REG16_REG16(Registers.regDE, Registers.regHL);
                    }
                    break;

                case 217:    /* EXX */
                    {
                        cpu.EXX();
                    }
                    break;


                case 227:    /* EX (SP),HL */
                    {
                        cpu.EX_ToWherePointsSP_HL();
                    }
                    break;

                /*
                 * Arithmetic instructions, ADD, SUB...
                 */
                /* ADD A,* */
                case 128:    /* ADD A,B */
                    {
                        cpu.ADD(Registers.regA, Registers.regB);
                    }
                    break;

                case 129:    /* ADD A,C */
                    {
                        cpu.ADD(Registers.regA, Registers.regC);
                    }
                    break;

                case 130:    /* ADD A,D */
                    {
                        cpu.ADD(Registers.regA, Registers.regD);
                    }
                    break;

                case 131:    /* ADD A,E */
                    {
                        cpu.ADD(Registers.regA, Registers.regE);
                    }
                    break;

                case 132:    /* ADD A,H */
                    {
                        cpu.ADD(Registers.regA, Registers.regH);
                    }
                    break;

                case 133:    /* ADD A,L */
                    {
                        cpu.ADD(Registers.regA, Registers.regL);
                    }
                    break;

                case 135:    /* ADD A,A */
                    {
                        cpu.ADD(Registers.regA, Registers.regA);
                    }
                    break;

                /* SUB * */
                case 144:    /* SUB B */
                    {
                        cpu.SUB(Registers.regA, Registers.regB);
                    }
                    break;

                case 145:    /* SUB C */
                    {
                        cpu.SUB(Registers.regA, Registers.regC);
                    }
                    break;

                case 146:    /* SUB D */
                    {
                        cpu.SUB(Registers.regA, Registers.regD);
                    }
                    break;

                case 147:    /* SUB E */
                    {
                        cpu.SUB(Registers.regA, Registers.regE);
                    }
                    break;

                case 148:    /* SUB H */
                    {
                        cpu.SUB(Registers.regA, Registers.regH);
                    }
                    break;

                case 149:    /* SUB L */
                    {
                        cpu.SUB(Registers.regA, Registers.regL);
                    }
                    break;

                case 151:    /* SUB A() */
                    {
                        cpu.SUB(Registers.regA, Registers.regA);
                    }
                    break;

                /* ADC A,* */
                case 136:    /* ADC A,B */
                    {
                        cpu.ADC(Registers.regA, Registers.regB);
                    }
                    break;


                case 137:    /* ADC A,C */
                    {

                        cpu.ADC(Registers.regA, Registers.regC);


                    }
                    break;


                case 138:    /* ADC A,D */
                    {

                        cpu.ADC(Registers.regA, Registers.regD);


                    }
                    break;

                case 139:    /* ADC A,E */
                    {

                        cpu.ADC(Registers.regA, Registers.regE);


                    }
                    break;

                case 140:    /* ADC A,H */
                    {

                        cpu.ADC(Registers.regA, Registers.regH);


                    }
                    break;

                case 141:    /* ADC A,L */
                    {

                        cpu.ADC(Registers.regA, Registers.regL);


                    }
                    break;

                case 143:    /* ADC A,A */
                    {

                        cpu.ADC(Registers.regA, Registers.regA);


                    }
                    break;

                /* SBC A,* */
                case 152:    /* SBC A,B */
                    {

                        cpu.SBC(Registers.regA, Registers.regB);

                    }
                    break;

                case 153:    /* SBC A,C */
                    {

                        cpu.SBC(Registers.regA, Registers.regC);

                    }
                    break;

                case 154:    /* SBC A,D */
                    {

                        cpu.SBC(Registers.regA, Registers.regD);

                    }
                    break;

                case 155:    /* SBC A,E */
                    {

                        cpu.SBC(Registers.regA, Registers.regE);

                    }
                    break;

                case 156:    /* SBC A,H */
                    {

                        cpu.SBC(Registers.regA, Registers.regH);

                    }
                    break;

                case 157:    /* SBC A,L */
                    {

                        cpu.SBC(Registers.regA, Registers.regL);

                    }
                    break;

                case 159:    /* SBC A,A */
                    {

                        cpu.SBC(Registers.regA, Registers.regA);

                    }
                    break;

                case 198: /* ADD A,N */
                    {
                        cpu.ADD_N(Registers.regA);
                    }
                    break;

                case 214: /* SUB N */
                    {
                        cpu.SUB_N(Registers.regA);
                    }
                    break;

                case 206: /* ADC A,N */
                    {
                        cpu.ADC_N(Registers.regA);
                    }
                    break;

                case 222: /* SBC A,N */
                    {
                        cpu.SBC_N(Registers.regA);
                    }
                    break;

                case 134:    /* ADD A,(HL) */
                    {
                        cpu.ADD_FromWherePointsHL(Registers.regA);
                    }
                    break;

                case 150:    /* SUB (HL) */
                    {
                        cpu.SUB_FromWherePointsHL(Registers.regA);
                    }
                    break;

                case 142:    /* ADC A,(HL) */
                    {
                        cpu.ADC_FromWherePointsHL(Registers.regA);
                    }
                    break;

                case 158:    /* SBC A,(HL) */
                    {
                        cpu.SBC_FromWherePointsHL(Registers.regA);
                    }
                    break;
                /*
                 * INC, DEC instructions
                 */
                case 4:    /* INC B */
                    {
                        cpu.INC(Registers.regB);
                    }
                    break;

                case 12:    /* INC C */
                    {
                        cpu.INC(Registers.regC);
                    }
                    break;

                case 20:    /* INC D */
                    {
                        cpu.INC(Registers.regD);
                    }
                    break;

                case 28:    /* INC E */
                    {
                        cpu.INC(Registers.regE);
                    }
                    break;

                case 36:    /* INC H */
                    {
                        cpu.INC(Registers.regH);
                    }
                    break;

                case 44:    /* INC L */
                    {
                        cpu.INC(Registers.regL);
                    }
                    break;

                case 60:    /* INC A() */
                    {
                        cpu.INC(Registers.regA);
                    }
                    break;

                /* DEC * */
                case 5:    /* DEC B */
                    {
                        cpu.DEC(Registers.regB);
                    }
                    break;

                case 13:    /* DEC C */
                    {
                        cpu.DEC(Registers.regC);
                    }
                    break;

                case 21:    /* DEC D */
                    {
                        cpu.DEC(Registers.regD);
                    }
                    break;

                case 29:    /* DEC E */
                    {
                        cpu.DEC(Registers.regE);
                    }
                    break;

                case 37:    /* DEC H */
                    {
                        cpu.DEC(Registers.regH);
                    }
                    break;

                case 45:    /* DEC L */
                    {
                        cpu.DEC(Registers.regL);
                    }
                    break;

                case 61:    /* DEC A() */
                    {
                        cpu.DEC(Registers.regA);
                    }
                    break;

                case 52:    /* INC (HL) */
                    {
                        cpu.INC_WherePointsHL();
                    }
                    break;

                case 53:    /* DEC (HL) */
                    {
                        cpu.DEC_WherePointsHL();
                    }
                    break;

                /*
                 * AND, XOR, OR instructions
                 */

                case 160:    /* AND B */
                    {
                        cpu.AND(Registers.regA, Registers.regB);
                    }
                    break;

                case 161:    /* AND C */
                    {
                        cpu.AND(Registers.regA, Registers.regC);
                    }
                    break;

                case 162:    /* AND D */
                    {
                        cpu.AND(Registers.regA, Registers.regD);
                    }
                    break;

                case 163:    /* AND E */
                    {
                        cpu.AND(Registers.regA, Registers.regE);
                    }
                    break;

                case 164:    /* AND H */
                    {
                        cpu.AND(Registers.regA, Registers.regH);
                    }
                    break;

                case 165:    /* AND L */
                    {
                        cpu.AND(Registers.regA, Registers.regL);
                    }
                    break;

                case 167:    /* AND A() */
                    {
                        cpu.AND(Registers.regA, Registers.regA);
                    }
                    break;

                /* OR * */
                case 176:    /* OR B */
                    {
                        cpu.OR(Registers.regA, Registers.regB);
                    }
                    break;

                case 177:    /* OR C */
                    {
                        cpu.OR(Registers.regA, Registers.regC);
                    }
                    break;

                case 178:    /* OR D */
                    {
                        cpu.OR(Registers.regA, Registers.regD);
                    }
                    break;

                case 179:    /* OR E */
                    {
                        cpu.OR(Registers.regA, Registers.regE);
                    }
                    break;

                case 180:    /* OR H */
                    {
                        cpu.OR(Registers.regA, Registers.regH);
                    }
                    break;

                case 181:    /* OR L */
                    {
                        cpu.OR(Registers.regA, Registers.regL);
                    }
                    break;

                case 183:    /* OR A() */
                    {
                        cpu.OR(Registers.regA, Registers.regA);
                    }
                    break;

                /* XOR * */
                case 168:    /* XOR B */
                    {
                        cpu.XOR(Registers.regA, Registers.regB);
                    }
                    break;

                case 169:    /* XOR C */
                    {
                        cpu.XOR(Registers.regA, Registers.regC);
                    }
                    break;

                case 170:    /* XOR D */
                    {
                        cpu.XOR(Registers.regA, Registers.regD);
                    }
                    break;

                case 171:    /* XOR E */
                    {
                        cpu.XOR(Registers.regA, Registers.regE);
                    }
                    break;

                case 172:    /* XOR H */
                    {
                        cpu.XOR(Registers.regA, Registers.regH);
                    }
                    break;

                case 173:    /* XOR L */
                    {
                        cpu.XOR(Registers.regA, Registers.regL);
                    }
                    break;


                case 175:    /* XOR A() */
                    {
                        cpu.XOR(Registers.regA, Registers.regA);
                    }
                    break;

                /* CP * */
                case 184:    /* CP B */
                    {
                        cpu.CP(Registers.regA, Registers.regB);
                    }
                    break;

                case 185:    /* CP C */
                    {
                        cpu.CP(Registers.regA, Registers.regC);
                    }
                    break;

                case 186:    /* CP D */
                    {
                        cpu.CP(Registers.regA, Registers.regD);
                    }
                    break;

                case 187:    /* CP E */
                    {
                        cpu.CP(Registers.regA, Registers.regE);
                    }
                    break;

                case 188:    /* CP H */
                    {
                        cpu.CP(Registers.regA, Registers.regH);
                    }
                    break;

                case 189:    /* CP L */
                    {
                        cpu.CP(Registers.regA, Registers.regL);
                    }
                    break;

                case 191:    /* CP A() */
                    {
                        cpu.CP(Registers.regA, Registers.regA);
                    }
                    break;

                case 230: /* AND N */
                    {
                        cpu.AND_N(Registers.regA);
                    }
                    break;

                case 246: /* OR N */
                    {
                        cpu.OR_N(Registers.regA);
                    }
                    break;

                case 254: /* CP N */
                    {
                        cpu.CP_N(Registers.regA);
                    }
                    break;

                case 238: /* XOR N */
                    {
                        cpu.XOR_N(Registers.regA);
                    }
                    break;

                case 166:    /* AND (HL) */
                    {
                        cpu.AND_FromWherePointsHL(Registers.regA);
                    }
                    break;

                case 182:    /* OR (HL) */
                    {
                        cpu.OR_FromWherePointsHL(Registers.regA);
                    }
                    break;

                case 174:    /* XOR (HL) */
                    {
                        cpu.XOR_FromWherePointsHL(Registers.regA);
                    }
                    break;

                case 190:    /* CP (HL) */
                    {
                        cpu.CP_FromWherePointsHL(Registers.regA);
                    }
                    break;

                /*
                 * Carry flag instructions, scf, ccf
                 */

                case 55: /* SCF */
                    {
                        cpu.SCF();
                    }
                    break;

                case 63: /* CCF */
                    {
                        cpu.CCF();
                    }
                    break;

                /*
                 * Interrupt instructions
                 */
                case 251:    /* EI */
                    {
                        cpu.EI();
                    }
                    break;

                case 243:    /* DI */
                    {
                        cpu.DI();
                    }
                    break;

                case 118:    /* HALT */
                    {
                        cpu.HALT();
                    }
                    break;
                /*
                 * 16bit arithmetic
                 */
                /* LD rr,nn / ADD HL,rr */
                case 9:    /* ADD HL,BC */
                    {
                        cpu.ADD(Registers.regHL, Registers.regBC);
                    }
                    break;

                case 25:    /* ADD HL,DE */
                    {
                        cpu.ADD(Registers.regHL, Registers.regDE);
                    }
                    break;

                case 41:    /* ADD HL,HL */
                    {
                        cpu.ADD(Registers.regHL, Registers.regHL);
                    }
                    break;

                case 57:    /* ADD HL,SP */
                    {
                        cpu.ADD(Registers.regHL, Registers.regSP);
                    }
                    break;

                /* INC/DEC * */
                case 3:    /* INC BC */
                    {
                        cpu.INC(Registers.regBC);
                    }
                    break;

                case 11:    /* DEC BC */
                    {
                        cpu.DEC(Registers.regBC);
                    }
                    break;

                case 19:    /* INC DE */
                    {
                        cpu.INC(Registers.regDE);
                    }
                    break;

                case 27:    /* DEC DE */
                    {
                        cpu.DEC(Registers.regDE);
                    }
                    break;

                case 35:    /* INC HL */
                    {
                        cpu.INC(Registers.regHL);
                    }
                    break;

                case 43:    /* DEC HL */
                    {
                        cpu.DEC(Registers.regHL);
                    }
                    break;

                case 51:    /* INC SP */
                    {
                        cpu.INC(Registers.regSP);
                    }
                    break;

                case 59:    /* DEC SP */
                    {
                        cpu.DEC(Registers.regSP);
                    }
                    break;

                /*
                 * Rotations A register
                 */
                /* R**A */
                case 7: /* RLCA */
                    {
                        cpu.RLCA();
                    }
                    break;

                case 15: /* RRCA */
                    {
                        cpu.RRCA();
                    }
                    break;

                case 23: /* RLA */
                    {
                        cpu.RLA();
                    }
                    break;

                case 31: /* RRA */
                    {
                        cpu.RRA();
                    }
                    break;

                /*
                 * Jumps, jp, jr, call, ret, rst
                 */
                case 195: /*JP N*/
                    {
                        cpu.JP_N();
                    }
                    break;

                case 233: /* JP (HL) */
                    {
                        cpu.JP_HL();
                    }
                    break;

                case 194:    /* JP NZ,nn */
                    {
                        cpu.JP_NZ_NN();
                    }
                    break;

                case 202:    /* JP Z,nn */
                    {
                        cpu.JP_Z_NN();
                    }
                    break;

                case 210:    /* JP NC,nn */
                    {
                        cpu.JP_NC_NN();
                    }
                    break;

                case 218:    /* JP C,nn */
                    {
                        cpu.JP_C_NN();
                    }
                    break;

                case 226:    /* JP PO,nn */
                    {
                        cpu.JP_PO_NN();
                    }
                    break;

                case 234:    /* JP PE,nn */
                    {
                        cpu.JP_PE_NN();
                    }
                    break;

                case 242:    /* JP P,nn */
                    {
                        cpu.JP_P_NN();
                    }
                    break;

                case 250:    /* JP M,nn */
                    {
                        cpu.JP_M_NN();
                    }
                    break;

                case 16:    /* DJNZ dis */
                    {
                        cpu.DJNZ();
                    }
                    break;

                case 24: /* JR dis */
                    {
                        cpu.JR();
                    }
                    break;

                case 32:    /* JR NZ,dis */
                    {
                        cpu.JR_NZ();
                    }
                    break;

                case 40:    /* JR Z,dis */
                    {
                        cpu.JR_Z();
                    }
                    break;

                case 48:    /* JR NC,dis */
                    {
                        cpu.JR_NC();
                    }
                    break;

                case 56:    /* JR C,dis */
                    {
                        cpu.JR_C();
                    }
                    break;

                case 205:    /* CALL nn */
                    {
                        cpu.CALL();
                    }
                    break;

                case 201: /* RET */
                    {
                        cpu.RET();
                    }
                    break;

                case 196: /* CALL NZ,nn */
                    {
                        cpu.CALL_NZ();
                    }
                    break;

                case 204: /* CALL Z,nn */
                    {
                        cpu.CALL_Z();
                    }
                    break;

                case 212: /* CALL NC,nn */
                    {
                        cpu.CALL_NC();
                    }
                    break;

                case 220: /* CALL C,nn */
                    {
                        cpu.CALL_C();
                    }
                    break;

                case 244: /* CALL P,nn */
                    {
                        cpu.CALL_P();
                    }
                    break;

                case 252: /* CALL M,nn */
                    {
                        cpu.CALL_M();
                    }
                    break;

                case 236: /* CALL PE,nn */
                    {
                        cpu.CALL_PE();
                    }
                    break;

                case 228: /* CALL PO,nn */
                    {
                        cpu.CALL_PO();
                    }
                    break;

                /* RET cc */
                case 192:    /* RET NZ */
                    {
                        cpu.RET_NZ();
                    }
                    break;

                case 200:    /* RET Z */
                    {
                        cpu.RET_Z();
                    }
                    break;

                case 208:    /* RET NC */
                    {
                        cpu.RET_NC();
                    }
                    break;

                case 216:    /* RET C */
                    {
                        cpu.RET_C();
                    }
                    break;

                case 224:    /* RET PO */
                    {
                        cpu.RET_PO();
                    }
                    break;

                case 232:    /* RET PE */
                    {
                        cpu.RET_PE();
                    }
                    break;

                case 240:    /* RET P */
                    {
                        cpu.RET_P();
                    }
                    break;

                case 248:    /* RET M */
                    {
                        cpu.RET_M();
                    }
                    break;

                /* RST n */
                case 199:    /* RST 0 */
                    {
                        cpu.RST(0);
                    }
                    break;

                case 207:    /* RST 8 */
                    {
                        cpu.RST(8);
                    }
                    break;

                case 215:    /* RST 16 */
                    {
                        cpu.RST(16);
                    }
                    break;

                case 223:    /* RST 24 */
                    {
                        cpu.RST(24);
                    }
                    break;

                case 231:    /* RST 32 */
                    {
                        cpu.RST(32);
                    }
                    break;

                case 239:    /* RST 40 */
                    {
                        cpu.RST(40);
                    }
                    break;

                case 247:    /* RST 48 */
                    {
                        cpu.RST(48);
                    }
                    break;

                case 255:    /* RST 56 */
                    {
                        cpu.RST(56);
                    }
                    break;

                /*
                 * I/O instructions, in, out
                 */

                case 211:    /* OUT (n),A */
                    {
                        cpu.OUT(Registers.regA);
                    }
                    break;

                case 219:    /* IN A,(n) */
                    {
                        cpu.IN(Registers.regA);
                    }
                    break;


                /*
                 * Prefixes
                 */
                case 203:
                    {
                        prefix203.Parse();
                    }
                    break;

                case 221:
                    {
                        prefix221.Parse();
                    }
                    break;

                case 253:
                    {
                        prefix253.Parse();
                    }
                    break;

                case 237:
                    {
                        prefix237.Parse();
                    }
                    break;

                default:
                    {
                        MessageBox.Show("CPUparser, Instruction not supported, code: " + code + ", address: " + Registers.regPC.Get());
                    }
                    break;

            }

            Globals.CPUparserInProgress = false; //parser finished, new data can be loaded from disk.
        }


        //end of class
    }
}

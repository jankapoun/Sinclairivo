using System;
using System.Collections.Generic;
using System.Text;

namespace Sinclairivo.NET
{
    /*
     * This class contains all the ZXS CPU flags
     * 
     */
    public class Flags
    {
        private Reg8 regF = new Reg8(0);

        /*
        * Constructor, Registry class must be passed as argument
        */
        public Flags(Registers r)
        {
            //this.regF = r.regF; possible mistake
            this.regF = Registers.regF;
        }

        /*
         * Carry flag, 0. bit
         */
        public bool GetCarry() //0.bit
        {
            if ((regF.Get() & 1) == 0) return false;
            else return true;
        }

        public int GetCarryAsZeroOrOne()
        {
            return (regF.Get() & 1);
        }

        public void SetCarry(bool b)
        {
            if (b) { regF.Set(regF.Get() | 1); } //set 0.bit
            else { regF.Set(regF.Get() & 254); } //reset 0. bit; }
        }

        /*
        * Complement carry flag
        */
        public void CCFCarry()
        {
            if ((regF.Get() & 1) == 0) { SetCarry(true); }
            else
            {
                regF.Set(regF.Get() & 254); //reset 0. bit;
            }
        }

        /*
        * N_Substraction flag, 1. bit
        */
        public bool GetN_Substraction() //1.bit
        {
            if ((regF.Get() & 2) == 0) return false;
            else return true;
                
        }

        public void SetN_Substraction(bool b)
        {
            if (b) { regF.Set(regF.Get() | 2); } //set 1.bit
            else { regF.Set(regF.Get() & 253); } //reset 1. bit; }
        }


        /*
        * PV flag, 2. bit
        */
        public bool GetPV() //2.bit
        {
            if ((regF.Get() & 4) == 0) return false;
            else return true;
        }

        public void SetPV(bool b)
        {
            if (b) { regF.Set(regF.Get() | 4); } //set 2.bit
            else { regF.Set(regF.Get() & 251); } //reset 2. bit; }
        }

        /*
        * 3 bit flag, 3. bit
        */
        public bool GetFlagBit3() //3.bit
        {
            if ((regF.Get() & 8) == 0) return false;
            else return true;
        }

        public void SetFlagBit3(bool b)
        {
            if (b) { regF.Set(regF.Get() | 8); } //set 3.bit
            else { regF.Set(regF.Get() & 247); } //reset 3. bit; }
        }

        /*
        * Half carry flag, 4. bit
        */
        public bool GetHalfCarry() //4.bit
        {
            if ((regF.Get() & 16) == 0) return false;
            else return true;
        }

        public void SetHalfCarry(bool b)
        {
            if (b) { regF.Set(regF.Get() | 16); } //set 4.bit
            else { regF.Set(regF.Get() & 239); } //reset 4. bit; }
        }

        /*
        * Flag bit 5 flag, 5. bit
        */
        public bool GetFlagBit5() //5.bit
        {
            if ((regF.Get() & 32) == 0) return false;
            else return true;
        }

        public void SetFlagBit5(bool b)
        {
            if (b) { regF.Set(regF.Get() | 32); } //set 5.bit
            else { regF.Set(regF.Get() & 223); } //reset 5. bit; }
        }


        /*
        * Zero flag, 6. bit
        */
        public bool GetZero() //6.bit
        {
            if ((regF.Get() & 64) == 0) return false;
            else return true;
        }

        public void SetZero(bool b)
        {
            if (b) { regF.Set(regF.Get() | 64); } //set 6.bit
            else { regF.Set(regF.Get() & 191); } //reset 6. bit; }
        }

        /*
        * Sign flag, 7. bit
        */
        public bool GetSign() //7.bit
        {
            if ((regF.Get() & 128) == 0) return false;
            else return true;
        }

        public void SetSign(bool b)
        {
            if (b) { regF.Set(regF.Get() | 128); } //set 7.bit
            else { regF.Set(regF.Get() & 127); } //reset 7. bit; }
        }

  

        //end of class
    }
}

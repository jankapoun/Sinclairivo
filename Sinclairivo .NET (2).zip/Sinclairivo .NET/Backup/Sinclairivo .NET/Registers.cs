using System;
using System.Collections.Generic;
using System.Text;

namespace Sinclairivo.NET
{

/**
 * Contains all the ZXS registry
 * @author Jan Kapoun, Mgr.
 */
    public class Registers
    {

    public Registers()
    {}
            
 /**
 * Interrupt, refresh, flag, stack and program counter registry
 */
    public static bool regIFF = false; //flip-flop registry, interrupt enabled/disabled
    public static bool regIFF2 = regIFF;
    public static Reg8 im = new Reg8(0); //mod preruseni
    public static Reg8 regR = new Reg8(0); //refresh registry
    public static Reg8 regI = new Reg8(0); //interrupt registry
    public static Reg8 regF = new Reg8(0); //flag registry
    public static Reg8 regF_ = new Reg8(0); //reserve flag registry
    public static Reg16 regSP = new Reg16(0, "Stack pointer"); //stack
    public static Reg16 regPC = new Reg16(0, "Program counter"); //program counter
    
    
 /**
 * Standard registry
 * 
 */
        public static Reg8 regA = new Reg8(0);
        public static Reg8 regB = new Reg8(0);
        public static Reg8 regC = new Reg8(0);
        public static Reg8 regD = new Reg8(0);
        public static Reg8 regE = new Reg8(0);
        public static Reg8 regH = new Reg8(0);
        public static Reg8 regL = new Reg8(0);
        public static Reg8 regLX = new Reg8(0);
        public static Reg8 regHX = new Reg8(0);
        public static Reg8 regLY = new Reg8(0);
        public static Reg8 regHY = new Reg8(0);
        public static Reg16 regAF = new Reg16(regA, regF);
        public static Reg16 regBC = new Reg16(regB, regC);
        public static Reg16 regDE = new Reg16(regD, regE);
        public static Reg16 regHL = new Reg16(regH, regL);
        public static Reg16 regIX = new Reg16(regHX, regLX);
        public static Reg16 regIY = new Reg16(regHY, regLY);
        
 /**
 * Reserve registry
 */
        public static Reg8 regA_ = new Reg8(0);
        public static Reg8 regB_ = new Reg8(0);
        public static Reg8 regC_ = new Reg8(0);
        public static Reg8 regD_ = new Reg8(0);
        public static Reg8 regE_ = new Reg8(0);
        public static Reg8 regH_ = new Reg8(0);
        public static Reg8 regL_ = new Reg8(0);
        public static Reg16 regAF_ = new Reg16(regA_, regF_);
        public static Reg16 regBC_ = new Reg16(regB_, regC_);
        public static Reg16 regDE_ = new Reg16(regD_, regE_);
        public static Reg16 regHL_ = new Reg16(regH_, regL_);
        
/**
 * Registry related routines
 */
        
 /**
 * Refreshes the R register (increases)
 */
  public static void Refresh_R()
  {
        regR.Inc();
  }
        
  
 /**
 * Sets the PC relatively, used in jumps
 */         
   public static void SetPCRelativJump(short i)
    {
       regPC.Plus(i);
    }

   
        //end of class
    }
}

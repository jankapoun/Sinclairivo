using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Sinclairivo.NET
{
/**
 * Contains the CPU parsing related routines
 * 
 */
    public class CPUroutines
    {

 
    private RAM ram;
    private Flags flags;
    private Ports ports;
    private Registers regs;
    private bool[] parity = new bool[256]; //the result parity table
    private int TCycleStates = 0;
    private bool halt = false;
    private bool doInterrupt = false; 
    
    private const int F_C  = 0x01;
    private const int F_N  = 0x02;
    private const int F_PV = 0x04;
    private const int F_3  = 0x08;
    private const int F_H  = 0x10;
    private const int F_5  = 0x20;
    private const int F_Z  = 0x40;
    private const int F_S  = 0x80;


    public CPUroutines(RAM ram, Flags flags, Ports ports, Registers regs)
    {
        this.ram = ram;
        this.flags = flags;
        this.ports = ports;
        this.regs = regs;
        this.CreatePV();
    }
    
    public bool GetInterruptRequest()
    {
        return doInterrupt;
    }
    
    public void SetInterruptRequest(bool b)
    {
        doInterrupt = b;
    }
    
    /**
     * Calls the interrupt routine.
     */
    public void CallIM()
    {
        SetInterruptRequest(false);
        halt = true;
        
        if ((Registers.regIFF == true) && (Registers.im.Get() == 1))
        { 
           CALL_IM1();
        }

        if ((Registers.regIFF == true) && (Registers.im.Get() == 2))
        { 
            CALL_IM2(); 
        }
        
    }
    
    
/**
 * Creates the PV table, needed for arithmetic and other
 * operations.
 */ 
public void CreatePV()
    {
            for (int i = 0; i < 256; i++)
            {
                bool p = true;
                for (int j = 0; j < 8; j++)
                {
                    if ((i & (1 << j)) != 0)
                    {
                        p = !p;
                    }
                }
                parity[i] = p;
            }
    }
    
/**
 * Refreshes (increases) the R register.
 * Only invokes the same routine in Registers.
 */ 
    public void Refresh_R()
    {
        Registers.Refresh_R();
    }

/**
 * Halts the instruction execution for a specified number
 * of ZXS T-cycles
 */ 
   public void WaitTCycle(int tc) 
    {
            TCycleStates += tc;
            SynchronizeCPUSpeed();
    }
   
   /**
    * Slows down to the original ZX Spectrum CPU speed.
    */
  public void SynchronizeCPUSpeed()
  {
        if (TCycleStates >= 70000) 
        {
           try  
           {
               if (Globals.CPUspeed != 1){ Thread.Sleep( Globals.CPUspeed );}
           }
           catch (Exception e) { MessageBox.Show(e.Message); }

            TCycleStates = 0;

            if (Registers.regIFF == true){ SetInterruptRequest(true);}
            
        }
        
        
  
  }

/**
 * Fetches next instruction or just data byte.
 * (Depends on the context.)
 */ 
    public int Fetch() //dodej kod instrukce a zvys reg R
    {
            int b = ram.ReadRAM(Registers.regPC.Get());
            Registers.regPC.Inc(); //po kazdem cteni reg PC ho automaticky zvysuj
            return b;
    }

/**   16bit index operation instructions have 2 prefixes. In a 4byte instruction, 
*  the actual instruction code lies as the last one, the shift code
*  lies on the 3rd place.
 * Fetches the previous instruction or byte (depends on the context)
 */ 
    public int FetchPreviousByte() 
    {
            int b = ram.ReadRAM(Registers.regPC.Get() - 2);
            return b;
    }
    
/**
 * 
 * Returns the NN value stored as instruction operand
 */
    public int FetchWord() 
    {
            int x = (Fetch() + (Fetch() * 256));
            return x;
    }
    
/**
 * Ignores 1 byte and increases the PC reg.
 */ 
    public void IgnoreByte()
    {
           Registers.regPC.Inc();
    }
    
    public void NOP()
    {
        WaitTCycle(4);
    }
    
   /**
     *  DAA 
     */
    public void DAA() 
    {
        int        ans = Registers.regA.Get();
        int        incr = 0;
        bool    carry = flags.GetCarry();

        if ((flags.GetHalfCarry()) || ((ans & 0x0f) > 0x09)) 
        {
                incr |= 0x06;
        }
        
        if (carry || (ans > 0x9f) || ((ans > 0x8f) && ((ans & 0x0f) > 0x09))) 
        {
                incr |= 0x60;
        }
        
        if (ans > 0x99) 
        {
                carry = true;
        }
        
        if (flags.GetN_Substraction()) 
        {
            Reg8 reg = new Reg8(incr);
            SUB(Registers.regA, reg);
        } 
        else 
        {
            Reg8 reg = new Reg8(incr);
            ADD(Registers.regA, reg);
        }

        ans = Registers.regA.Get();

        flags.SetCarry( carry );
        flags.SetPV( parity[ ans ] );
       
        WaitTCycle(4);
    }
    
    public void CPL(Reg8 reg)
    {
        
        int ans = Registers.regA.Get() ^ 0xff;

        flags.SetFlagBit3( (ans & F_3) != 0 );
        flags.SetFlagBit5( (ans & F_5) != 0 );
        flags.SetHalfCarry( true );    
        flags.SetN_Substraction( true );    

        Registers.regA.Set(ans);
        WaitTCycle(4);
    }
    
    public void LD(Reg8 regX, Reg8 regY)
    {
        regX.Set(regY.Get());
        WaitTCycle(4);
    }
    
    /**
     * LD I, A 
     * LD R, A
     */
    public void LD_I_R_A(Reg8 regX, Reg8 regY)
    {
        regX.Set(regY.Get());
        WaitTCycle(9);
    }
   
    /**
     * LD A, I 
     * LD A, R
     */
    public void LD_A_I_R(Reg8 regX, Reg8 regY)
    {
       
        int ans = regY.Get();

        flags.SetSign( (ans & F_S) != 0 );
        flags.SetFlagBit3( (ans & F_3) != 0 );
        flags.SetFlagBit5( (ans & F_5) != 0 );
        flags.SetZero( ans == 0 );
        flags.SetPV( Registers.regIFF2 );
        flags.SetHalfCarry( false );    
        flags.SetN_Substraction( false );    

        Registers.regA.Set(ans);

        WaitTCycle(9);
    }
   
    
    public void LD(Reg16 regX, Reg16 regY)
    {
        regX.Set(regY.Get());
        WaitTCycle(6);
    }
    
    public void LD(Reg16 regX, Reg16 regY, int TCycle)
    {
        regX.Set(regY.Get());
        WaitTCycle(TCycle);
    }
    
   /**
    *  LD A, N
    */
    public void LD_REG8_NN(Reg8 regX)
    {
        regX.Set(Fetch());
        WaitTCycle(7);
    }
    
    
   /**
    *  LD HL, NN
    */
    public void LD_REG16_NN(Reg16 regX)
    {
        regX.Set(FetchWord());
        WaitTCycle(10);
    }
    
    /**
    *  LD IX, NN
    */
    public void LD_REG16_NN(Reg16 regX, int TCycle)
    {
        regX.Set(FetchWord());
        WaitTCycle(TCycle);
    }
    
    /**
    *  LD (HL), A
    */
    public void LD_ToWherePointsR16_REG8(Reg16 reg16, Reg8 reg8)
    {
        ram.WriteRAM(reg16.Get(), reg8.Get());
        WaitTCycle(7);
    }
    
    /**
    *  LD (HL), NN
    */
    public void LD_ToWherePointsR16_NN(Reg16 reg16)
    {
        ram.WriteRAM(reg16.Get(), Fetch());
        WaitTCycle(10);
    }
    
   /**
    *  LD A, (HL)
    */
    public void LD_REG8_FromWherePointsR16(Reg8 reg8, Reg16 reg16)
    {
        reg8.Set(ram.ReadRAM(reg16.Get()));
        WaitTCycle(7);
    }
    
    /**
    *  LD HL, (NN)
    */
    public void LD_REG16_FromWherePointsOp(Reg16 reg16)
    {
        int addr = FetchWord();
        int low = ram.ReadRAM(addr);
        int high = ram.ReadRAM(addr + 1);
        reg16.Set(low + (256 * high));
        WaitTCycle(16);
    }
    
    /**
    *  LD HL,(NN)
    */
    public void LD_REG16_FromWherePointsOp(Reg16 reg16, int TCycle)
    {
        int addr = FetchWord();
        int low = ram.ReadRAM(addr);
        int high = ram.ReadRAM(addr + 1);
        reg16.Set(low + (256 * high));
        WaitTCycle(TCycle);
    }
   
    /**
    *  LD (NN), A
    */
    public void LD_MEM_REG8(Reg8 regX)
    {
        ram.WriteRAM(FetchWord(), regX.Get());
        WaitTCycle(13);
    }
   
    /**
    *  LD A,(NN)
    */
    public void LD_REG8_MEM(Reg8 regX)
    {
        regX.Set(ram.ReadRAM(FetchWord()));
        WaitTCycle(13);
    }
   
    /**
    *  LD (NN), HL
    */
    public void LD_MEM_REG16(Reg16 reg)
    {
         int addr = FetchWord();
         ram.WriteRAM(addr, (reg.Get() % 256));
         ram.WriteRAM((addr + 1), (reg.Get() / 256));
         WaitTCycle(16);
    }
    
   /**
    *  LD (NN), HL
    */
    public void LD_MEM_REG16(Reg16 reg, int TCycle)
    {
         int addr = FetchWord();
         ram.WriteRAM(addr, (reg.Get() % 256));
         ram.WriteRAM((addr + 1), (reg.Get() / 256));
         WaitTCycle(TCycle);
    }
   
    /*
    *  LD A,(IX + E)
    */
    public void LD_REG8_From_IndexReg(Reg8 r8, Reg16 r16 )
    {
       LD(r8, GetReg8FromWherePointsIX_IY_Shift(r16));
       WaitTCycle(19);
    }
   
   /**
    *  LD (IX + E),A
    */
    public void LD_ToWherePointsIndexReg_Reg8(Reg16 r16, Reg8 r8 )
    {
       ram.WriteRAM(GetIXaddressWithShift(r16), r8.Get());
       WaitTCycle(19);
    }
   
   /**
    *  LD (IX + E),N
    */
    public void LD_ToWherePointsIndexReg_NN(Reg16 r16)
    {
       ram.WriteRAM(GetIXaddressWithShift(r16), Fetch());
       WaitTCycle(19);
    }
    
    /**
    * LDI
    */
    public void LDI()
    {
        ram.WriteRAM(Registers.regDE.Get(), ram.ReadRAM(Registers.regHL.Get()));
        Registers.regDE.Inc(); Registers.regHL.Inc(); Registers.regBC.Dec();
        if (Registers.regBC.Get() == 0) { flags.SetPV(false); }
        else { flags.SetPV(true); }
        
        flags.SetN_Substraction(false);
        flags.SetHalfCarry(false);
        WaitTCycle(16);
    }
    
   /**
   * LDD
   */
   public void LDD()
    {
        ram.WriteRAM(Registers.regDE.Get(), ram.ReadRAM(Registers.regHL.Get()));
        Registers.regDE.Dec(); Registers.regHL.Dec(); Registers.regBC.Dec();
        if (Registers.regBC.Get() == 0) { flags.SetPV(false); }
        else { flags.SetPV(true); }
        
        flags.SetN_Substraction(false);
        flags.SetHalfCarry(false);
        WaitTCycle(16);
    }                           
   
   /**
   * LDDR
   */
   public void LDDR()
   {
        if (Registers.regBC.Get() != 0)
        {
            ram.WriteRAM(Registers.regDE.Get(), ram.ReadRAM(Registers.regHL.Get()));
            Registers.regDE.Dec(); Registers.regHL.Dec(); Registers.regBC.Dec();
            WaitTCycle(21);
            Registers.SetPCRelativJump(-2);
        }
        else { flags.SetPV(false); WaitTCycle(16); }
        
        flags.SetN_Substraction(false);
        flags.SetHalfCarry(false);
   }
   
   /**
   * LDIR
   */
   public void LDIR()
   {
       if (Registers.regBC.Get() != 0)
        {
            ram.WriteRAM(Registers.regDE.Get(), ram.ReadRAM(Registers.regHL.Get()));
            Registers.regDE.Inc(); Registers.regHL.Inc(); Registers.regBC.Dec();
            WaitTCycle(21);
            Registers.SetPCRelativJump(-2);
        }
        else { flags.SetPV(false); WaitTCycle(16); }
       
       flags.SetN_Substraction(false);
       flags.SetHalfCarry(false);
   }
   
    
   /**
    *  Sets flags accoding to the reg value.
    */
   private void setFlags(Reg8 reg)
   {
        if (reg.Get() > 127) { flags.SetSign(true);}
        else { flags.SetSign(false);}
        if (reg.Get() == 0) { flags.SetZero(true);}
        else {flags.SetZero(false);}
        
        flags.SetPV(parity[reg.Get()]);
   }
   
   /**
    *  INC A
    */
    public Reg8 INC(Reg8 reg)
    {
            bool    pv = (reg.Get() == 0x7f);
            bool    h  = (((reg.Get() & 0x0f) + 1) & F_H) != 0;

            reg.Inc();

            flags.SetSign((reg.Get() & F_S) != 0 );
            flags.SetFlagBit3((reg.Get() & F_3) != 0 );
            flags.SetFlagBit5((reg.Get() & F_5) != 0 );
            flags.SetZero((reg.Get()) == 0 );
            flags.SetPV( pv );
            flags.SetHalfCarry( h );
            flags.SetN_Substraction(false);
            
            WaitTCycle(4);
            return reg;
    }
   
   /**
    *  INC BC
    */
    public void INC(Reg16 reg)
    {
        reg.Inc();
        WaitTCycle(6);
    
    }

    public Reg8 INC(Reg8 reg, int TCycle)
    {
            INC(reg);
            WaitTCycle(TCycle);
            return reg;
    }
  
   /**
    *  INC IX/IY
    */
    public void INC_IndexReg(Reg16 reg)
    {
            reg.Inc();
            WaitTCycle(10);
    }
    
    
    /*
    *  INC (HL)
    */
    public void INC_WherePointsHL()
    {
        int addr = Registers.regHL.Get();
        Reg8 reg = new Reg8(FromWherePointsReg16(Registers.regHL));
        INC(reg);
        ram.WriteRAM(addr, reg.Get());
        WaitTCycle(11);
    }
   
    /*
    *  INC (IX + N)
    */
    public void INC_WherePointsIX_Shift(Reg16 regXY)
    {
        int shift = this.GetRelativeShift();
        Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
        INC(reg);
        ram.WriteRAM((regXY.Get() + shift), reg.Get());
        WaitTCycle(23);
  
    }
       
    
     public void DEC(Reg8 reg)
     {
         
        bool  pv = (reg.Get() == 0x80);
        bool    h  = (((reg.Get() & 0x0f) - 1) & F_H) != 0;
        reg.Dec();

        flags.SetSign( (reg.Get() & F_S) != 0 );
        flags.SetFlagBit3( (reg.Get() & F_3) != 0 );
        flags.SetFlagBit5( (reg.Get() & F_5) != 0 );
        flags.SetZero( (reg.Get()) == 0 );
        flags.SetPV( pv );
        flags.SetHalfCarry( h );
        flags.SetN_Substraction(true);
        WaitTCycle(4);
     }

     public void DEC(Reg16 reg)
     {
            reg.Dec();
            WaitTCycle(6);
     }
     
   /**
    *  DEC (HL)
    */
    public void DEC_WherePointsHL()
    {
        int addr = Registers.regHL.Get();
        Reg8 reg = new Reg8(FromWherePointsReg16(Registers.regHL));
        DEC(reg);
        ram.WriteRAM(addr, reg.Get());
        WaitTCycle(11);
    }
    
   /**
    *  DEC (IX + N)
    */
    public void DEC_WherePointsIX_Shift(Reg16 regXY)
    {
        int shift = this.GetRelativeShift();
        Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
        DEC(reg);
        ram.WriteRAM((regXY.Get() + shift), reg.Get());
        flags.SetN_Substraction(true);
        WaitTCycle(23);
    }
    
    /**
    *  DEC IX/IY
    */
    public void DEC_IndexReg(Reg16 reg)
    {
            reg.Dec();
            WaitTCycle(10);
    }
   
     public void ADD(Reg8 regX,  Reg8 regY)
     {
            int a = regX.Get();
            int b = regY.Get();
            int wans = a + b;
            int ans  = wans & 0xff;

            flags.SetSign((ans & F_S)  != 0 );
            flags.SetFlagBit3( (ans & F_3)  != 0 );
            flags.SetFlagBit5( (ans & F_5)  != 0 );
            flags.SetZero( (ans) == 0 );
            flags.SetCarry( (wans&0x100) != 0 );
            flags.SetPV( ((a ^ ~b) & (a ^ ans) & 0x80) != 0 );
            flags.SetHalfCarry(  (((a & 0x0f) + (b & 0x0f)) & F_H) != 0 );
            flags.SetN_Substraction( false );
            regX.Set(ans);
            WaitTCycle(4);

     }
     
    public void ADD(Reg16 x, Reg16 y)
    {
            int a = x.Get();
            int b = y.Get();
            int lans = a + b;
            int ans  = lans & 0xffff;
            
            flags.SetFlagBit3( (ans & (F_3<<8)) != 0 );
            flags.SetFlagBit5( (ans & (F_5<<8)) != 0 );
            flags.SetCarry( (lans & 0x10000)!=0 );
            flags.SetHalfCarry( (((a & 0x0fff) + (b & 0x0fff)) & 0x1000)!=0 );
            flags.SetN_Substraction( false );

            x.Set(ans);
            WaitTCycle(11);
    }
    
 /**
 * ADC HL,BC /DE/HL..
 */
   public void ADC(Reg16 x, Reg16 y)
    {
            int c    = flags.GetCarryAsZeroOrOne();
            int a = x.Get();
            int b = y.Get();
            int lans = a + b + c;
            int ans  = lans & 0xffff;

            flags.SetSign( (ans & (F_S<<8)) != 0 );
            flags.SetFlagBit3( (ans & (F_3<<8)) != 0 );
            flags.SetFlagBit5( (ans & (F_5<<8)) != 0 );
            flags.SetZero( (ans) == 0 );
            flags.SetCarry( (lans & 0x10000)!=0 );
            flags.SetPV( ((a ^ ~b) & (a ^ ans) & 0x8000)!=0 );
            flags.SetHalfCarry( (((a & 0x0fff) + (b & 0x0fff) + c) & 0x1000)!=0 );
            flags.SetN_Substraction( false );

            x.Set(ans);
            WaitTCycle(15);
            
    }
    
    /**
     * ADD IX,BC /DE/HL..
     */
    public void ADD_IX_REG16(Reg16 x, Reg16 y)
    {
            this.AritmSet16SgnsAdd(x, y);
            x.Plus(y.Get());
            flags.SetN_Substraction(false);
            WaitTCycle(15);
    }
    
     
     public void ADD_N(Reg8 regX)
     {
        Reg8 regY = new Reg8(Fetch());
        ADD(regX, regY);
        WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     public void ADC_N(Reg8 regX)
     {
         regX.Plus(flags.GetCarryAsZeroOrOne());
         ADD_N(regX);
     }
     
     public void ADC(Reg8 regX,  Reg8 regY)
     {
            int a    = regX.Get();
            int b = regY.Get();
            int c    = flags.GetCarryAsZeroOrOne();
            int wans = a + b + c;
            int ans  = wans & 0xff;

            flags.SetSign( (ans & F_S)  != 0 );
            flags.SetFlagBit3( (ans & F_3)  != 0 );
            flags.SetFlagBit5( (ans & F_5)  != 0 );
            flags.SetZero( (ans)        == 0 );
            flags.SetCarry( (wans&0x100) != 0 );
            flags.SetPV( ((a ^ ~b) & (a ^ ans) & 0x80) != 0 );
            flags.SetHalfCarry(  (((a & 0x0f) + (b & 0x0f) + c) & F_H) != 0 );
            flags.SetN_Substraction( false );

            regX.Set(ans);
            WaitTCycle(4);
     }
     
     public void ADD_FromWherePointsHL(Reg8 regX)
     {
         Reg8 regY = new Reg8(FromWherePointsReg16(Registers.regHL));
         ADD(regX, regY);
         WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
 
 /*
  * ADD A,(IX + N)
  */
     public void ADD_A_IX_IY_Plus_N(Reg8 regA, Reg16 regXY)
     {
        ADD(regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
        WaitTCycle(19);
     }
 
  /*
  * ADC A,(IX + N)
  */
     public void ADC_A_IX_IY_Plus_N(Reg8 regA, Reg16 regXY)
     {
        ADC(regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
        WaitTCycle(19);
     }
 
     
     public void ADC_FromWherePointsHL(Reg8 regX)
     {
         regX.Plus(flags.GetCarryAsZeroOrOne());
         ADD_FromWherePointsHL(regX);
     }
    
     
     public void SUB(Reg8  regX, Reg8 regY)
     {
            int a    = regX.Get();
            int b = regY.Get();
            int wans = a - b;
            int ans  = wans & 0xff;

            flags.SetSign( (ans & F_S)  != 0 );
            flags.SetFlagBit3( (ans & F_3)  != 0 );
            flags.SetFlagBit5( (ans & F_5)  != 0 );
            flags.SetZero( (ans)        == 0 );
            flags.SetCarry( (wans&0x100) != 0 );
            flags.SetPV( ((a ^ b) & (a ^ ans) & 0x80) != 0 );
            flags.SetHalfCarry(  (((a & 0x0f) - (b & 0x0f)) & F_H) != 0 );
            flags.SetN_Substraction( true );
            
            regX.Set(ans);
            WaitTCycle(4);

     }
 
     
/**
 * SBC HL,BC /DE/HL..
 */
   public void SBC(Reg16 x, Reg16 y)
    {
        int a = x.Get();
        int b = y.Get();
        int c    = flags.GetCarryAsZeroOrOne();
        int lans = a - b - c;
        int ans  = lans & 0xffff;

        flags.SetSign( (ans & (F_S<<8)) != 0 );
        flags.SetFlagBit3( (ans & (F_3<<8)) != 0 );
        flags.SetFlagBit5( (ans & (F_5<<8)) != 0 );
        flags.SetZero( (ans) == 0 );
        flags.SetCarry( (lans & 0x10000)!=0 );
        flags.SetPV( ((a ^ b) & (a ^ ans) & 0x8000)!=0 );
        flags.SetHalfCarry( (((a & 0x0fff) - (b & 0x0fff) - c) & 0x1000)!=0 );
        flags.SetN_Substraction( true );

        x.Set(ans);
        WaitTCycle(15);
       
    }

   
/**
 * SBC A,B..
 */
 public void SBC(Reg8 x, Reg8 y)
    {
        this.sbc(x, y);
        flags.SetN_Substraction(true);
        WaitTCycle(4);
    }

    
     public void SUB_N(Reg8 regX)
     {
        Reg8 regY = new Reg8(Fetch());
        SUB(regX, regY);
        WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
    
     
    public void SBC_N(Reg8 x)
    {
        Reg8 y = new Reg8(this.Fetch());
        this.sbc(x, y);
        WaitTCycle(7);
    }
     
     public void SUB_FromWherePointsHL(Reg8 regX)
     {
         Reg8 regY = new Reg8(FromWherePointsReg16(Registers.regHL));
         SUB(regX, regY);
         WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     public void SBC_FromWherePointsHL(Reg8 x)
     {
        Reg8 y = new Reg8(FromWherePointsReg16(Registers.regHL));
        this.sbc(x, y);
        WaitTCycle(7);
     }
     
     private void sbc(Reg8 x, Reg8 y)
     {
            int a    = x.Get();
            int b = y.Get();
            int c    = flags.GetCarryAsZeroOrOne();
            int wans = a - b - c;
            int ans  = wans & 0xff;

            flags.SetSign( (ans & F_S)  != 0 );
            flags.SetFlagBit3( (ans & F_3)  != 0 );
            flags.SetFlagBit5( (ans & F_5)  != 0 );
            flags.SetZero( (ans)        == 0 );
            flags.SetCarry( (wans&0x100) != 0 );
            flags.SetPV( ((a ^ b) & (a ^ ans) & 0x80) != 0 );
            flags.SetHalfCarry(  (((a & 0x0f) - (b & 0x0f) - c) & F_H) != 0 );
            flags.SetN_Substraction( true );

            x.Set(ans);
         
     }
    
     private void sbc(Reg16 x, Reg16 y)
     {
        int i = x.Get();
        int k = y.Get() + (flags.GetCarryAsZeroOrOne());
        x.Minus(y.Get());
        x.Minus(flags.GetCarryAsZeroOrOne());
      
        if ((i - k) < 0) flags.SetCarry(true);
        else flags.SetCarry(false);
        if ((i - k) > 32767){ flags.SetSign(true);}
        else flags.SetSign(false);
        if ((i - k) == 0) { flags.SetZero(true); }
        else flags.SetZero(false);
        flags.SetPV(false); //pri aritmetickych operacich je PV nejspise vzdy nula.
        
        flags.SetN_Substraction(true);
     }
     
  /*
  * SUB A,(IX + N)
  */
     public void SUB_A_IX_IY_Plus_N(Reg8 regA, Reg16 regXY)
     {
        SUB(regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
        WaitTCycle(19);
     }
 
  /*
  * SBC A,(IX + N)
  */
     public void SBC_A_IX_IY_Plus_N(Reg8 x, Reg16 regXY)
     {
        Reg8 y = new Reg8(GetReg8FromWherePointsIX_IY_Shift(regXY).Get());
        this.sbc(x, y);
        WaitTCycle(19);
     }
 
     private void AritmSet16SgnsAdd(Reg16 x, Reg16 y)
     {
            if ((x.Get() + y.Get()) == 65536) { flags.SetZero(true); }
            else flags.SetZero(false);
            if ((x.Get() + y.Get()) > 65535) { flags.SetCarry(true); }
            else flags.SetCarry(false);
            if (x.Get() + y.Get() > 32767){ flags.SetSign(true);}
            else flags.SetSign(false);
     }

     private void AritmSet16SgnsSub(Reg16 x, Reg16 y)
     {
        if ((x.Get() - y.Get()) < 0) { flags.SetCarry(true); }
        else flags.SetCarry(false);
        if (x.Get() - y.Get() > 32767){ flags.SetSign(true);}
        else flags.SetSign(false);
        if ((x.Get() - y.Get()) == 0) { flags.SetZero(true); }
        else flags.SetZero(false);
            
     }
     
     public void AND(Reg8 x, Reg8 y)
     {
            int b = y.Get();
            int ans = Registers.regA.Get() & b;

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetHalfCarry( true );
            flags.SetPV( parity[ ans ] );
            flags.SetZero( ans == 0 );
            flags.SetN_Substraction( false );
            flags.SetCarry( false );

            Registers.regA.Set(ans);
            WaitTCycle(4);
     }
     
     public void AND_N(Reg8 regX)
     {
        Reg8 regY = new Reg8(Fetch());
        AND(regX, regY);
        WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
    
     public void AND_FromWherePointsHL(Reg8 regX)
     {
         Reg8 regY = new Reg8(FromWherePointsReg16(Registers.regHL));
         AND(regX, regY);
         WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     /*
     /* AND (IX + N)
     */
     public void AND_RegA_FromWherePointsIX_IY_Shift(Reg16 regXY)
     {
         AND(Registers.regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
         WaitTCycle(19);
     }
     
     /*
     /* OR (IX + N)
     */
     public void OR_RegA_FromWherePointsIX_IY_Shift(Reg16 regXY)
     {
         OR(Registers.regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
         WaitTCycle(19);
     }                      
     
     /*
     /* XOR (IX + N)
     */
     public void XOR_RegA_FromWherePointsIX_IY_Shift(Reg16 regXY)
     {
         XOR(Registers.regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
         WaitTCycle(19);
     }
     
     /*
     /* CP (IX + N)
     */
     public void CP_RegA_FromWherePointsIX_IY_Shift(Reg16 regXY)
     {
        CP(Registers.regA, GetReg8FromWherePointsIX_IY_Shift(regXY));
        WaitTCycle(19);
     }
     
     public void CPI()
     {
        if (Registers.regA.Get() == ram.ReadRAM(Registers.regHL.Get()))
        {
            flags.SetZero(true);
            Registers.regHL.Inc(); Registers.regBC.Dec();
        }
        else
        {
            flags.SetZero(false);
            Registers.regHL.Inc(); Registers.regBC.Dec();
        }

        if (Registers.regBC.Get() == 0) flags.SetPV(false);
        else flags.SetPV(true);
        flags.SetN_Substraction(true);
        WaitTCycle(16);
     }
     
     public void CPD()
     {
        if (Registers.regA.Get() == ram.ReadRAM(Registers.regHL.Get()))
        {
            flags.SetZero(true);
            Registers.regHL.Dec(); Registers.regBC.Dec();
        }
        else
        {
            flags.SetZero(false);
            Registers.regHL.Dec(); Registers.regBC.Dec();
        }

        if (Registers.regBC.Get() == 0) flags.SetPV(false);
        else flags.SetPV(true);
        flags.SetN_Substraction(true);
        WaitTCycle(16);
     }
     
     public void CPIR()
     {
        if (Registers.regBC.Get() != 0)
        {
            if (Registers.regA.Get() != ram.ReadRAM(Registers.regHL.Get()))
            {
                if (ram.ReadRAM(Registers.regHL.Get()) > Registers.regA.Get()) { flags.SetSign(true); }
                else { flags.SetSign(false); }

                flags.SetZero(false);
                Registers.regHL.Inc(); Registers.regBC.Dec();
                WaitTCycle(21);
                Registers.SetPCRelativJump(-2);
            }
            else 
            {
                if (ram.ReadRAM(Registers.regHL.Get()) > Registers.regA.Get()) { flags.SetSign(true); }
                else {flags.SetSign(false);}

                Registers.regHL.Inc(); Registers.regBC.Dec();
                flags.SetZero(true); flags.SetPV(true);  //HL ukazuje az za nalezenou hodnotu
            } 
        }
        else { flags.SetPV(false); WaitTCycle(16); }
        flags.SetN_Substraction(false);
    }
                              
    public void CPDR()
     {
        if (Registers.regBC.Get() != 0)
        {
            if (Registers.regA.Get() != ram.ReadRAM(Registers.regHL.Get()))
            {
                if (ram.ReadRAM(Registers.regHL.Get()) > Registers.regA.Get()) { flags.SetSign(true); }
                else { flags.SetSign(false); }

                flags.SetZero(false);
                Registers.regHL.Dec(); Registers.regBC.Dec();
                WaitTCycle(21);
                Registers.SetPCRelativJump(-2);
            }
            else 
            {
                if (ram.ReadRAM(Registers.regHL.Get()) > Registers.regA.Get()) { flags.SetSign(true); }
                else {flags.SetSign(false);}

                Registers.regHL.Dec(); Registers.regBC.Dec();
                flags.SetZero(true); flags.SetPV(true);  //HL ukazuje az za nalezenou hodnotu
            } 
        }
        else { flags.SetPV(false); WaitTCycle(16); }
        
        flags.SetN_Substraction(false);
    }
     

/**
 * Returns a Reg8 object which holds data pointed by the IX or IY regs.
 */     
     private Reg8 GetReg8FromWherePointsIX_IY_Shift(Reg16 regXY)
     {
         Reg8 reg = new Reg8(0);
         reg.Set(ram.ReadRAM(regXY.Get() + GetRelativeShift()));
         return reg;
     }

/**
 * Returns the actual adress held in the IX or IY regs + shift.
 */     
     private int GetIXaddressWithShift(Reg16 regXY)
     {
          return (regXY.Get() + GetRelativeShift());
     }
     
 /**
  * Gets the relative shift value.
  * Used with index registers or relative jumps.
  */
     private sbyte GetRelativeShift()
     {
         sbyte x = (sbyte)Fetch();
         return x;
     }
     
     /**
      * Returns the absolute address to where shall
      * the "jr" or "djnz" instructions jump.
      */
     private int GetAbsolutePCvalue()
     {
         Reg16 reg = new Reg16(Registers.regPC.Get());
         reg.Plus(GetRelativeShift() + 1); //must be added "1", otherwise the absolute address is not correct
         return reg.Get();
     }
     
     public void OR(Reg8 x, Reg8 y)
     {   
        int b = y.Get();
        int ans = Registers.regA.Get() | b;

        flags.SetSign( (ans & F_S) != 0 );
        flags.SetFlagBit3( (ans & F_3) != 0 );
        flags.SetFlagBit5( (ans & F_5) != 0 );
        flags.SetHalfCarry( false );
        flags.SetPV( parity[ ans ] );
        flags.SetZero( ans == 0 );
        flags.SetN_Substraction( false );
        flags.SetCarry( false );

        Registers.regA.Set(ans);
        WaitTCycle(4);
     }

     public void OR_N(Reg8 regX)
     {
        Reg8 regY = new Reg8(Fetch());
        OR(regX, regY);
        WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
    
     public void OR_FromWherePointsHL(Reg8 regX)
     {
         Reg8 regY = new Reg8(FromWherePointsReg16(Registers.regHL));
         OR(regX, regY);
         WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     public void XOR(Reg8 x, Reg8 y)
     {
            int b = y.Get();
            int ans = (Registers.regA.Get() ^ b) & 0xff;

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetHalfCarry( false );
            flags.SetPV( parity[ ans ] );
            flags.SetZero( ans == 0 );
            flags.SetN_Substraction( false );
            flags.SetCarry( false );    
            Registers.regA.Set(ans);

            WaitTCycle(4);
     }
     
     public void XOR_N(Reg8 regX)
     {
        Reg8 regY = new Reg8(Fetch());
        XOR(regX, regY);
        WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     public void XOR_FromWherePointsHL(Reg8 regX)
     {
         Reg8 regY = new Reg8(FromWherePointsReg16(Registers.regHL));
         XOR(regX, regY);
         WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
    
     public void CP(Reg8  regX, Reg8 regY) //CP is actually kind of SUB
     {
        int a    = Registers.regA.Get();
        int b = regY.Get();
        int wans = a - b;
        int ans  = wans & 0xff;

        flags.SetSign( (ans & F_S) != 0 );
        flags.SetFlagBit3( (b & F_3)   != 0 );
        flags.SetFlagBit5( (b & F_5)   != 0 );
        flags.SetN_Substraction( true );
        flags.SetZero( ans == 0 );
        flags.SetCarry( (wans & 0x100)!=0 );
        flags.SetHalfCarry((((a & 0x0f) - (b & 0x0f)) & F_H) != 0 );
        flags.SetPV( ((a ^ b) & (a ^ ans) & 0x80) != 0 );
 
        WaitTCycle(4);
     }

     public void CP_N(Reg8 regX)
     {
        Reg8 regY = new Reg8(Fetch());
        CP(regX, regY);
        WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     public void CP_FromWherePointsHL(Reg8 regX)
     {
         Reg8 regY = new Reg8(FromWherePointsReg16(Registers.regHL));
         CP(regX, regY);
         WaitTCycle(3); //additional 3 T cycles because memory is slower than registers.
     }
     
     public void SCF()
     {
        int        ans = Registers.regA.Get();

        flags.SetFlagBit3( (ans & F_3) != 0 );
        flags.SetFlagBit5( (ans & F_5) != 0 );
        flags.SetN_Substraction( false );
        flags.SetHalfCarry( false );
        flags.SetCarry( true );

        WaitTCycle(4);
     }
     
     public void CCF()
     {
        int        ans = Registers.regA.Get();

        flags.SetFlagBit3( (ans & F_3) != 0 );
        flags.SetFlagBit5( (ans & F_5) != 0 );
        flags.SetN_Substraction( false );
        flags.SetCarry( flags.GetCarry() ? false : true );
 
        WaitTCycle(4);
     }
     
    public void EI()
    {
        Registers.regIFF = true;
        WaitTCycle(4);
    }
    
    public void DI()
    {
        Registers.regIFF = false;
        WaitTCycle(4);
    }
    
    public void HALT()
    {
        if (halt == false)
        {
            Registers.regPC.Dec();
        }
        else 
        {
            halt = false; 
        }
        
        WaitTCycle(4);
    }
    
    private void sla(Reg8 reg)
    {

        int ans = reg.Get();
        bool c = (ans & 0x80) != 0;
        ans = (ans << 1) & 0xff;

        flags.SetSign( (ans & F_S) != 0 );
        flags.SetFlagBit3( (ans & F_3) != 0 );
        flags.SetFlagBit5( (ans & F_5) != 0 );
        flags.SetZero( (ans) == 0 );
        flags.SetPV( parity[ ans ] );
        flags.SetHalfCarry( false );
        flags.SetN_Substraction( false );
        flags.SetCarry( c );
        
        reg.Set(ans);

        
    }
    
    public void SLA(Reg8 reg)
     {
            sla(reg);
            WaitTCycle(8);
     }
     
     public void SLA(Reg8 reg, int TCycle)
     {
            SLA(reg);
            WaitTCycle(TCycle);
     }
     
      public void SRL(Reg8 reg)
      {
           int ans = reg.Get();
           bool c = (ans & 0x01) != 0;
           ans = ans >> 1;

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetZero( (ans) == 0 );
            flags.SetPV( parity[ ans ] );
            flags.SetHalfCarry( false );
            flags.SetN_Substraction( false );
            flags.SetCarry(c);
            reg.Set(ans);
            WaitTCycle(8);
           
      }
      
      public void SRL(Reg8 reg, int TCycle)
      {
            SRL(reg);
            WaitTCycle(TCycle);
      }

      public void SLIA(Reg8 reg)
      {
            int ans = reg.Get();
            bool c = (ans & 0x80) != 0;
            ans = ((ans << 1) | 0x01) & 0xff;

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetZero( (ans) == 0 );
            flags.SetPV( parity[ ans ] );
            flags.SetHalfCarry( false );
            flags.SetN_Substraction( false );
            flags.SetCarry( c );
            reg.Set(ans);
            WaitTCycle(8);
           
      }

      public void SLIA(Reg8 reg, int TCycle)
      {
            SLIA(reg);
            WaitTCycle(TCycle);
      }

       public void SRA(Reg8 reg)
       {
           int ans = reg.Get();
            bool c = (ans & 0x01) != 0;
            ans = (ans >> 1) | (ans & 0x80);

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetZero( (ans) == 0 );
            flags.SetPV( parity[ ans ] );
            flags.SetHalfCarry( false );
            flags.SetN_Substraction( false );
            flags.SetCarry( c );
            reg.Set(ans);

            WaitTCycle(8);
          
       }

       public void SRA(Reg8 reg, int TCycle)
       {
            SRA(reg);
            WaitTCycle(TCycle);
       }

       private void rr(Reg8 reg)
       {
            int ans = reg.Get();
            bool c = (ans & 0x01) != 0;

            if ( flags.GetCarry() == true ) 
            {
                    ans = (ans >> 1) | 0x80;
            } 
            else 
            {
                    ans >>= 1;
            }

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetZero( (ans) == 0 );
            flags.SetPV( parity[ ans ] );
            flags.SetHalfCarry( false );
            flags.SetN_Substraction( false );
            flags.SetCarry( c );    

            reg.Set(ans);

       }
       
       public void RR(Reg8 reg)
       {
           rr(reg);
           WaitTCycle(8);
       }
    
       public void RLCA()
       {
            
            int     ans = Registers.regA.Get();
            bool c   = (ans & 0x80) != 0;

            if ( c ) 
            {
                    ans = (ans << 1)|0x01;
            } 
            else 
            {
                    ans <<= 1;
            }

            ans &= 0xff;

            flags.SetFlagBit3( (ans & F_3)  != 0 );
            flags.SetFlagBit5( (ans & F_5)  != 0 );
            flags.SetN_Substraction( false );
            flags.SetHalfCarry( false );
            flags.SetCarry( c );
            
            Registers.regA.Set(ans);

            WaitTCycle(4);
        }
       
       public void RRCA()
       {
           
            int ans = Registers.regA.Get();
            bool c = (ans & 0x01) != 0;

            if ( c ) 
            {
                    ans = (ans >> 1)|0x80;
            } 
            else 
            {
                    ans >>= 1;
            }

            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetHalfCarry( false );
            flags.SetN_Substraction( false );
            flags.SetCarry( c );    

            Registers.regA.Set(ans);
           
           WaitTCycle(4);
       }
       
       public void RLA()
       { 
           
            int ans = Registers.regA.Get();
            bool c = (ans & 0x80) != 0;

            if ( flags.GetCarry() == true ) 
            {
                    ans = (ans << 1) | 0x01;
            } 
            else 
            {
                    ans <<= 1;
            }
            ans &= 0xff;

            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetHalfCarry( false );
            flags.SetN_Substraction( false );
            flags.SetCarry( c );   

            Registers.regA.Set(ans);

           WaitTCycle(4);
       }
       
       public void RRA()
       {
            int     ans = Registers.regA.Get();
            bool c   = (ans & 0x01) != 0;

            if ( flags.GetCarry() == true ) 
            {
                    ans = (ans >> 1) | 0x80;
            } 
            else 
            {
                    ans >>= 1;
            }

            flags.SetFlagBit3( (ans & F_3)  != 0 );
            flags.SetFlagBit5( (ans & F_5)  != 0 );
            flags.SetN_Substraction( false );
            flags.SetHalfCarry( false );
            flags.SetCarry( c );
            Registers.regA.Set(ans);

          WaitTCycle(4);
       }   
       
       private void rlc(Reg8 reg)
       {
           int ans = reg.Get();
           bool c = (ans & 0x80) != 0;

		if ( c ) 
                {
			ans = (ans << 1)|0x01;
		} 
                else 
                {
			ans <<= 1;
		}
		ans &= 0xff;

		flags.SetSign( (ans & F_S) != 0 );
		flags.SetFlagBit3( (ans & F_3) != 0 );
		flags.SetFlagBit5( (ans & F_5) != 0 );
		flags.SetZero( (ans) == 0 );
		flags.SetPV( parity[ ans ] );
		flags.SetHalfCarry( false );
		flags.SetN_Substraction( false );
		flags.SetCarry( c );    

		reg.Set(ans);

       }
       
       public void RLC(Reg8 reg)
       {
            rlc(reg);  
            WaitTCycle(8);
        }
       
       private void rrc(Reg8 reg)
       {
            int ans = reg.Get();
            bool c = (ans & 0x01) != 0;

		if ( c ) 
                {
			ans = (ans >> 1)|0x80;
		} 
                else 
                {
			ans >>= 1;
		}

		flags.SetSign( (ans & F_S) != 0 );
		flags.SetFlagBit3( (ans & F_3) != 0 );
		flags.SetFlagBit5( (ans & F_5) != 0 );
		flags.SetZero( (ans) == 0 );
		flags.SetPV( parity[ ans ] );
		flags.SetHalfCarry( false );
		flags.SetN_Substraction( false );
		flags.SetCarry( c );    
                
                reg.Set(ans);

       }
       
       public void RRC(Reg8 reg)
       {
            rrc(reg);
            WaitTCycle(8);
        }

       
       public void RLD()
       {
            int ans = Registers.regA.Get();
            int t   = ram.ReadRAM(Registers.regHL.Get());
            int q   = t;

            t   = (t << 4) | (ans & 0x0f);
            ans = (ans & 0xf0) | (q >> 4);
            ram.WriteRAM(Registers.regHL.Get(), (t & 0xff));

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetZero( ans == 0 );
            flags.SetPV( Registers.regIFF2 );
            flags.SetHalfCarry( false );    
            flags.SetN_Substraction( false );  

            Registers.regA.Set(ans);

            WaitTCycle(18);
       
       }

       public void RRD()
       {
            int ans = Registers.regA.Get();
            int t   = ram.ReadRAM(Registers.regHL.Get());
            int q   = t;

            t   = (t >> 4) | (ans << 4);
            ans = (ans & 0xf0) | (q & 0x0f);
            ram.WriteRAM(Registers.regHL.Get(), (t & 0xff));

            flags.SetSign( (ans & F_S) != 0 );
            flags.SetFlagBit3( (ans & F_3) != 0 );
            flags.SetFlagBit5( (ans & F_5) != 0 );
            flags.SetZero( ans == 0 );
            flags.SetPV( Registers.regIFF2 );
            flags.SetHalfCarry( false );    
            flags.SetN_Substraction( false );        

            Registers.regA.Set( ans );
            WaitTCycle(18);

       }

       
       public void SLA_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            SLA(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       
       public void SRA_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            SRA(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       
       public void SRL_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            SRL(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       public void SLIA_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            SLIA(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       
       public void RRC_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            RRC(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       
       public void RLC_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            RLC(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       private void rl(Reg8 reg)
       {
           int ans = reg.Get();
           bool c = (ans & 0x80) != 0;

		if ( flags.GetCarry() == true ) 
                {
			ans = (ans << 1) | 0x01;
		} 
                else 
                {
			ans <<= 1;
		}
		ans &= 0xff;

		flags.SetSign( (ans & F_S) != 0 );
		flags.SetFlagBit3( (ans & F_3) != 0 );
		flags.SetFlagBit5( (ans & F_5) != 0 );
		flags.SetZero( (ans) == 0 );
		flags.SetPV( parity[ ans ] );
		flags.SetHalfCarry( false );
		flags.SetN_Substraction( false );
		flags.SetCarry( c );   
                
                reg.Set(ans);

       }
       
       public void RL(Reg8 reg) 
       {
           rl(reg);
           WaitTCycle(8);
       }
       
       public void RL_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            RL(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(7); //additional 7 cycles, the sum is 15 cycles
       }
       
       public void RR_OnWherePointsHL()
       {
            Reg8 reg = new Reg8(0);
            reg.Set(ram.ReadRAM(Registers.regHL.Get()));
            rr(reg);
            ram.WriteRAM(Registers.regHL.Get(), reg.Get());
            WaitTCycle(15); //additional 7 cycles, the sum is 15 cycles
       }
       
       public void RR_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            rr(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }

       public void RL_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            rl(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }

       public void RLC_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            this.rlc(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }
       
       public void RRC_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            this.rrc(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }

       public void SLA_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            this.sla(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }


       public void SRA_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            this.SRA(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }

       public void SLIA_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            this.SLIA(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }

       public void SRL_OnWherePointsIndexReg(Reg16 regXY)
       {
            byte shift = (byte)FetchPreviousByte();
            Reg8 reg = new Reg8(ram.ReadRAM(regXY.Get() + shift));
            this.SRL(reg);
            ram.WriteRAM((regXY.Get() + shift), reg.Get());
            WaitTCycle(23);
       }
       
       public void BIT(Reg8 reg, int pos)
       {
            
            int bAnd = 1;
            bAnd = (bAnd << pos); //posun se na pozadovany bit
           
            int r = reg.Get();
            bool    bitSet = ((r & bAnd) != 0);

            flags.SetN_Substraction( false );
            flags.SetHalfCarry( true );
            flags.SetFlagBit3( (r & F_3) != 0 );
            flags.SetFlagBit5( (r & F_5) != 0 );
            flags.SetSign( (bAnd == F_S) ? bitSet : false );
            flags.SetZero(  !bitSet );
            flags.SetPV( !bitSet );
	
            WaitTCycle(8);
       }

        public void BIT(Reg8 reg, int pos, int TCycle)
        {
            BIT(reg, pos);
            WaitTCycle(TCycle);
        } 
        
       public void BIT_OnWherePointsHL(int pos)
       {
           Reg8 reg = new Reg8(0);
           reg.Set(ram.ReadRAM(Registers.regHL.Get()));
           BIT(reg, pos, 12);  
       }
       
       /**
        * BIT 0,(IX + N)
        */
       public void BIT_OnWherePointsIndexReg(Reg16 reg16, int pos)
       {
            Reg8 reg = new Reg8(0);
            byte shift = (byte)FetchPreviousByte();
            int addr = (reg16.Get() + shift);
            reg.Set(ram.ReadRAM(addr));
            BIT(reg, pos, 20);
       }
       

        public void SET(Reg8 reg, int pos)
        {
            int bAnd = 1;
            bAnd = (bAnd << pos); //posun se na pozadovany bit
            reg.Set(bAnd | reg.Get());
            WaitTCycle(8);
        }

        public void SET(Reg8 reg, int pos, int TCycle)
        {
            SET(reg, pos);
            WaitTCycle(TCycle);
        }

        
       /**
       * SET 6,(IX + N) 
       */
       public void SET_OnWherePointsIndexReg(Reg16 reg16, int pos)
        {
            Reg8 reg = new Reg8(0);
            byte shift = (byte)FetchPreviousByte();
            int addr = (reg16.Get() + shift);
            reg.Set(ram.ReadRAM(addr));
            SET(reg, pos, 23);
            ram.WriteRAM(addr, reg.Get());
        }

       public void SET_OnWherePointsHL(int pos)
       {
           Reg8 reg = new Reg8(0);
           reg.Set(ram.ReadRAM(Registers.regHL.Get()));
           SET(reg, pos, 12);
           ram.WriteRAM(Registers.regHL.Get(), reg.Get());
       }
       
        
        public void RES(Reg8 reg, int pos)
        {
            int bAnd = 1;
            bAnd = (bAnd << pos); //posun se na pozadovany bit
            bAnd = (~bAnd);
            reg.Set(bAnd & reg.Get());
            WaitTCycle(8);
        }

        public void RES(Reg8 reg, int pos, int TCycle)
        {
            RES(reg, pos);
            WaitTCycle(TCycle);
        }
        
        /**
         * RES 6,(IX + N) 
         */
        public void RES_OnWherePointsIndexReg(Reg16 reg16, int pos)
        {
            Reg8 reg = new Reg8(0);
            byte shift = (byte)FetchPreviousByte();
            int addr = (reg16.Get() + shift);
            reg.Set(ram.ReadRAM(addr));
            RES(reg, pos, 23);
            ram.WriteRAM(addr, reg.Get());
        }

       public void RES_OnWherePointsHL(int pos)
       {
           Reg8 reg = new Reg8(0);
           reg.Set(ram.ReadRAM(Registers.regHL.Get()));
           RES(reg, pos, 12);
           ram.WriteRAM(Registers.regHL.Get(), reg.Get());
       }
       
       
       public void NEG()
       {
           Reg8 reg = new Reg8(0);
           SUB(reg, Registers.regA);
           Registers.regA.Set(reg.Get());
           WaitTCycle(8);
        }
       
        /**
         * OUT (N),A
         */
        public void OUT(Reg8 x)
        {
            Out(Fetch(), x.Get(),11);
        }
        
        /**
         * OUT (c),D
         */
        public void OUT(Reg16 r16, Reg8 r8)
        {
            Out(r16.Get(), r8.Get(),12);
        }
        
        /**
         * IN A,(N)
         */
        public void IN(Reg8 x)
        {
            //int high = x.Get() * 256;
            //int low = Fetch();
            
            int low = Registers.regA.Get() * 256;
            int high = Fetch();
            
            int port = high + low;
            Registers.regA.Set(In(port,11));
            
            int ans = Registers.regA.Get();
            flags.SetZero( ans == 0 );
            flags.SetSign( (ans & F_S)!=0 );
            flags.SetFlagBit3( (ans & F_3)!=0 );
            flags.SetFlagBit5( (ans & F_5)!=0 );
            flags.SetPV( parity[ ans ] );
            flags.SetN_Substraction( false );
            flags.SetHalfCarry( false );
            
            WaitTCycle(4);
        }
        
        /**
         * IN D,(c)
         */
        public void IN(Reg8 r8, Reg16 r16)
        {
            int ans = In(r16.Get(),12);
            flags.SetZero( ans == 0 );
            flags.SetSign( (ans & F_S)!=0 );
            flags.SetFlagBit3( (ans & F_3)!=0 );
            flags.SetFlagBit5( (ans & F_5)!=0 );
            flags.SetPV( parity[ ans ] );
            flags.SetN_Substraction( false );
            flags.SetHalfCarry( false );
            
            r8.Set(ans);
            WaitTCycle(4);
        }
        
        
        private void Out(int port, int value, int TCycle)
        {
            ports.OutPort(port, value);
            WaitTCycle(TCycle);
        }

        private int In(int port, int TCycle)
        {   
            WaitTCycle(TCycle);
            return ports.InPort(port);
        }

        /**
         * PUSH BC  /HL/DE...
         */
        public void PUSH(Reg16 reg16)
        {
            push(reg16);
            WaitTCycle(11);
        }
        
        /**
         * PUSH IX/IY
         */
        public void PUSH_IndexReg(Reg16 reg16)
        {
            push(reg16);
            WaitTCycle(15);
        }
        
        public void PUSH(Reg16 reg16, int TCycle)
        {
            push(reg16);
            WaitTCycle(TCycle);
        }
        
        private void push(Reg16 reg)
        {
            Registers.regSP.Minus(2);
            ram.WriteRAM(Registers.regSP.Get(), (reg.Get() % 256));
            Registers.regSP.Inc();
            ram.WriteRAM((Registers.regSP.Get()), (reg.Get() / 256));
            Registers.regSP.Dec();
        }
        
        /**
         * POP BC   /HL/DE..
         */
        public void POP(Reg16 reg16)
        {
            int value = (ram.ReadRAM(Registers.regSP.Get()));
            Registers.regSP.Inc();
            value += (256 * (ram.ReadRAM(Registers.regSP.Get())));
            Registers.regSP.Inc();
            reg16.Set(value);
            WaitTCycle(10);
        }
        
        public void POP(Reg16 reg16, int TCycle)
        {
            int value = (ram.ReadRAM(Registers.regSP.Get()));
            Registers.regSP.Inc();
            value += (256 * (ram.ReadRAM(Registers.regSP.Get())));
            Registers.regSP.Inc();
            reg16.Set(value);
            WaitTCycle(TCycle);
        }
        
        
        /**
         * POP IX/IY
         */
        public void POP_IndexReg(Reg16 reg16)
        {
            int value = (ram.ReadRAM(Registers.regSP.Get()));
            Registers.regSP.Inc();
            value += (256 * (ram.ReadRAM(Registers.regSP.Get())));
            Registers.regSP.Inc();
            reg16.Set(value);
            WaitTCycle(15);
        }
        
    /**
     * CALL NN
     * This function is kind of PUSH instruction but 
     * sets the PC register as well.
     */    
        public void CALL()
        {
            int call = FetchWord();
            PUSH(Registers.regPC, 17); //CALL is kind of PUSH
            Registers.regPC.Set(call);
        }
   
    /**
     * Called to ensure the IM0 interrupt function.
     */
        public void CALL_IM0()
        {}
       
        
    /**
     * Called every 1/50 sec to ensure the IM1 interrupt function.
     */
        public void CALL_IM1()
        {
            this.push(Registers.regPC);
            Registers.regPC.Set(56);
        }
   
    /**
     * Called every 1/50 sec to ensure the IM2 interrupt function.
     */
        public void CALL_IM2()
        {
            PUSH(Registers.regPC, 17); //CALL is kind of PUSH
            int vector = ((Registers.regI.Get() * 256) + 255);
            int adr = (ram.ReadRAM(vector) + (256 * ram.ReadRAM(vector + 1)));
            Registers.regPC.Set(adr);
        }
   
        
    /**
     * CALL NZ, NN
     */ 
        public void CALL_NZ()
        {
            call_on_false(flags.GetZero());
        }
        
    /**
     * CALL Z, NN
     */ 
        public void CALL_Z()
        {
            call_on_true(flags.GetZero());
        }
        
    /**
     * CALL C, NN
     */ 
        public void CALL_C()
        {
            call_on_true(flags.GetCarry());
        }
        
    /**
     * CALL NC, NN
     */ 
        public void CALL_NC()
        {
            call_on_false(flags.GetCarry());
        }
        
        
    /**
     * CALL P, NN
     */ 
        public void CALL_P()
        {
            call_on_false(flags.GetSign());
        }
        
    /**
     * CALL M, NN
     */ 
        public void CALL_M()
        {
            call_on_true(flags.GetSign());
        }
        
    /**
     * CALL PO, NN
     */ 
        public void CALL_PO()
        {
            call_on_false(flags.GetPV());
        }
        
    /**
     * CALL PE, NN
     */ 
        public void CALL_PE()
        {
            call_on_true(flags.GetPV());
        }
        
        private void call_on_true(bool b)
        {
            if (b == true)
             {
                CALL();
             }
         else
             {
                FetchWord();
                WaitTCycle(10);
             }
        }
        
        private void call_on_false(bool b)
        {
            if (b == false)
             {
                CALL();
             }
         else
             {
                FetchWord();
                WaitTCycle(10);
             }
        }
   
        private void ret_on_true(bool b)
        {
            if (b == true)
             {
                RET();
             }
         else
             {
                WaitTCycle(10);
             }
        }
        
        private void ret_on_false(bool b)
        {
            if (b == false)
             {
                RET();
             }
         else
             {
                WaitTCycle(10);
             }
        }
   
        public void RET()
        {
            POP(Registers.regPC);
        }
        
        public void RET_C()
        {
            ret_on_true(flags.GetCarry());
        }

        public void RET_NC()
        {
            ret_on_false(flags.GetCarry());
        }
        
        public void RET_Z()
        {
            ret_on_true(flags.GetZero());
        }

        public void RET_NZ()
        {
            ret_on_false(flags.GetZero());
        }
        
        public void RET_PO()
        {
            ret_on_false(flags.GetPV());
        }
        
        public void RET_PE()
        {
            ret_on_true(flags.GetPV());
        }
        
        public void RET_P()
        {
            ret_on_false(flags.GetSign());
        }

        public void RET_M()
        {
            ret_on_true(flags.GetSign());
        }

        public void RETI()
        {
            POP(Registers.regPC, 14);
        }

        public void RETN()
        {
            POP(Registers.regPC, 14);
        }

        public void RST(int addr)
        {
            PUSH(Registers.regPC, 11); //RST je vlastne druh PUSH
            Registers.regPC.Set(addr);
        }
       
       private void jp_on_true(bool b)
       {
            if (b == true)
             {
                JP_N();
             }
            else
             {
                FetchWord();
                WaitTCycle(6);
             }

       }
       
       private void jp_on_false(bool b)
       {
            if (b == false)
             {
                JP_N();
             }
            else
             {
                FetchWord();
                WaitTCycle(6);
             }
       }
       
       
       public void JP_N()
       {
            Registers.regPC.Set(FetchWord());
            WaitTCycle(10);
       }
       
       public void JP_HL()
       {
            Registers.regPC.Set(Registers.regHL.Get());
            //System.out.println(Registers.regPC.Get());
            WaitTCycle(4);
       }
       /**
        * JP (IX)   /(IY)
        */
       public void JP_Index(Reg16 reg)
       {
            Registers.regPC.Set(reg.Get());
            WaitTCycle(8);
       }
       
       public void JP_NZ_NN()
       {
            jp_on_false(flags.GetZero());
       }
       
       public void JP_Z_NN()
       {
            jp_on_true(flags.GetZero());
       }
      
       public void JP_NC_NN()
       {
            jp_on_false(flags.GetCarry());
       }
       
       public void JP_C_NN()
       {
            jp_on_true(flags.GetCarry());
       }
       
       public void JP_PO_NN()
       {
            jp_on_false(flags.GetPV());
       }
      
       public void JP_PE_NN()
       {
            jp_on_true(flags.GetPV());
       }
       
       public void JP_P_NN()
       {
            jp_on_false(flags.GetSign());
       }
      
       public void JP_M_NN()
       {
            jp_on_true(flags.GetSign());
       }
       
   /**
    * DJNZ
    */
       public void DJNZ()
       {
           Registers.regB.Dec();
           
           if (Registers.regB.Get() != 0)
           {
                Registers.regPC.Set(GetAbsolutePCvalue());
                WaitTCycle(13);
           }
           
           else
             {
                Fetch();
                WaitTCycle(8);
             }
       }
           
           
       
       private void jr()
       {
            Registers.regPC.Set(GetAbsolutePCvalue());
       }
       
       private void jr_on_true(bool b)
       {
       if (b == true)
            {
                jr();
                WaitTCycle(12);
             }
            else
            {
                Fetch();
                WaitTCycle(7);
            }
       
       }
       
       private void jr_on_false(bool b)
       {
       if (b == false)
            {
                jr();
                WaitTCycle(12);
             }
            else
            {
                Fetch();
                WaitTCycle(7);
            }
       }
       
       public void JR()
       {
            jr();
            WaitTCycle(12); 
       }
       
       public void JR_NZ()
       {
            jr_on_false(flags.GetZero());
       }

       public void JR_Z()
       {
            jr_on_true(flags.GetZero());
       }
       
       public void JR_C()
       {
       
            jr_on_true(flags.GetCarry());
       }
       
       public void JR_NC()
       {
           jr_on_false(flags.GetCarry());
       }

        
/**
 * Exchange the 16bit registry
 */     
        public void EXX() 
        {
            int intrm;
            intrm = Registers.regBC.Get();
            Registers.regBC.Set(Registers.regBC_.Get());
            Registers.regBC_.Set(intrm);

            intrm = Registers.regDE.Get();
            Registers.regDE.Set(Registers.regDE_.Get());
            Registers.regDE_.Set(intrm);

            intrm = Registers.regHL.Get();
            Registers.regHL.Set(Registers.regHL_.Get());
            Registers.regHL_.Set(intrm);
            
            WaitTCycle(4);

        }
/**
 * Exchange 16bit registers
 */ 
        
        public void EX_REG16_REG16(Reg16 regX, Reg16 regY )
        {
            Reg16 reg = new Reg16(0);
            reg.Set(regX.Get()); //prohod registr "A"
            regX.Set(regY.Get());
            regY.Set(reg.Get());
            
            WaitTCycle(4);
        }

/**
 * Ex (SP),HL.
 */         
        public void EX_ToWherePointsSP_HL()
        {
            Reg16 rHL = new Reg16(Registers.regHL.Get());
            Registers.regL.Set(ram.ReadRAM(Registers.regSP.Get()));
            Registers.regH.Set(ram.ReadRAM(Registers.regSP.Get() + 1));
            ram.WriteRAM(Registers.regSP.Get(), (rHL.Get() % 256));
            ram.WriteRAM((Registers.regSP.Get() + 1), (rHL.Get() / 256));
            WaitTCycle(19);
        }

/**
 * Ex (SP),IX.
 */         
        public void EX_ToWherePointsSP_IX()
        {
            Reg16 rHL = new Reg16(Registers.regIX.Get());
            Registers.regLX.Set(ram.ReadRAM(Registers.regSP.Get()));
            Registers.regHX.Set(ram.ReadRAM(Registers.regSP.Get() + 1));
            ram.WriteRAM(Registers.regSP.Get(), (rHL.Get() % 256));
            ram.WriteRAM((Registers.regSP.Get() + 1), (rHL.Get() / 256));
            WaitTCycle(23);
        }

/**
 * Ex (SP),IY.
 */         
        public void EX_ToWherePointsSP_IY()
        {
            Reg16 rHL = new Reg16(Registers.regIY.Get());
            Registers.regLY.Set(ram.ReadRAM(Registers.regSP.Get()));
            Registers.regHY.Set(ram.ReadRAM(Registers.regSP.Get() + 1));
            ram.WriteRAM(Registers.regSP.Get(), (rHL.Get() % 256));
            ram.WriteRAM((Registers.regSP.Get() + 1), (rHL.Get() / 256));
            WaitTCycle(23);
        }
        
        
/**
 * Returns a 16bit  number which is stored in memory at a position
 * given by the operand.
 */         
    public int FromWherePointsOp()
    {
        int addr = FetchWord();
        int low = ram.ReadRAM(addr);
        int high = ram.ReadRAM(addr + 1);
        return (low + (256 * high));
    }

/**
 * Returns a 8bit number which is stored in memory at a position
 * given by a 16bit register.
 */         
    public int FromWherePointsReg16(Reg16 regX)
    {
        int addr = regX.Get();
        int value = ram.ReadRAM(addr);
        return value;
    }
    
    public void im(int i)
    {
        Registers.im.Set(i);
        WaitTCycle(4);
    }
    
    /**
     * Called when an instruction is not implemented.
     */
    public void NotImplemented(int code)
    {
        MessageBox.Show("CPUroutines: Instruction not supported, code: " + code);
    }
   


        //end of class
    }
}

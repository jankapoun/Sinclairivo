using System;
using System.Collections.Generic;
using System.Text;

namespace Sinclairivo.NET
{
/*
 * This class stores all the global variables and constants
 */
    public class Globals
    {
            public static int ScreenRefreshFrequency = 1000 / 50;// = 50Hz
            public static int FlashFrequency = 15; //Frequency of blinking attributes

            public static bool reset = false; //resets the whole ZXS machine if set
            public static bool pause = false; //pauses the ZXS machine
            public static bool quality = true; //picture/screen rendering quality
            public static bool pauseScreenRefresh = false; //pauses the screen refresh (menu can be pulled down)
            public static bool snapshotSNARequest = false;// if true, does RET instruction and jumps into the snapped program.
            public static bool snapshotLoading = false;
            public static bool CPUparserInProgress = false;
            public static bool paintingInProgress = false;
            public static bool mapCursorAsKempston = false;

            /**
             * Zilog CPU speed, 
             * 20 approximates 3,5MHz - however, some time needs also the
             * emulator to execute, so -5 for approximation
             */

            public static int CPUspeed = 15;
            public static int sliderCPUspeedMin = 1;
            public static int sliderCPUspeedMax = 60;

        //end of class
    }
}
